import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Copy, 
  Share2, 
  MapPin, 
  Calendar, 
  Clock, 
  Building2, 
  Plane, 
  DollarSign, 
  ArrowLeft, 
  Sparkles,
  MessageCircle
} from 'lucide-react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import LoadingSpinner from '../components/common/LoadingSpinner';

export default function SharedTripPage({ slug, onNavigate, showToast }) {
  const { user, isAuthenticated, refreshUser } = useAuth();
  const { formatAmount } = useCurrency();
  const [tripData, setTripData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadPublicTrip() {
      try {
        setLoading(true);
        const data = await api.community.getBySlug(slug);
        setTripData(data);
      } catch (err) {
        console.error('Failed to load shared trip:', err);
        showToast('Shared itinerary not found or has been made private.', 'error');
      } finally {
        setLoading(false);
      }
    }
    if (slug) loadPublicTrip();
  }, [slug]);

  async function handleToggleLike() {
    if (!isAuthenticated) {
      showToast('Please sign in to like this itinerary.', 'info');
      return;
    }
    try {
      const res = await api.community.toggleLike(tripData.trip.id);
      setTripData({
        ...tripData,
        trip: {
          ...tripData.trip,
          isLiked: res.isLiked,
          likesCount: res.likesCount
        }
      });
      showToast(res.isLiked ? 'Itinerary upvoted!' : 'Like removed', 'success');
    } catch {
      showToast('Failed to update like', 'error');
    }
  }

  async function handleClone() {
    if (!isAuthenticated) {
      showToast('Please sign in to clone this itinerary into your account.', 'info');
      return;
    }
    try {
      const res = await api.community.cloneTrip(tripData.trip.id);
      showToast(res.message, 'success');
      refreshUser();
      onNavigate('my-trips');
    } catch (err) {
      showToast(err.message || 'Failed to clone trip', 'error');
    }
  }

  function handleShareLink() {
    navigator.clipboard.writeText(window.location.href);
    showToast('Shareable link copied to clipboard!', 'success');
  }

  function shareTwitter() {
    const text = encodeURIComponent(`Check out this travel itinerary for ${tripData.trip.title} on GlobeTrotter!`);
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${encodeURIComponent(window.location.href)}`, '_blank');
  }

  function shareWhatsApp() {
    const text = encodeURIComponent(`Check out this trip plan "${tripData.trip.title}" on GlobeTrotter: ${window.location.href}`);
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  }

  if (loading || !tripData) return <LoadingSpinner message="Opening shared community itinerary..." />;

  const { trip, stops = [] } = tripData;

  return (
    <div className="container" style={{ paddingBottom: '4rem' }}>
      {/* Top Navigation */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '1.5rem 0 1.25rem' }}>
        <button className="btn btn-ghost btn-sm" onClick={() => onNavigate('community')}>
          <ArrowLeft size={16} />
          <span>Back to Community Hub</span>
        </button>

        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <button className="btn btn-outline btn-sm" onClick={handleShareLink}>
            <Share2 size={15} />
            <span>Copy Link</span>
          </button>
          <button className="btn btn-outline btn-sm" onClick={shareWhatsApp} style={{ color: '#25D366' }}>
            <MessageCircle size={15} />
            <span>WhatsApp</span>
          </button>
          <button className="btn btn-primary btn-sm" onClick={handleClone}>
            <Copy size={15} />
            <span>Copy to My Trips</span>
          </button>
        </div>
      </div>

      {/* Hero Banner */}
      <div style={{
        position: 'relative',
        borderRadius: 'var(--radius-xl)',
        overflow: 'hidden',
        boxShadow: 'var(--shadow-xl)',
        marginBottom: '2rem',
        minHeight: '280px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'flex-end',
        padding: '2.5rem 2rem',
        color: 'white',
        background: `linear-gradient(180deg, rgba(15, 23, 42, 0.2) 0%, rgba(15, 23, 42, 0.9) 100%), url('${trip.coverImage}') center/cover no-repeat`
      }}>
        <div style={{ position: 'relative', zIndex: 2, maxWidth: '800px' }}>
          <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.75rem' }}>
            <span className="badge badge-coral" style={{ backdropFilter: 'blur(8px)' }}>{trip.travelStyle}</span>
            <span className="badge badge-teal" style={{ backdropFilter: 'blur(8px)' }}>{stops.length} Cities</span>
          </div>

          <h1 style={{ fontSize: '2.4rem', fontWeight: 800, color: 'white', lineHeight: 1.15, marginBottom: '0.75rem' }}>
            {trip.title}
          </h1>

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1.25rem', fontSize: '0.95rem', color: '#E2E8F0' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <Calendar size={16} color="var(--primary-coral)" />
              <span>{trip.startDate} to {trip.endDate}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <DollarSign size={16} color="var(--accent-emerald)" />
              <span>Est. Budget: {formatAmount(trip.budgetAllocated)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Author Card & Likes */}
      <div className="card" style={{ padding: '1.25rem 1.75rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <img
            src={trip.author?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
            alt=""
            style={{ width: '48px', height: '48px', borderRadius: '50%', objectFit: 'cover' }}
          />
          <div>
            <div style={{ fontWeight: 800, fontSize: '1.05rem' }}>Created by {trip.author?.name}</div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{trip.author?.location || 'GlobeTrotter Explorer'}</div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button
            onClick={handleToggleLike}
            className={`btn ${trip.isLiked ? 'btn-danger' : 'btn-outline'}`}
            style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}
          >
            <Heart size={16} fill={trip.isLiked ? 'currentColor' : 'none'} />
            <span>{trip.likesCount} Upvotes</span>
          </button>
          <button className="btn btn-primary" onClick={handleClone}>
            <Copy size={16} />
            <span>Clone This Itinerary</span>
          </button>
        </div>
      </div>

      {/* Stops & Day Breakdown */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
        {stops.map((stop, sIdx) => (
          <div key={stop.id} className="card" style={{ padding: '1.75rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.25rem', borderBottom: '1px solid var(--border-color)', paddingBottom: '1rem' }}>
              <img src={stop.cityImage} alt={stop.cityName} style={{ width: '60px', height: '60px', borderRadius: 'var(--radius-md)', objectFit: 'cover' }} />
              <div>
                <h3 style={{ fontSize: '1.4rem', fontWeight: 800 }}>Stop {sIdx + 1}: {stop.cityName}, {stop.cityCountry}</h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                  {stop.arrivalDate} to {stop.departureDate} • Lodging: {stop.accommodationName}
                </p>
              </div>
            </div>

            {/* Activities in this stop */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
              {(stop.activities || []).map(act => (
                <div key={act.id} style={{ padding: '1rem', background: 'var(--bg-surface-secondary)', borderRadius: 'var(--radius-md)', borderLeft: '4px solid var(--primary-coral)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', fontWeight: 700, color: 'var(--primary-coral)' }}>
                    <span>Day {act.dayNumber} • {act.startTime}</span>
                    <span style={{ color: 'var(--text-primary)' }}>{act.cost === 0 ? 'Free' : formatAmount(act.cost)}</span>
                  </div>
                  <h4 style={{ fontSize: '1rem', fontWeight: 700, marginTop: '0.35rem' }}>{act.title}</h4>
                  <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '0.25rem' }}>{act.notes || 'Curated experience'}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
