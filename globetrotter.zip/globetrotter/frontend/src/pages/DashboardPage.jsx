import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Compass, 
  Map, 
  Globe2, 
  Calendar, 
  DollarSign, 
  TrendingUp, 
  Sparkles, 
  ArrowRight, 
  Heart, 
  Star,
  CheckCircle2,
  Users
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import api from '../services/api';
import TripCard from '../components/cards/TripCard';
import CityCard from '../components/cards/CityCard';
import BudgetGauge from '../components/charts/BudgetGauge';
import LoadingSpinner from '../components/common/LoadingSpinner';

export default function DashboardPage({
  onNavigate,
  onOpenCreateTrip,
  onViewTrip,
  onEditTrip,
  onBudgetTrip,
  onAddStopWithCity,
  onViewCityDetails,
  showToast
}) {
  const { user, stats, refreshUser } = useAuth();
  const { formatAmount } = useCurrency();
  const [trips, setTrips] = useState([]);
  const [cities, setCities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchDashboardData() {
      try {
        setLoading(true);
        const [tripsData, citiesData] = await Promise.all([
          api.trips.list({ limit: 6 }),
          api.cities.list()
        ]);
        setTrips(tripsData.trips || []);
        setCities(citiesData.cities || []);
      } catch (err) {
        console.error('Failed to load dashboard:', err);
        showToast('Failed to load dashboard data', 'error');
      } finally {
        setLoading(false);
      }
    }
    fetchDashboardData();
  }, []);

  async function handleToggleSaveCity(cityId) {
    try {
      const res = await api.cities.toggleSave(cityId);
      setCities(cities.map(c => c.id === cityId ? { ...c, isSaved: res.isSaved } : c));
      showToast(res.message, 'success');
      refreshUser();
    } catch (err) {
      showToast('Failed to update wishlist', 'error');
    }
  }

  async function handleCloneTrip(tripId) {
    try {
      const res = await api.trips.duplicate(tripId);
      showToast(res.message, 'success');
      const updated = await api.trips.list();
      setTrips(updated.trips || []);
      refreshUser();
    } catch (err) {
      showToast('Failed to clone trip', 'error');
    }
  }

  async function handleDeleteTrip(tripId) {
    if (!window.confirm('Are you sure you want to delete this itinerary?')) return;
    try {
      await api.trips.delete(tripId);
      showToast('Trip deleted successfully', 'info');
      setTrips(trips.filter(t => t.id !== tripId));
      refreshUser();
    } catch (err) {
      showToast('Failed to delete trip', 'error');
    }
  }

  if (loading) return <LoadingSpinner message="Curating your personal dashboard..." />;

  const ongoingTrips = trips.filter(t => t.status === 'ongoing');
  const upcomingTrips = trips.filter(t => t.status === 'upcoming');
  const primaryTrip = ongoingTrips[0] || upcomingTrips[0] || trips[0];

  return (
    <div className="container-wide" style={{ paddingBottom: '3rem' }}>
      {/* 1. Hero Banner */}
      <div className="hero-banner">
        <div style={{ maxWidth: '640px' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', padding: '0.35rem 0.85rem', background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(8px)', borderRadius: 'var(--radius-full)', fontSize: '0.8rem', fontWeight: 700, marginBottom: '1rem', color: '#FFF' }}>
            <Sparkles size={14} color="var(--primary-coral)" />
            <span>Welcome Back, {user?.firstName || 'Traveler'}!</span>
          </div>

          <h1 className="hero-title">
            Where will your next <span className="hero-title-highlight">adventure</span> take you?
          </h1>

          <p className="hero-subtitle">
            Plan multi-city itineraries, organize daily schedules, track live travel budgets, and explore curated destination guides.
          </p>

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.85rem' }}>
            <button className="btn btn-primary btn-lg" onClick={onOpenCreateTrip}>
              <Plus size={18} />
              <span>Plan New Journey</span>
            </button>
            <button className="btn btn-outline btn-lg" onClick={() => onNavigate('cities')} style={{ background: 'rgba(255,255,255,0.95)' }}>
              <Compass size={18} />
              <span>Explore Destinations</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Key Metrics & Stat Highlights */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
        gap: '1.25rem',
        marginBottom: '2.5rem'
      }}>
        <button
          type="button"
          className="card stat-card-clickable"
          onClick={() => onNavigate('my-trips')}
          style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem', textAlign: 'left', border: '1px solid var(--border-color)', cursor: 'pointer' }}
          title="View all your itineraries"
        >
          <div style={{ width: '48px', height: '48px', borderRadius: 'var(--radius-md)', background: 'rgba(255, 107, 74, 0.12)', color: 'var(--primary-coral)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Map size={24} />
          </div>
          <div>
            <div style={{ fontSize: '1.65rem', fontWeight: 800 }}>{stats?.totalTrips ?? 0}</div>
            <div style={{ fontSize: '0.825rem', color: 'var(--text-muted)', fontWeight: 600 }}>Total Itineraries</div>
          </div>
        </button>

        <button
          type="button"
          className="card stat-card-clickable"
          onClick={() => onNavigate('my-trips')}
          style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem', textAlign: 'left', border: '1px solid var(--border-color)', cursor: 'pointer' }}
          title="See the countries behind your itineraries"
        >
          <div style={{ width: '48px', height: '48px', borderRadius: 'var(--radius-md)', background: 'rgba(8, 145, 178, 0.12)', color: 'var(--secondary-teal)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Globe2 size={24} />
          </div>
          <div>
            <div style={{ fontSize: '1.65rem', fontWeight: 800 }}>{stats?.totalCountries ?? 0}</div>
            <div style={{ fontSize: '0.825rem', color: 'var(--text-muted)', fontWeight: 600 }}>Countries Explored</div>
          </div>
        </button>

        <button
          type="button"
          className="card stat-card-clickable"
          onClick={() => onNavigate('calendar')}
          style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem', textAlign: 'left', border: '1px solid var(--border-color)', cursor: 'pointer' }}
          title="View your scheduled experiences on the calendar"
        >
          <div style={{ width: '48px', height: '48px', borderRadius: 'var(--radius-md)', background: 'rgba(109, 93, 211, 0.12)', color: 'var(--accent-indigo)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Sparkles size={24} />
          </div>
          <div>
            <div style={{ fontSize: '1.65rem', fontWeight: 800 }}>{stats?.totalActivities ?? 0}</div>
            <div style={{ fontSize: '0.825rem', color: 'var(--text-muted)', fontWeight: 600 }}>Scheduled Experiences</div>
          </div>
        </button>

        <button
          type="button"
          className="card stat-card-clickable"
          onClick={() => onNavigate('profile')}
          style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem', textAlign: 'left', border: '1px solid var(--border-color)', cursor: 'pointer' }}
          title="View your saved wishlist destinations"
        >
          <div style={{ width: '48px', height: '48px', borderRadius: 'var(--radius-md)', background: 'rgba(217, 164, 65, 0.15)', color: 'var(--accent-gold)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Heart size={24} />
          </div>
          <div>
            <div style={{ fontSize: '1.65rem', fontWeight: 800 }}>{stats?.savedDestinationsCount ?? 0}</div>
            <div style={{ fontSize: '0.825rem', color: 'var(--text-muted)', fontWeight: 600 }}>Wishlist Destinations</div>
          </div>
        </button>
      </div>

      {/* 3. Main Dashboard Grid: Upcoming Trips & Budget Snapshot */}
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 2fr) minmax(0, 1fr)', gap: '2rem', marginBottom: '3rem' }}>
        {/* Left: Active & Recent Trips */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
            <div>
              <h2 style={{ fontSize: '1.4rem', fontWeight: 800 }}>Your Travel Itineraries</h2>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Ongoing and upcoming journeys</p>
            </div>
            <button className="btn btn-ghost btn-sm" onClick={() => onNavigate('my-trips')} style={{ color: 'var(--primary-coral)', fontWeight: 700 }}>
              <span>View All ({trips.length})</span>
              <ArrowRight size={15} />
            </button>
          </div>

          {trips.length > 0 ? (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem' }}>
              {trips.slice(0, 4).map(trip => (
                <TripCard
                  key={trip.id}
                  trip={trip}
                  onView={onViewTrip}
                  onEdit={onEditTrip}
                  onBudget={onBudgetTrip}
                  onCalendar={() => onNavigate('calendar')}
                  onClone={handleCloneTrip}
                  onDelete={handleDeleteTrip}
                />
              ))}
            </div>
          ) : (
            <div className="card" style={{ padding: '3rem 2rem', textAlign: 'center' }}>
              <div style={{ width: '56px', height: '56px', borderRadius: '50%', background: 'var(--bg-surface-secondary)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', marginBottom: '1rem' }}>
                <Map size={28} />
              </div>
              <h3 style={{ fontSize: '1.2rem', fontWeight: 700 }}>No Itineraries Planned Yet</h3>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', maxWidth: '380px', margin: '0.5rem auto 1.5rem' }}>
                Start designing your first dream trip by selecting travel dates, cities, and budgeting goals.
              </p>
              <button className="btn btn-primary" onClick={onOpenCreateTrip}>
                <Plus size={16} />
                <span>Create Your First Trip</span>
              </button>
            </div>
          )}
        </div>

        {/* Right: Quick Budget Snapshot & Quick Actions */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Primary Trip Budget Gauge */}
          {primaryTrip && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 700 }}>Financial Overview</h3>
                <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{primaryTrip.title}</span>
              </div>
              <BudgetGauge allocated={primaryTrip.budgetAllocated} spent={primaryTrip.totalSpent} />
            </div>
          )}

          {/* Quick Action Navigation Card */}
          <div className="card" style={{ padding: '1.25rem' }}>
            <h3 style={{ fontSize: '1.05rem', fontWeight: 700, marginBottom: '0.85rem' }}>Quick Actions</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
              <button
                className="btn btn-outline"
                onClick={() => onNavigate('cities')}
                style={{ justifyContent: 'flex-start', padding: '0.75rem 1rem' }}
              >
                <Globe2 size={18} color="var(--secondary-teal)" />
                <div style={{ textAlign: 'left', marginLeft: '0.4rem' }}>
                  <div style={{ fontWeight: 700, fontSize: '0.875rem' }}>Explore Global Cities</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Browse top destinations and cost guides</div>
                </div>
              </button>

              <button
                className="btn btn-outline"
                onClick={() => onNavigate('activities')}
                style={{ justifyContent: 'flex-start', padding: '0.75rem 1rem' }}
              >
                <Sparkles size={18} color="var(--accent-indigo)" />
                <div style={{ textAlign: 'left', marginLeft: '0.4rem' }}>
                  <div style={{ fontWeight: 700, fontSize: '0.875rem' }}>Discover Experiences</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Tours, cuisine masterclasses, outdoor hikes</div>
                </div>
              </button>

              <button
                className="btn btn-outline"
                onClick={() => onNavigate('community')}
                style={{ justifyContent: 'flex-start', padding: '0.75rem 1rem' }}
              >
                <Users size={18} color="var(--primary-coral)" />
                <div style={{ textAlign: 'left', marginLeft: '0.4rem' }}>
                  <div style={{ fontWeight: 700, fontSize: '0.875rem' }}>Community Itineraries</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Discover & clone public itineraries</div>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Recommended Trending Destinations */}
      <div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
          <div>
            <h2 style={{ fontSize: '1.4rem', fontWeight: 800 }}>Trending Worldwide Destinations</h2>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Handpicked cities with top traveler ratings</p>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={() => onNavigate('cities')} style={{ color: 'var(--primary-coral)', fontWeight: 700 }}>
            <span>Explore All Cities ({cities.length})</span>
            <ArrowRight size={15} />
          </button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1.25rem' }}>
          {cities.slice(0, 4).map(city => (
            <CityCard
              key={city.id}
              city={city}
              onToggleSave={handleToggleSaveCity}
              onAddToTrip={(c) => onAddStopWithCity(c)}
              onViewDetails={() => onViewCityDetails && onViewCityDetails(city.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
