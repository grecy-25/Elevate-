import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Building2, 
  Plane, 
  DollarSign, 
  Edit3, 
  Share2, 
  Printer, 
  CheckCircle2, 
  Sparkles, 
  ArrowLeft,
  LayoutList,
  Layers,
  CalendarDays
} from 'lucide-react';
import api from '../services/api';
import { useCurrency } from '../context/CurrencyContext';
import LoadingSpinner from '../components/common/LoadingSpinner';

export default function ItineraryViewPage({
  tripId,
  onEditTrip,
  onBudgetTrip,
  onNavigate,
  showToast
}) {
  const { formatAmount } = useCurrency();
  const [tripData, setTripData] = useState(null);
  const [viewMode, setViewMode] = useState('timeline'); // 'timeline' | 'day-wise' | 'city-wise'
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        const data = await api.trips.getById(tripId);
        setTripData(data);
      } catch (err) {
        console.error('Failed to load itinerary view:', err);
        showToast('Failed to load itinerary', 'error');
      } finally {
        setLoading(false);
      }
    }
    if (tripId) loadData();
  }, [tripId]);

  function handleShare() {
    const url = `${window.location.origin}/#/share/${tripData.trip.shareSlug}`;
    navigator.clipboard.writeText(url);
    showToast('Public itinerary link copied to clipboard!', 'success');
  }

  function handlePrint() {
    window.print();
  }

  if (loading || !tripData) return <LoadingSpinner message="Generating your trip visual plan..." />;

  const { trip, stops = [], budget } = tripData;

  // Flatten all activities with computed dates for timeline
  const allTimelineActivities = [];
  stops.forEach(stop => {
    const stopArrival = new Date(stop.arrivalDate);
    (stop.activities || []).forEach(act => {
      const actDate = new Date(stopArrival);
      actDate.setDate(actDate.getDate() + ((act.dayNumber || 1) - 1));
      allTimelineActivities.push({
        ...act,
        cityName: stop.cityName,
        cityCountry: stop.cityCountry,
        computedDate: actDate.toISOString().split('T')[0],
        dateFormatted: actDate.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })
      });
    });
  });

  // Sort timeline by date then time
  allTimelineActivities.sort((a, b) => {
    if (a.computedDate !== b.computedDate) return a.computedDate.localeCompare(b.computedDate);
    return (a.startTime || '').localeCompare(b.startTime || '');
  });

  return (
    <div className="container" style={{ paddingBottom: '4rem' }}>
      {/* Top Controls Bar */}
      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '1rem',
        margin: '1.5rem 0 1.25rem'
      }}>
        <button className="btn btn-ghost btn-sm" onClick={() => onEditTrip(trip.id)}>
          <ArrowLeft size={16} />
          <span>Back to Builder</span>
        </button>

        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
          <button className="btn btn-outline btn-sm" onClick={handlePrint}>
            <Printer size={15} />
            <span>Print Itinerary</span>
          </button>
          <button className="btn btn-outline btn-sm" onClick={handleShare}>
            <Share2 size={15} />
            <span>Share Public Link</span>
          </button>
          <button className="btn btn-primary btn-sm" onClick={() => onEditTrip(trip.id)}>
            <Edit3 size={15} />
            <span>Edit Plan</span>
          </button>
        </div>
      </div>

      {/* Hero Header Card */}
      <div style={{
        position: 'relative',
        borderRadius: 'var(--radius-xl)',
        overflow: 'hidden',
        boxShadow: 'var(--shadow-xl)',
        marginBottom: '2rem',
        minHeight: '280px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'flex-end',
        padding: '2.5rem 2rem',
        color: 'white',
        background: `linear-gradient(180deg, rgba(15, 23, 42, 0.2) 0%, rgba(15, 23, 42, 0.9) 100%), url('${trip.coverImage}') center/cover no-repeat`
      }}>
        <div style={{ position: 'relative', zIndex: 2, maxWidth: '800px' }}>
          <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.75rem' }}>
            <span className="badge badge-coral" style={{ backdropFilter: 'blur(8px)' }}>{trip.travelStyle}</span>
            <span className="badge badge-teal" style={{ backdropFilter: 'blur(8px)' }}>{stops.length} Cities</span>
            <span className="badge badge-indigo" style={{ backdropFilter: 'blur(8px)' }}>{trip.status}</span>
          </div>

          <h1 style={{ fontSize: '2.5rem', fontWeight: 800, color: 'white', lineHeight: 1.15, marginBottom: '0.75rem' }}>
            {trip.title}
          </h1>

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1.25rem', fontSize: '0.95rem', color: '#E2E8F0' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <Calendar size={16} color="var(--primary-coral)" />
              <span>{trip.startDate} to {trip.endDate}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <DollarSign size={16} color="var(--accent-emerald)" />
              <span>Est. Budget: {formatAmount(budget.totalSpent)}</span>
            </div>
            {trip.owner && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <img src={trip.owner.avatarUrl} alt="" style={{ width: '22px', height: '22px', borderRadius: '50%' }} />
                <span>Planned by {trip.owner.firstName} {trip.owner.lastName}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* View Mode Switcher */}
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        marginBottom: '2rem'
      }}>
        <div style={{
          display: 'flex',
          background: 'var(--bg-surface)',
          padding: '4px',
          borderRadius: 'var(--radius-full)',
          border: '1px solid var(--border-color)',
          boxShadow: 'var(--shadow-sm)'
        }}>
          <button
            onClick={() => setViewMode('timeline')}
            className={`btn btn-sm ${viewMode === 'timeline' ? 'btn-primary' : 'btn-ghost'}`}
            style={{ borderRadius: 'var(--radius-full)', padding: '0.45rem 1.25rem' }}
          >
            <Layers size={15} />
            <span>Timeline View</span>
          </button>
          <button
            onClick={() => setViewMode('day-wise')}
            className={`btn btn-sm ${viewMode === 'day-wise' ? 'btn-primary' : 'btn-ghost'}`}
            style={{ borderRadius: 'var(--radius-full)', padding: '0.45rem 1.25rem' }}
          >
            <CalendarDays size={15} />
            <span>Day-by-Day</span>
          </button>
          <button
            onClick={() => setViewMode('city-wise')}
            className={`btn btn-sm ${viewMode === 'city-wise' ? 'btn-primary' : 'btn-ghost'}`}
            style={{ borderRadius: 'var(--radius-full)', padding: '0.45rem 1.25rem' }}
          >
            <LayoutList size={15} />
            <span>City Stops</span>
          </button>
        </div>
      </div>

      {/* 1. TIMELINE VIEW */}
      {viewMode === 'timeline' && (
        <div style={{ maxWidth: '800px', margin: '0 auto', position: 'relative' }}>
          {/* Vertical line */}
          <div style={{
            position: 'absolute',
            left: '20px',
            top: '20px',
            bottom: '20px',
            width: '3px',
            background: 'var(--border-color)',
            zIndex: 1
          }} />

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.75rem', position: 'relative', zIndex: 2 }}>
            {allTimelineActivities.map((act, idx) => (
              <div key={idx} style={{ display: 'flex', gap: '1.5rem', alignItems: 'flex-start' }}>
                {/* Timeline node */}
                <div style={{
                  width: '42px',
                  height: '42px',
                  borderRadius: '50%',
                  background: 'var(--primary-gradient)',
                  color: 'white',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                  boxShadow: 'var(--shadow-coral)'
                }}>
                  <Clock size={18} />
                </div>

                {/* Timeline Activity Card */}
                <div className="card" style={{ flex: 1, padding: '1.25rem', borderLeft: '4px solid var(--primary-coral)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem' }}>
                    <div>
                      <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--primary-coral)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                        {act.dateFormatted} • {act.startTime}
                      </span>
                      <h3 style={{ fontSize: '1.2rem', fontWeight: 800, marginTop: '0.2rem' }}>{act.title}</h3>
                    </div>
                    <span style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                      {act.cost === 0 ? 'Free' : formatAmount(act.cost)}
                    </span>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.825rem', color: 'var(--text-secondary)', marginBottom: '0.75rem' }}>
                    <MapPin size={14} color="var(--secondary-teal)" />
                    <span>{act.cityName}, {act.cityCountry}</span>
                    <span>•</span>
                    <span className="badge badge-indigo" style={{ fontSize: '0.7rem' }}>{act.category}</span>
                    <span>•</span>
                    <span>{act.durationMins} Mins</span>
                  </div>

                  {act.notes && (
                    <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', background: 'var(--bg-surface-secondary)', padding: '0.5rem 0.75rem', borderRadius: 'var(--radius-sm)' }}>
                      {act.notes}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. DAY-BY-DAY VIEW */}
      {viewMode === 'day-wise' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', maxWidth: '880px', margin: '0 auto' }}>
          {stops.map((stop, sIdx) => (
            <div key={stop.id}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
                <span style={{ fontSize: '1.35rem', fontWeight: 800 }}>Stop {sIdx + 1}: {stop.cityName}</span>
                <span className="badge badge-teal">{stop.arrivalDate} to {stop.departureDate}</span>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
                {(stop.activities || []).map(act => (
                  <div key={act.id} className="card" style={{ padding: '1.25rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                      <span className="badge badge-coral">Day {act.dayNumber} • {act.startTime}</span>
                      <strong>{act.cost === 0 ? 'Free' : formatAmount(act.cost)}</strong>
                    </div>
                    <h4 style={{ fontSize: '1.05rem', fontWeight: 700 }}>{act.title}</h4>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '0.25rem' }}>{act.notes || 'Curated activity scheduled.'}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 3. CITY-WISE VIEW */}
      {viewMode === 'city-wise' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '1.5rem' }}>
          {stops.map((stop, idx) => (
            <div key={stop.id} className="card" style={{ overflow: 'hidden' }}>
              <div style={{ position: 'relative', height: '160px' }}>
                <img src={stop.cityImage} alt={stop.cityName} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent 0%, rgba(15,23,42,0.8) 100%)' }} />
                <div style={{ position: 'absolute', bottom: '12px', left: '16px', color: 'white' }}>
                  <h3 style={{ fontSize: '1.4rem', fontWeight: 800 }}>Stop {idx + 1}: {stop.cityName}</h3>
                  <p style={{ fontSize: '0.85rem' }}>{stop.cityCountry}</p>
                </div>
              </div>
              <div style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Stay:</span>
                  <strong>{stop.accommodationName} ({formatAmount(stop.accommodationCost)})</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Transit:</span>
                  <strong>{stop.transportMode} ({formatAmount(stop.transportCost)})</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Activities:</span>
                  <strong>{stop.activities?.length || 0} scheduled</strong>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
