import React, { useState, useEffect } from 'react';
import { Calendar as CalendarIcon, MapPin, Sparkles, Plus, ArrowRight } from 'lucide-react';
import api from '../services/api';
import InteractiveCalendar from '../components/calendar/InteractiveCalendar';
import LoadingSpinner from '../components/common/LoadingSpinner';

export default function TripCalendarPage({ onViewTrip, onNavigate, showToast }) {
  const [trips, setTrips] = useState([]);
  const [selectedTripId, setSelectedTripId] = useState('all');
  const [fullTripsData, setFullTripsData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadCalendarData() {
      try {
        setLoading(true);
        const data = await api.trips.list();
        const tripList = data.trips || [];
        setTrips(tripList);

        // Fetch full hierarchy for all trips to populate calendar activities
        const fullList = await Promise.all(
          tripList.map(t => api.trips.getById(t.id).catch(() => null))
        );
        setFullTripsData(fullList.filter(Boolean).map(item => ({
          ...item.trip,
          stops: item.stops
        })));
      } catch (err) {
        console.error('Failed to load calendar:', err);
        showToast('Failed to load calendar events', 'error');
      } finally {
        setLoading(false);
      }
    }
    loadCalendarData();
  }, []);

  if (loading) return <LoadingSpinner message="Building your interactive calendar schedule..." />;

  const activeTripsForCalendar = selectedTripId === 'all' 
    ? fullTripsData 
    : fullTripsData.filter(t => t.id === Number(selectedTripId));

  const currentSelectedTrip = selectedTripId !== 'all' ? activeTripsForCalendar[0] : null;

  return (
    <div className="container-wide" style={{ paddingBottom: '4rem' }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '1rem',
        margin: '2rem 0 1.5rem'
      }}>
        <div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', padding: '0.25rem 0.65rem', background: 'rgba(109, 93, 211, 0.1)', color: 'var(--accent-indigo)', borderRadius: 'var(--radius-full)', fontSize: '0.8rem', fontWeight: 700, marginBottom: '0.5rem' }}>
            <CalendarIcon size={14} />
            <span>Itinerary Master Calendar</span>
          </div>
          <h1 style={{ fontSize: '2.2rem', fontWeight: 800 }}>Trip Timeline & Schedule</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
            Inspect scheduled activities and travel dates across all your journeys.
          </p>
        </div>

        {/* Trip Selector Filter */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <label style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-secondary)' }}>
            Filter Trip:
          </label>
          <select
            className="form-select"
            value={selectedTripId}
            onChange={(e) => setSelectedTripId(e.target.value)}
            style={{ width: 'auto', minWidth: '220px' }}
          >
            <option value="all">All Active Journeys ({fullTripsData.length})</option>
            {fullTripsData.map(t => (
              <option key={t.id} value={t.id}>{t.title}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Calendar Component */}
      <InteractiveCalendar
        trips={activeTripsForCalendar}
        currentTrip={currentSelectedTrip}
        onSelectTrip={onViewTrip}
      />
    </div>
  );
}
