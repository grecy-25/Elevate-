import React, { useState, useEffect } from 'react';
import { Plus, Search, Filter, Map, Calendar, ArrowRight, Copy, Trash2, Edit3, DollarSign } from 'lucide-react';
import api from '../services/api';
import TripCard from '../components/cards/TripCard';
import LoadingSpinner from '../components/common/LoadingSpinner';

export default function MyTripsPage({
  onOpenCreateTrip,
  onViewTrip,
  onEditTrip,
  onBudgetTrip,
  onNavigate,
  showToast
}) {
  const [trips, setTrips] = useState([]);
  const [counts, setCounts] = useState({ all: 0, ongoing: 0, upcoming: 0, completed: 0 });
  const [activeTab, setActiveTab] = useState('all'); // 'all' | 'ongoing' | 'upcoming' | 'completed'
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  async function fetchTrips() {
    try {
      setLoading(true);
      const data = await api.trips.list({
        status: activeTab,
        search: searchQuery
      });
      setTrips(data.trips || []);
      if (data.counts) setCounts(data.counts);
    } catch (err) {
      console.error('Failed to load trips:', err);
      showToast('Failed to load trips', 'error');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchTrips();
  }, [activeTab]);

  function handleSearchSubmit(e) {
    e.preventDefault();
    fetchTrips();
  }

  async function handleClone(tripId) {
    try {
      const res = await api.trips.duplicate(tripId);
      showToast(res.message, 'success');
      fetchTrips();
    } catch (err) {
      showToast('Failed to duplicate trip', 'error');
    }
  }

  async function handleDelete(tripId) {
    if (!window.confirm('Are you sure you want to permanently delete this itinerary and all its scheduled activities?')) return;
    try {
      await api.trips.delete(tripId);
      showToast('Trip deleted successfully', 'info');
      fetchTrips();
    } catch (err) {
      showToast('Failed to delete trip', 'error');
    }
  }

  return (
    <div className="container-wide" style={{ paddingBottom: '3rem' }}>
      {/* Page Header */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '1rem', margin: '2rem 0 1.75rem' }}>
        <div>
          <h1 style={{ fontSize: '2.2rem', fontWeight: 800 }}>My Travel Itineraries</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
            Manage, edit, and review your multi-city journeys
          </p>
        </div>

        <button className="btn btn-primary btn-lg" onClick={onOpenCreateTrip}>
          <Plus size={18} />
          <span>Plan New Journey</span>
        </button>
      </div>

      {/* Tabs & Search Bar */}
      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '1rem',
        background: 'var(--bg-surface)',
        padding: '0.75rem 1.25rem',
        borderRadius: 'var(--radius-lg)',
        border: '1px solid var(--border-color)',
        boxShadow: 'var(--shadow-sm)',
        marginBottom: '2rem'
      }}>
        {/* Status Filter Tabs */}
        <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
          {[
            { id: 'all', label: 'All Trips', count: counts.all },
            { id: 'ongoing', label: 'Ongoing', count: counts.ongoing },
            { id: 'upcoming', label: 'Upcoming', count: counts.upcoming },
            { id: 'completed', label: 'Past / Completed', count: counts.completed }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`btn btn-sm ${activeTab === tab.id ? 'btn-primary' : 'btn-ghost'}`}
              style={{ borderRadius: 'var(--radius-md)' }}
            >
              <span>{tab.label}</span>
              <span style={{
                background: activeTab === tab.id ? 'rgba(255,255,255,0.25)' : 'var(--bg-surface-secondary)',
                color: activeTab === tab.id ? 'white' : 'var(--text-secondary)',
                padding: '0.1rem 0.4rem',
                borderRadius: 'var(--radius-full)',
                fontSize: '0.75rem',
                fontWeight: 700
              }}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Search Input */}
        <form onSubmit={handleSearchSubmit} style={{ display: 'flex', gap: '0.5rem', minWidth: '260px' }}>
          <div style={{ position: 'relative', flex: 1 }}>
            <input
              type="text"
              className="form-input"
              placeholder="Search by trip name or city..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{ paddingLeft: '2.25rem', paddingRight: '0.75rem', height: '38px', fontSize: '0.875rem' }}
            />
            <Search size={15} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          </div>
          <button type="submit" className="btn btn-outline btn-sm">
            Search
          </button>
        </form>
      </div>

      {/* Trips Grid */}
      {loading ? (
        <LoadingSpinner message="Fetching your itineraries..." />
      ) : trips.length > 0 ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1.75rem' }}>
          {trips.map(trip => (
            <TripCard
              key={trip.id}
              trip={trip}
              onView={onViewTrip}
              onEdit={onEditTrip}
              onBudget={onBudgetTrip}
              onCalendar={() => onNavigate('calendar')}
              onClone={handleClone}
              onDelete={handleDelete}
            />
          ))}
        </div>
      ) : (
        <div className="card" style={{ padding: '4rem 2rem', textAlign: 'center', margin: '2rem 0' }}>
          <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: 'rgba(255, 107, 74, 0.1)', color: 'var(--primary-coral)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1.25rem' }}>
            <Map size={32} />
          </div>
          <h3 style={{ fontSize: '1.35rem', fontWeight: 800 }}>No Trips Found</h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem', maxWidth: '420px', margin: '0.5rem auto 1.75rem' }}>
            {searchQuery 
              ? `No itineraries matching "${searchQuery}". Try a different keyword.` 
              : `You don't have any ${activeTab !== 'all' ? activeTab : ''} itineraries currently.`}
          </p>
          <button className="btn btn-primary btn-lg" onClick={onOpenCreateTrip}>
            <Plus size={18} />
            <span>Start a New Trip</span>
          </button>
        </div>
      )}
    </div>
  );
}
