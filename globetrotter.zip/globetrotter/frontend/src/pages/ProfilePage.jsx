import React, { useState, useEffect } from 'react';
import { User, Mail, Phone, MapPin, Heart, Shield, Lock, Trash2, CheckCircle2, Coins, Globe } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import api from '../services/api';
import CityCard from '../components/cards/CityCard';
import LoadingSpinner from '../components/common/LoadingSpinner';

export default function ProfilePage({ onNavigate, onAddStopWithCity, showToast }) {
  const { user, stats, savedDestinations, refreshUser, logout } = useAuth();
  const { currency, setCurrency, currencies } = useCurrency();

  // Profile fields state
  const [firstName, setFirstName] = useState(user?.firstName || '');
  const [lastName, setLastName] = useState(user?.lastName || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [city, setCity] = useState(user?.city || '');
  const [country, setCountry] = useState(user?.country || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [avatarUrl, setAvatarUrl] = useState(user?.avatarUrl || '');

  // Password fields state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const [savingProfile, setSavingProfile] = useState(false);
  const [changingPass, setChangingPass] = useState(false);

  useEffect(() => {
    if (user) {
      setFirstName(user.firstName || '');
      setLastName(user.lastName || '');
      setPhone(user.phone || '');
      setCity(user.city || '');
      setCountry(user.country || '');
      setBio(user.bio || '');
      setAvatarUrl(user.avatarUrl || '');
    }
  }, [user]);

  async function handleUpdateProfile(e) {
    e.preventDefault();
    try {
      setSavingProfile(true);
      const res = await api.auth.updateProfile({
        firstName,
        lastName,
        phone,
        city,
        country,
        bio,
        avatarUrl,
        currency
      });
      showToast('Profile updated successfully!', 'success');
      refreshUser();
    } catch (err) {
      showToast(err.message || 'Failed to update profile', 'error');
    } finally {
      setSavingProfile(false);
    }
  }

  async function handleChangePassword(e) {
    e.preventDefault();
    if (!currentPassword || !newPassword) {
      showToast('Please fill in both current and new password.', 'error');
      return;
    }
    try {
      setChangingPass(true);
      await api.auth.changePassword({ currentPassword, newPassword });
      showToast('Password changed successfully!', 'success');
      setCurrentPassword('');
      setNewPassword('');
    } catch (err) {
      showToast(err.message || 'Failed to change password', 'error');
    } finally {
      setChangingPass(false);
    }
  }

  async function handleDeleteAccount() {
    if (!window.confirm('WARNING: Are you absolutely sure you want to permanently delete your account and all associated itineraries? This action cannot be undone.')) return;
    try {
      await api.auth.deleteAccount();
      logout();
      showToast('Account deleted successfully.', 'info');
      onNavigate('auth');
    } catch (err) {
      showToast('Failed to delete account', 'error');
    }
  }

  return (
    <div className="container" style={{ paddingBottom: '4rem' }}>
      {/* Header */}
      <div style={{ margin: '2rem 0 2rem' }}>
        <h1 style={{ fontSize: '2.3rem', fontWeight: 800 }}>Account & Traveler Profile</h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
          Manage your personal information, travel currency preferences, and saved destination wishlist.
        </p>
      </div>

      {/* Grid: Left Profile Form, Right Preferences & Wishlist */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '2rem' }}>
        {/* Left Column: Personal Information Form */}
        <div className="card" style={{ padding: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.75rem', paddingBottom: '1.25rem', borderBottom: '1px solid var(--border-color)' }}>
            <img
              src={avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80'}
              alt="Avatar"
              style={{ width: '64px', height: '64px', borderRadius: '50%', objectFit: 'cover', border: '3px solid var(--primary-coral)' }}
            />
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>{user?.firstName} {user?.lastName}</h3>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>{user?.email}</p>
              <span className={`badge ${user?.role === 'admin' ? 'badge-indigo' : 'badge-teal'}`} style={{ marginTop: '0.35rem' }}>
                {user?.role === 'admin' ? 'Platform Administrator' : 'GlobeTrotter Member'}
              </span>
            </div>
          </div>

          <form onSubmit={handleUpdateProfile}>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">First Name *</label>
                <input
                  type="text"
                  className="form-input"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Last Name *</label>
                <input
                  type="text"
                  className="form-input"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Phone Number</label>
                <input
                  type="tel"
                  className="form-input"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>
              <div className="form-group">
                <label className="form-label">City</label>
                <input
                  type="text"
                  className="form-input"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Country</label>
                <input
                  type="text"
                  className="form-input"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Avatar Photo URL</label>
                <input
                  type="url"
                  className="form-input"
                  placeholder="https://..."
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Bio / Travel Manifesto</label>
              <textarea
                className="form-textarea"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
              />
            </div>

            <button type="submit" className="btn btn-primary" disabled={savingProfile} style={{ width: '100%', marginTop: '0.5rem' }}>
              <span>{savingProfile ? 'Saving Changes...' : 'Save Profile Details'}</span>
            </button>
          </form>
        </div>

        {/* Right Column: Preferences & Security */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          {/* Currency & Localization Preference */}
          <div className="card" style={{ padding: '1.75rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
              <Coins size={20} color="var(--accent-gold)" />
              <h3 style={{ fontSize: '1.15rem', fontWeight: 800 }}>Currency Preferences</h3>
            </div>

            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '1rem' }}>
              Choose your preferred display currency for all trip budgeting and experience costs:
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(100px, 1fr))', gap: '0.5rem' }}>
              {Object.keys(currencies).map(code => (
                <button
                  key={code}
                  type="button"
                  onClick={() => setCurrency(code)}
                  className={`btn btn-sm ${currency === code ? 'btn-primary' : 'btn-outline'}`}
                  style={{ fontWeight: 700 }}
                >
                  {code} ({currencies[code].symbol})
                </button>
              ))}
            </div>
          </div>

          {/* Security & Password */}
          <div className="card" style={{ padding: '1.75rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
              <Lock size={20} color="var(--accent-indigo)" />
              <h3 style={{ fontSize: '1.15rem', fontWeight: 800 }}>Account Security</h3>
            </div>

            <form onSubmit={handleChangePassword}>
              <div className="form-group">
                <label className="form-label">Current Password</label>
                <input
                  type="password"
                  className="form-input"
                  placeholder="••••••••"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">New Password (min 6 characters)</label>
                <input
                  type="password"
                  className="form-input"
                  placeholder="••••••••"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                />
              </div>

              <button type="submit" className="btn btn-outline" disabled={changingPass} style={{ width: '100%' }}>
                <span>{changingPass ? 'Updating...' : 'Update Password'}</span>
              </button>
            </form>

            <div style={{ marginTop: '1.5rem', paddingTop: '1.25rem', borderTop: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: '0.875rem', color: '#DC2626' }}>Danger Zone</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Permanently erase account and itineraries</div>
              </div>
              <button className="btn btn-danger btn-sm" onClick={handleDeleteAccount}>
                <Trash2 size={14} />
                <span>Delete Account</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Saved Wishlist Section */}
      <div style={{ marginTop: '3.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.25rem' }}>
          <Heart size={22} fill="var(--accent-rose)" color="var(--accent-rose)" />
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Saved Travel Wishlist ({savedDestinations?.length || 0})</h2>
        </div>

        {savedDestinations && savedDestinations.length > 0 ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1.5rem' }}>
            {savedDestinations.map(city => (
              <CityCard
                key={city.id}
                city={{ ...city, isSaved: true }}
                onToggleSave={async (id) => {
                  await api.cities.toggleSave(id);
                  refreshUser();
                }}
                onAddToTrip={onAddStopWithCity}
              />
            ))}
          </div>
        ) : (
          <div className="card" style={{ padding: '2.5rem', textAlign: 'center', color: 'var(--text-muted)' }}>
            <p>No saved destinations yet. Explore cities and click the heart icon to save them to your wishlist!</p>
          </div>
        )}
      </div>
    </div>
  );
}
