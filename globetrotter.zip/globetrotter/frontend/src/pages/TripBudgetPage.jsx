import React, { useState, useEffect } from 'react';
import { 
  DollarSign, 
  Plus, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle2, 
  Trash2, 
  Receipt, 
  PieChart as PieIcon, 
  BarChart2, 
  ArrowLeft,
  Calendar,
  Tag
} from 'lucide-react';
import api from '../services/api';
import { useCurrency } from '../context/CurrencyContext';
import DonutChart from '../components/charts/DonutChart';
import BarChart from '../components/charts/BarChart';
import BudgetGauge from '../components/charts/BudgetGauge';
import AddExpenseModal from '../components/forms/AddExpenseModal';
import LoadingSpinner from '../components/common/LoadingSpinner';

export default function TripBudgetPage({
  tripId,
  onViewTrip,
  onEditTrip,
  onNavigate,
  showToast
}) {
  const { formatAmount } = useCurrency();
  const [budgetData, setBudgetData] = useState(null);
  const [trip, setTrip] = useState(null);
  const [showAddExpense, setShowAddExpense] = useState(false);
  const [loading, setLoading] = useState(true);

  async function loadBudgetData() {
    try {
      setLoading(true);
      const [expRes, tripRes] = await Promise.all([
        api.expenses.getByTrip(tripId),
        api.trips.getById(tripId)
      ]);
      setBudgetData(expRes);
      setTrip(tripRes.trip);
    } catch (err) {
      console.error('Failed to load budget data:', err);
      showToast('Failed to load financial breakdown', 'error');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (tripId) loadBudgetData();
  }, [tripId]);

  async function handleAddExpense(expensePayload) {
    try {
      await api.expenses.add(expensePayload);
      showToast('Expense recorded successfully!', 'success');
      loadBudgetData();
    } catch (err) {
      showToast(err.message || 'Failed to add expense', 'error');
    }
  }

  async function handleDeleteExpense(expenseId) {
    try {
      await api.expenses.delete(expenseId);
      showToast('Expense removed', 'info');
      loadBudgetData();
    } catch (err) {
      showToast('Failed to delete expense', 'error');
    }
  }

  if (loading || !budgetData || !trip) return <LoadingSpinner message="Calculating trip financial analytics..." />;

  const {
    allocatedBudget,
    totalSpent,
    remainingBudget,
    percentUtilized,
    isOverbudget,
    categories,
    dailyBreakdown,
    expenses = []
  } = budgetData;

  return (
    <div className="container-wide" style={{ paddingBottom: '4rem' }}>
      {/* Top Bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '1.5rem 0 1.25rem' }}>
        <button className="btn btn-ghost btn-sm" onClick={() => onEditTrip(trip.id)}>
          <ArrowLeft size={16} />
          <span>Back to Itinerary</span>
        </button>

        <div style={{ display: 'flex', gap: '0.65rem' }}>
          <button className="btn btn-primary btn-sm" onClick={() => setShowAddExpense(true)}>
            <Plus size={15} />
            <span>Log Custom Expense</span>
          </button>
          <button className="btn btn-outline btn-sm" onClick={() => onViewTrip(trip.id)}>
            <span>View Full Itinerary</span>
          </button>
        </div>
      </div>

      {/* Title */}
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', padding: '0.2rem 0.6rem', background: 'rgba(255, 107, 74, 0.1)', color: 'var(--primary-coral)', borderRadius: 'var(--radius-full)', fontSize: '0.75rem', fontWeight: 700, marginBottom: '0.4rem' }}>
          <DollarSign size={13} />
          <span>Trip Financial Command Center</span>
        </div>
        <h1 style={{ fontSize: '2.2rem', fontWeight: 800 }}>Budget & Cost Breakdown: {trip.title}</h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
          Real-time expense distribution across lodging, transportation, scheduled experiences, and dining.
        </p>
      </div>

      {/* Overbudget Warning Alert if applicable */}
      {isOverbudget && (
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.75rem',
          padding: '1rem 1.25rem',
          background: 'rgba(225, 71, 107, 0.1)',
          border: '1.5px solid var(--accent-rose)',
          borderRadius: 'var(--radius-lg)',
          color: 'var(--accent-rose)',
          marginBottom: '2rem'
        }}>
          <AlertTriangle size={24} style={{ flexShrink: 0 }} />
          <div>
            <h4 style={{ fontWeight: 800, fontSize: '1rem' }}>Budget Alert: Target Allocation Exceeded</h4>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              Total scheduled expenses currently exceed your target budget by {formatAmount(Math.abs(remainingBudget))}. Consider adjusting transit or accommodation choices.
            </p>
          </div>
        </div>
      )}

      {/* Key Financial KPIs */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.25rem', marginBottom: '2.5rem' }}>
        <div className="card" style={{ padding: '1.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Planned Allocation</span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--text-primary)', marginTop: '0.25rem' }}>
            {formatAmount(allocatedBudget)}
          </div>
        </div>

        <div className="card" style={{ padding: '1.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Total Spent / Scheduled</span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: isOverbudget ? 'var(--accent-rose)' : 'var(--primary-coral)', marginTop: '0.25rem' }}>
            {formatAmount(totalSpent)}
          </div>
        </div>

        <div className="card" style={{ padding: '1.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>{remainingBudget >= 0 ? 'Remaining Balance' : 'Over Budget Amount'}</span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: remainingBudget >= 0 ? 'var(--accent-emerald)' : 'var(--accent-rose)', marginTop: '0.25rem' }}>
            {formatAmount(Math.abs(remainingBudget))}
          </div>
        </div>

        <div className="card" style={{ padding: '1.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Budget Utilization</span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--secondary-teal)', marginTop: '0.25rem' }}>
            {percentUtilized}%
          </div>
        </div>
      </div>

      {/* Interactive Charts Section: Donut Chart & Daily Spend Bar Chart */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '2rem', marginBottom: '3rem' }}>
        {/* Category Donut Chart */}
        <div className="card" style={{ padding: '1.75rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.25rem' }}>
            <PieIcon size={20} color="var(--primary-coral)" />
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800 }}>Category Distribution</h3>
          </div>
          <DonutChart data={categories} size={250} />
        </div>

        {/* Daily Expenditure Bar Chart */}
        <div className="card" style={{ padding: '1.75rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.25rem' }}>
            <BarChart2 size={20} color="var(--accent-indigo)" />
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800 }}>Daily Spending Timeline</h3>
          </div>
          {dailyBreakdown.length > 0 ? (
            <BarChart data={dailyBreakdown} height={210} barColor="var(--accent-indigo)" />
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '210px', color: 'var(--text-muted)' }}>
              <p style={{ fontSize: '0.9rem' }}>No individual dated expenses logged yet.</p>
              <button className="btn btn-primary btn-sm" onClick={() => setShowAddExpense(true)} style={{ marginTop: '0.75rem' }}>
                <Plus size={14} />
                <span>Log First Expense</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Logged Expenses Ledger Table */}
      <div className="card" style={{ padding: '1.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Receipt size={20} color="var(--secondary-teal)" />
            <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>Detailed Expense Ledger ({expenses.length})</h3>
          </div>

          <button className="btn btn-primary btn-sm" onClick={() => setShowAddExpense(true)}>
            <Plus size={15} />
            <span>Add Expense</span>
          </button>
        </div>

        {expenses.length > 0 ? (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.9rem' }}>
              <thead>
                <tr style={{ borderBottom: '2px solid var(--border-color)', color: 'var(--text-muted)', fontSize: '0.8rem', textTransform: 'uppercase' }}>
                  <th style={{ padding: '0.75rem 1rem' }}>Title</th>
                  <th style={{ padding: '0.75rem 1rem' }}>Category</th>
                  <th style={{ padding: '0.75rem 1rem' }}>Date</th>
                  <th style={{ padding: '0.75rem 1rem' }}>Notes / Receipt</th>
                  <th style={{ padding: '0.75rem 1rem', textAlign: 'right' }}>Amount</th>
                  <th style={{ padding: '0.75rem 1rem', textAlign: 'center' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {expenses.map(e => (
                  <tr key={e.id} style={{ borderBottom: '1px solid var(--border-color)', transition: 'background 0.15s ease' }}>
                    <td style={{ padding: '0.85rem 1rem', fontWeight: 700 }}>{e.title}</td>
                    <td style={{ padding: '0.85rem 1rem' }}>
                      <span className="badge badge-indigo" style={{ fontSize: '0.75rem' }}>{e.category}</span>
                    </td>
                    <td style={{ padding: '0.85rem 1rem', color: 'var(--text-secondary)' }}>{e.expenseDate}</td>
                    <td style={{ padding: '0.85rem 1rem', color: 'var(--text-muted)' }}>{e.notes || '—'}</td>
                    <td style={{ padding: '0.85rem 1rem', textAlign: 'right', fontWeight: 800 }}>{formatAmount(e.amount)}</td>
                    <td style={{ padding: '0.85rem 1rem', textAlign: 'center' }}>
                      <button
                        onClick={() => handleDeleteExpense(e.id)}
                        style={{ background: 'none', border: 'none', color: '#DC2626', cursor: 'pointer' }}
                        title="Delete expense"
                      >
                        <Trash2 size={15} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '2.5rem 1rem', color: 'var(--text-muted)' }}>
            <p>No ad-hoc expenses recorded yet. Click "Add Expense" to log receipts, meals, and transit fares.</p>
          </div>
        )}
      </div>

      {/* Add Expense Modal */}
      <AddExpenseModal
        isOpen={showAddExpense}
        onClose={() => setShowAddExpense(false)}
        onAddExpense={handleAddExpense}
        tripId={trip.id}
      />
    </div>
  );
}
