import React, { useState, useEffect } from 'react';
import { Search, Filter, Globe2, Sparkles, MapPin, Plus, Heart } from 'lucide-react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import CityCard from '../components/cards/CityCard';
import LoadingSpinner from '../components/common/LoadingSpinner';

const REGIONS = ['All', 'Europe', 'Asia', 'Americas', 'Africa', 'Oceania', 'Middle East'];
const COST_OPTIONS = [
  { id: 'All', label: 'Any Budget' },
  { id: '1', label: '$ Budget' },
  { id: '2', label: '$$ Moderate' },
  { id: '3', label: '$$$ Upscale' },
  { id: '4', label: '$$$$ Luxury' }
];

export default function CitySearchPage({ onAddStopWithCity, onViewCityDetails, showToast }) {
  const { refreshUser } = useAuth();
  const [cities, setCities] = useState([]);
  const [region, setRegion] = useState('All');
  const [costIndex, setCostIndex] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  async function fetchCities() {
    try {
      setLoading(true);
      const data = await api.cities.list({
        region: region !== 'All' ? region : undefined,
        costIndex: costIndex !== 'All' ? costIndex : undefined,
        search: searchQuery
      });
      setCities(data.cities || []);
    } catch (err) {
      console.error('Failed to load cities:', err);
      showToast('Failed to load destination cities', 'error');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchCities();
  }, [region, costIndex]);

  function handleSearchSubmit(e) {
    e.preventDefault();
    fetchCities();
  }

  async function handleToggleSave(cityId) {
    try {
      const res = await api.cities.toggleSave(cityId);
      setCities(cities.map(c => c.id === cityId ? { ...c, isSaved: res.isSaved } : c));
      showToast(res.message, 'success');
      refreshUser();
    } catch {
      showToast('Failed to update wishlist', 'error');
    }
  }

  return (
    <div className="container-wide" style={{ paddingBottom: '3.5rem' }}>
      {/* Header */}
      <div style={{ margin: '2rem 0 1.5rem' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', padding: '0.25rem 0.65rem', background: 'rgba(8, 145, 178, 0.1)', color: 'var(--secondary-teal)', borderRadius: 'var(--radius-full)', fontSize: '0.8rem', fontWeight: 700, marginBottom: '0.5rem' }}>
          <Globe2 size={14} />
          <span>Global Destination Directory</span>
        </div>
        <h1 style={{ fontSize: '2.3rem', fontWeight: 800 }}>Explore Global Cities & Stops</h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
          Discover iconic travel destinations, average cost indices, and best seasonal weather for your itineraries.
        </p>
      </div>

      {/* Filter & Search Bar */}
      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        gap: '1rem',
        background: 'var(--bg-surface)',
        padding: '1.25rem',
        borderRadius: 'var(--radius-xl)',
        border: '1px solid var(--border-color)',
        boxShadow: 'var(--shadow-sm)',
        marginBottom: '2rem'
      }}>
        {/* Search */}
        <form onSubmit={handleSearchSubmit} style={{ flex: 1, minWidth: '240px', position: 'relative' }}>
          <input
            type="text"
            className="form-input"
            placeholder="Search by city name, country, or description..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{ paddingLeft: '2.5rem' }}
          />
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
        </form>

        {/* Region Pills */}
        <div style={{ display: 'flex', gap: '0.35rem', overflowX: 'auto', paddingBottom: '2px', alignItems: 'center' }}>
          {REGIONS.map(r => (
            <button
              key={r}
              onClick={() => setRegion(r)}
              className={`btn btn-sm ${region === r ? 'btn-secondary' : 'btn-outline'}`}
              style={{ fontSize: '0.825rem', borderRadius: 'var(--radius-full)', whiteSpace: 'nowrap' }}
            >
              {r}
            </button>
          ))}
        </div>

        {/* Cost Index Select */}
        <select
          className="form-select"
          value={costIndex}
          onChange={(e) => setCostIndex(e.target.value)}
          style={{ width: 'auto', minWidth: '150px' }}
        >
          {COST_OPTIONS.map(opt => (
            <option key={opt.id} value={opt.id}>{opt.label}</option>
          ))}
        </select>
      </div>

      {/* City Cards Grid */}
      {loading ? (
        <LoadingSpinner message="Searching global destinations..." />
      ) : cities.length > 0 ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1.75rem' }}>
          {cities.map(city => (
            <CityCard
              key={city.id}
              city={city}
              onToggleSave={handleToggleSave}
              onAddToTrip={onAddStopWithCity}
              onViewDetails={() => onViewCityDetails && onViewCityDetails(city.id)}
            />
          ))}
        </div>
      ) : (
        <div className="card" style={{ padding: '3.5rem 2rem', textAlign: 'center' }}>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>No Destinations Found</h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', margin: '0.5rem 0 1.5rem' }}>
            No cities matched your current search filters. Try selecting "All" regions or clearing the search bar.
          </p>
          <button className="btn btn-primary" onClick={() => { setRegion('All'); setCostIndex('All'); setSearchQuery(''); }}>
            Reset Filters
          </button>
        </div>
      )}
    </div>
  );
}
