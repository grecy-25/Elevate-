import React, { useState } from 'react';
import { Compass, Sparkles, ShieldCheck, Mail, Lock, User, Phone, MapPin, Globe, ArrowRight, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function AuthPage({ onLoginSuccess }) {
  const { login, register, loginAsDemoTraveler, loginAsDemoAdmin } = useAuth();
  const [tab, setTab] = useState('login'); // 'login' | 'register'
  
  // Login State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Register State
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [country, setCountry] = useState('');
  const [bio, setBio] = useState('');

  // Forgot password
  const [showForgot, setShowForgot] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotMsg, setForgotMsg] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleLoginSubmit(e) {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      setError('Please enter your email and password.');
      return;
    }
    try {
      setLoading(true);
      setError('');
      await login(loginEmail, loginPassword);
      if (onLoginSuccess) onLoginSuccess();
    } catch (err) {
      setError(err.message || 'Invalid credentials. Please check your email and password.');
    } finally {
      setLoading(false);
    }
  }

  async function handleRegisterSubmit(e) {
    e.preventDefault();
    if (!firstName || !lastName || !registerEmail || !registerPassword) {
      setError('First name, last name, email, and password are required.');
      return;
    }
    try {
      setLoading(true);
      setError('');
      await register({
        firstName,
        lastName,
        email: registerEmail,
        password: registerPassword,
        phone,
        city,
        country,
        bio
      });
      if (onLoginSuccess) onLoginSuccess();
    } catch (err) {
      setError(err.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  }

  async function handleDemoTraveler() {
    try {
      setLoading(true);
      setError('');
      await loginAsDemoTraveler();
      if (onLoginSuccess) onLoginSuccess();
    } catch (err) {
      setError(err.message || 'Failed to login as Demo Traveler.');
    } finally {
      setLoading(false);
    }
  }

  async function handleDemoAdmin() {
    try {
      setLoading(true);
      setError('');
      await loginAsDemoAdmin();
      if (onLoginSuccess) onLoginSuccess();
    } catch (err) {
      setError(err.message || 'Failed to login as Demo Admin.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{
      minHeight: '85vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem 1rem',
      background: 'radial-gradient(circle at 10% 20%, rgba(255, 107, 74, 0.08) 0%, rgba(8, 145, 178, 0.06) 90%)'
    }}>
      <div style={{ width: '100%', maxWidth: tab === 'register' ? '680px' : '460px', transition: 'all 0.3s ease' }}>
        {/* Brand Header */}
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{
            width: '54px',
            height: '54px',
            background: 'var(--primary-gradient)',
            borderRadius: 'var(--radius-lg)',
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            boxShadow: 'var(--shadow-coral)',
            marginBottom: '0.75rem'
          }}>
            <Compass size={30} />
          </div>
          <h1 style={{ fontSize: '2rem', fontWeight: 800 }}>GlobeTrotter</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem', marginTop: '0.25rem' }}>
            Empowering Personalized Multi-City Travel Planning
          </p>
        </div>

        {/* Auth Glass Card */}
        <div className="card" style={{ padding: '2rem', boxShadow: 'var(--shadow-xl)', border: '1px solid var(--border-color)' }}>
          {/* Tabs */}
          <div style={{
            display: 'flex',
            background: 'var(--bg-surface-secondary)',
            padding: '4px',
            borderRadius: 'var(--radius-md)',
            marginBottom: '1.75rem'
          }}>
            <button
              onClick={() => { setTab('login'); setError(''); }}
              style={{
                flex: 1,
                padding: '0.65rem 0',
                border: 'none',
                background: tab === 'login' ? 'var(--bg-surface)' : 'transparent',
                color: tab === 'login' ? 'var(--primary-coral)' : 'var(--text-secondary)',
                fontWeight: 700,
                fontSize: '0.9rem',
                borderRadius: 'var(--radius-sm)',
                boxShadow: tab === 'login' ? 'var(--shadow-sm)' : 'none',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
            >
              Sign In
            </button>
            <button
              onClick={() => { setTab('register'); setError(''); }}
              style={{
                flex: 1,
                padding: '0.65rem 0',
                border: 'none',
                background: tab === 'register' ? 'var(--bg-surface)' : 'transparent',
                color: tab === 'register' ? 'var(--primary-coral)' : 'var(--text-secondary)',
                fontWeight: 700,
                fontSize: '0.9rem',
                borderRadius: 'var(--radius-sm)',
                boxShadow: tab === 'register' ? 'var(--shadow-sm)' : 'none',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
            >
              Create Account
            </button>
          </div>

          {error && (
            <div style={{ padding: '0.85rem 1rem', background: '#FEE2E2', color: '#DC2626', borderRadius: 'var(--radius-md)', marginBottom: '1.25rem', fontSize: '0.875rem' }}>
              {error}
            </div>
          )}

          {/* LOGIN FORM */}
          {tab === 'login' && (
            <form onSubmit={handleLoginSubmit}>
              <div className="form-group">
                <label className="form-label">Email Address</label>
                <div style={{ position: 'relative' }}>
                  <input
                    type="email"
                    className="form-input"
                    placeholder="traveler@globetrotter.com"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    required
                    style={{ paddingLeft: '2.5rem' }}
                  />
                  <Mail size={17} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                </div>
              </div>

              <div className="form-group">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <label className="form-label">Password</label>
                  <button
                    type="button"
                    onClick={() => setShowForgot(!showForgot)}
                    style={{ background: 'none', border: 'none', color: 'var(--primary-coral)', fontSize: '0.8rem', fontWeight: 600, cursor: 'pointer' }}
                  >
                    Forgot Password?
                  </button>
                </div>
                <div style={{ position: 'relative' }}>
                  <input
                    type="password"
                    className="form-input"
                    placeholder="••••••••"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    required
                    style={{ paddingLeft: '2.5rem' }}
                  />
                  <Lock size={17} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                </div>
              </div>

              {/* Forgot password helper */}
              {showForgot && (
                <div style={{ padding: '1rem', background: 'var(--bg-surface-secondary)', borderRadius: 'var(--radius-md)', marginBottom: '1.25rem', fontSize: '0.85rem' }}>
                  <p style={{ fontWeight: 600, marginBottom: '0.5rem' }}>Password Recovery:</p>
                  <p style={{ color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>
                    Demo accounts use default password: <code>password123</code> (traveler) and <code>admin123</code> (admin).
                  </p>
                </div>
              )}

              <button
                type="submit"
                className="btn btn-primary btn-lg"
                disabled={loading}
                style={{ width: '100%', marginTop: '0.5rem' }}
              >
                <span>{loading ? 'Authenticating...' : 'Sign In to GlobeTrotter'}</span>
                <ArrowRight size={18} />
              </button>
            </form>
          )}

          {/* REGISTER FORM */}
          {tab === 'register' && (
            <form onSubmit={handleRegisterSubmit}>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">First Name *</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="Alex"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    required
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Last Name *</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="Morgan"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Email Address *</label>
                  <input
                    type="email"
                    className="form-input"
                    placeholder="alex@example.com"
                    value={registerEmail}
                    onChange={(e) => setRegisterEmail(e.target.value)}
                    required
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Password * (min 6 chars)</label>
                  <input
                    type="password"
                    className="form-input"
                    placeholder="••••••••"
                    value={registerPassword}
                    onChange={(e) => setRegisterPassword(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Phone Number</label>
                  <input
                    type="tel"
                    className="form-input"
                    placeholder="+1 (555) 000-0000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">City</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="San Francisco"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Country</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="United States"
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Bio / Travel Philosophy</label>
                <textarea
                  className="form-textarea"
                  placeholder="Tell fellow travelers what you love about exploring..."
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  style={{ minHeight: '70px' }}
                />
              </div>

              <button
                type="submit"
                className="btn btn-primary btn-lg"
                disabled={loading}
                style={{ width: '100%', marginTop: '0.5rem' }}
              >
                <span>{loading ? 'Creating Account...' : 'Register & Start Planning'}</span>
                <ArrowRight size={18} />
              </button>
            </form>
          )}

          {/* Quick Demo Access Bar */}
          <div style={{ marginTop: '1.75rem', paddingTop: '1.5rem', borderTop: '1px solid var(--border-color)', textAlign: 'center' }}>
            <p style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.85rem' }}>
              ⚡ 1-Click Instant Demo Access
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              <button
                type="button"
                className="btn btn-outline btn-sm"
                onClick={handleDemoTraveler}
                disabled={loading}
                style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem' }}
              >
                <Sparkles size={15} color="var(--primary-coral)" />
                <span>Demo Traveler</span>
              </button>
              <button
                type="button"
                className="btn btn-outline btn-sm"
                onClick={handleDemoAdmin}
                disabled={loading}
                style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem' }}
              >
                <ShieldCheck size={15} color="var(--accent-indigo)" />
                <span>Demo Admin</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
