import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Users, 
  Map, 
  DollarSign, 
  TrendingUp, 
  RefreshCw, 
  BarChart2, 
  Activity, 
  UserCheck, 
  UserX,
  AlertCircle
} from 'lucide-react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import BarChart from '../components/charts/BarChart';
import LoadingSpinner from '../components/common/LoadingSpinner';

export default function AdminDashboardPage({ showToast }) {
  const { user, isAdmin } = useAuth();
  const { formatAmount } = useCurrency();
  const [analytics, setAnalytics] = useState(null);
  const [usersList, setUsersList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reseeding, setReseeding] = useState(false);

  async function loadAdminData() {
    try {
      setLoading(true);
      const [anRes, userRes] = await Promise.all([
        api.admin.getAnalytics(),
        api.admin.listUsers()
      ]);
      setAnalytics(anRes);
      setUsersList(userRes.users || []);
    } catch (err) {
      console.error('Failed to load admin analytics:', err);
      showToast(err.message || 'Failed to load admin dashboard', 'error');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (isAdmin) loadAdminData();
  }, [isAdmin]);

  async function handleToggleUserRole(userId, currentRole) {
    const newRole = currentRole === 'admin' ? 'user' : 'admin';
    try {
      await api.admin.updateUserRole(userId, newRole);
      showToast(`User role updated to ${newRole}`, 'success');
      loadAdminData();
    } catch (err) {
      showToast(err.message || 'Failed to update user role', 'error');
    }
  }

  async function handleResetDatabase() {
    if (!window.confirm('Are you sure you want to reset and re-seed the SQLite database with pristine demo records?')) return;
    try {
      setReseeding(true);
      const res = await api.admin.resetDatabase();
      showToast(res.message, 'success');
      loadAdminData();
    } catch (err) {
      showToast(err.message || 'Failed to reset database', 'error');
    } finally {
      setReseeding(false);
    }
  }

  if (!isAdmin) {
    return (
      <div className="container" style={{ padding: '4rem 1rem', textAlign: 'center' }}>
        <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: '#FEE2E2', color: '#DC2626', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1.5rem' }}>
          <AlertCircle size={32} />
        </div>
        <h2 style={{ fontSize: '1.6rem', fontWeight: 800 }}>Admin Access Required</h2>
        <p style={{ color: 'var(--text-secondary)', marginTop: '0.5rem' }}>
          This page is restricted to platform administrators. Please sign in with an admin account.
        </p>
      </div>
    );
  }

  if (loading || !analytics) return <LoadingSpinner message="Loading platform analytics & user management..." />;

  const { metrics, topCities = [], categoryStats = [], travelStyles = [], recentTrips = [] } = analytics;

  // Format top cities for bar chart
  const topCitiesChartData = topCities.map(c => ({
    label: c.name,
    count: c.visit_count,
    title: `${c.name} (${c.country})`
  }));

  return (
    <div className="container-wide" style={{ paddingBottom: '4rem' }}>
      {/* Header */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '1rem', margin: '2rem 0 2rem' }}>
        <div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', padding: '0.25rem 0.65rem', background: 'rgba(109, 93, 211, 0.12)', color: 'var(--accent-indigo)', borderRadius: 'var(--radius-full)', fontSize: '0.8rem', fontWeight: 700, marginBottom: '0.5rem' }}>
            <ShieldCheck size={14} />
            <span>Platform Administration & Analytics</span>
          </div>
          <h1 style={{ fontSize: '2.3rem', fontWeight: 800 }}>Platform Intelligence Dashboard</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
            Monitor application adoption, top destination trends, user accounts, and platform health.
          </p>
        </div>

        <button 
          className="btn btn-secondary btn-sm" 
          onClick={handleResetDatabase}
          disabled={reseeding}
        >
          <RefreshCw size={15} className={reseeding ? 'spin' : ''} />
          <span>{reseeding ? 'Reseeding Database...' : 'Reset / Reseed Sample Database'}</span>
        </button>
      </div>

      {/* Platform KPIs */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.25rem', marginBottom: '2.5rem' }}>
        <div className="card" style={{ padding: '1.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Registered Users</span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--text-primary)', marginTop: '0.25rem' }}>
            {metrics.totalUsers}
          </div>
        </div>

        <div className="card" style={{ padding: '1.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Total Itineraries</span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--primary-coral)', marginTop: '0.25rem' }}>
            {metrics.totalTrips}
          </div>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{metrics.totalPublicTrips} Public</span>
        </div>

        <div className="card" style={{ padding: '1.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Total Stops & Cities</span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--secondary-teal)', marginTop: '0.25rem' }}>
            {metrics.totalStops}
          </div>
        </div>

        <div className="card" style={{ padding: '1.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Scheduled Experiences</span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent-indigo)', marginTop: '0.25rem' }}>
            {metrics.totalScheduledActivities}
          </div>
        </div>

        <div className="card" style={{ padding: '1.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>Total Budget Tracked</span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent-emerald)', marginTop: '0.25rem' }}>
            {formatAmount(metrics.totalBudgetTracked)}
          </div>
        </div>
      </div>

      {/* Analytics Charts */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '2rem', marginBottom: '3rem' }}>
        {/* Top Booked Destinations Bar Chart */}
        <div className="card" style={{ padding: '1.75rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.25rem' }}>
            <BarChart2 size={20} color="var(--primary-coral)" />
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800 }}>Top Destination Cities by Route Inclusions</h3>
          </div>
          <BarChart data={topCitiesChartData} height={200} barColor="var(--primary-coral)" />
        </div>

        {/* Activity Category Breakdown */}
        <div className="card" style={{ padding: '1.75rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.25rem' }}>
            <Activity size={20} color="var(--accent-indigo)" />
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800 }}>Experience Category Popularity</h3>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {categoryStats.map(cat => (
              <div key={cat.category} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.5rem 0.75rem', background: 'var(--bg-surface-secondary)', borderRadius: 'var(--radius-sm)' }}>
                <span style={{ fontWeight: 700, fontSize: '0.85rem' }}>{cat.category}</span>
                <span className="badge badge-indigo">{cat.count} scheduled</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* User Management Table */}
      <div className="card" style={{ padding: '1.75rem', marginBottom: '3rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.25rem' }}>
          <Users size={20} color="var(--secondary-teal)" />
          <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>Platform Registered Users ({usersList.length})</h3>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.9rem' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid var(--border-color)', color: 'var(--text-muted)', fontSize: '0.8rem', textTransform: 'uppercase' }}>
                <th style={{ padding: '0.75rem 1rem' }}>User</th>
                <th style={{ padding: '0.75rem 1rem' }}>Email</th>
                <th style={{ padding: '0.75rem 1rem' }}>Location</th>
                <th style={{ padding: '0.75rem 1rem' }}>Itineraries</th>
                <th style={{ padding: '0.75rem 1rem' }}>Role</th>
                <th style={{ padding: '0.75rem 1rem', textAlign: 'center' }}>Role Action</th>
              </tr>
            </thead>
            <tbody>
              {usersList.map(u => (
                <tr key={u.id} style={{ borderBottom: '1px solid var(--border-color)' }}>
                  <td style={{ padding: '0.85rem 1rem', display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                    <img src={u.avatarUrl} alt="" style={{ width: '32px', height: '32px', borderRadius: '50%', objectFit: 'cover' }} />
                    <span style={{ fontWeight: 700 }}>{u.name}</span>
                  </td>
                  <td style={{ padding: '0.85rem 1rem', color: 'var(--text-secondary)' }}>{u.email}</td>
                  <td style={{ padding: '0.85rem 1rem', color: 'var(--text-muted)' }}>{u.location || '—'}</td>
                  <td style={{ padding: '0.85rem 1rem', fontWeight: 700 }}>{u.tripsCount}</td>
                  <td style={{ padding: '0.85rem 1rem' }}>
                    <span className={`badge ${u.role === 'admin' ? 'badge-indigo' : 'badge-gray'}`}>
                      {u.role}
                    </span>
                  </td>
                  <td style={{ padding: '0.85rem 1rem', textAlign: 'center' }}>
                    <button
                      className="btn btn-outline btn-sm"
                      onClick={() => handleToggleUserRole(u.id, u.role)}
                      style={{ fontSize: '0.75rem' }}
                    >
                      {u.role === 'admin' ? 'Demote to User' : 'Promote to Admin'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Trips Audit Log */}
      <div className="card" style={{ padding: '1.75rem' }}>
        <h3 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '1rem' }}>Recent Platform Activity Feed</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
          {recentTrips.map(r => (
            <div key={r.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.75rem 1rem', background: 'var(--bg-surface-secondary)', borderRadius: 'var(--radius-md)', fontSize: '0.85rem' }}>
              <div>
                <strong>{r.title}</strong>
                <span style={{ color: 'var(--text-muted)', marginLeft: '0.5rem' }}>created by {r.author}</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <span style={{ fontWeight: 700 }}>{formatAmount(r.budget)}</span>
                <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>{r.createdAt?.slice(0, 10)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
