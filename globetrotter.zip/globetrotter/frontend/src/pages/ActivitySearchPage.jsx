import React, { useState, useEffect } from 'react';
import { Sparkles, Search, Filter, Clock, Star, MapPin, Plus, DollarSign } from 'lucide-react';
import api from '../services/api';
import { useCurrency } from '../context/CurrencyContext';
import ActivityCard from '../components/cards/ActivityCard';
import AddActivityModal from '../components/forms/AddActivityModal';
import LoadingSpinner from '../components/common/LoadingSpinner';
import CityAutocomplete from '../components/common/CityAutocomplete';

const CATEGORIES = ['All', 'Sightseeing', 'Culinary', 'Adventure', 'Culture', 'Relaxation', 'Nightlife'];

export default function ActivitySearchPage({ showToast }) {
  const { formatAmount } = useCurrency();
  const [activities, setActivities] = useState([]);
  const [trips, setTrips] = useState([]);
  
  // Filters
  const [selectedCityId, setSelectedCityId] = useState('');
  const [selectedCityLabel, setSelectedCityLabel] = useState('');
  const [category, setCategory] = useState('All');
  const [maxPrice, setMaxPrice] = useState('150');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  // Schedule activity modal state
  const [schedulingActivity, setSchedulingActivity] = useState(null);
  const [targetTripId, setTargetTripId] = useState('');
  const [selectedTripStops, setSelectedTripStops] = useState([]);
  const [targetStopId, setTargetStopId] = useState('');

  async function fetchData() {
    try {
      setLoading(true);
      const [actRes, tripsRes] = await Promise.all([
        api.activities.list({
          cityId: selectedCityId || undefined,
          category: category !== 'All' ? category : undefined,
          maxPrice: maxPrice || undefined,
          search: searchQuery || undefined
        }),
        api.trips.list()
      ]);
      setActivities(actRes.activities || []);
      setTrips(tripsRes.trips || []);
    } catch (err) {
      console.error('Failed to load activities catalog:', err);
      showToast('Failed to load activities', 'error');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchData();
  }, [selectedCityId, category, maxPrice]);

  function handleSearchSubmit(e) {
    e.preventDefault();
    fetchData();
  }

  async function handleOpenSchedule(activity) {
    setSchedulingActivity(activity);
    if (trips.length > 0) {
      const firstTrip = trips[0];
      setTargetTripId(firstTrip.id);
      try {
        const fullTrip = await api.trips.getById(firstTrip.id);
        setSelectedTripStops(fullTrip.stops || []);
        if (fullTrip.stops && fullTrip.stops.length > 0) {
          setTargetStopId(fullTrip.stops[0].id);
        }
      } catch {
        setSelectedTripStops([]);
      }
    }
  }

  async function handleTripChange(newTripId) {
    setTargetTripId(newTripId);
    try {
      const fullTrip = await api.trips.getById(newTripId);
      setSelectedTripStops(fullTrip.stops || []);
      if (fullTrip.stops && fullTrip.stops.length > 0) {
        setTargetStopId(fullTrip.stops[0].id);
      } else {
        setTargetStopId('');
      }
    } catch {
      setSelectedTripStops([]);
      setTargetStopId('');
    }
  }

  async function handleConfirmSchedule(payload) {
    try {
      if (!targetStopId) {
        showToast('Please select a trip stop to add this activity to.', 'error');
        return;
      }
      await api.activities.schedule({
        ...payload,
        tripStopId: Number(targetStopId),
        activityId: schedulingActivity.id,
        customTitle: schedulingActivity.title,
        category: schedulingActivity.category,
        cost: schedulingActivity.price
      });
      showToast(`Scheduled "${schedulingActivity.title}" into your itinerary!`, 'success');
      setSchedulingActivity(null);
    } catch (err) {
      showToast(err.message || 'Failed to schedule activity', 'error');
    }
  }

  return (
    <div className="container-wide" style={{ paddingBottom: '3.5rem' }}>
      {/* Header */}
      <div style={{ margin: '2rem 0 1.5rem' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', padding: '0.25rem 0.65rem', background: 'rgba(109, 93, 211, 0.1)', color: 'var(--accent-indigo)', borderRadius: 'var(--radius-full)', fontSize: '0.8rem', fontWeight: 700, marginBottom: '0.5rem' }}>
          <Sparkles size={14} />
          <span>Curated Travel Experiences</span>
        </div>
        <h1 style={{ fontSize: '2.3rem', fontWeight: 800 }}>Explore Things to Do & Activities</h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
          Sightseeing passes, local culinary masterclasses, private museum tours, and outdoor adventures.
        </p>
      </div>

      {/* Filter Bar */}
      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        gap: '1rem',
        alignItems: 'center',
        background: 'var(--bg-surface)',
        padding: '1.25rem',
        borderRadius: 'var(--radius-xl)',
        border: '1px solid var(--border-color)',
        boxShadow: 'var(--shadow-sm)',
        marginBottom: '2rem'
      }}>
        {/* Search */}
        <form onSubmit={handleSearchSubmit} style={{ flex: 1, minWidth: '220px', position: 'relative' }}>
          <input
            type="text"
            className="form-input"
            placeholder="Search activities or keywords..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{ paddingLeft: '2.5rem' }}
          />
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
        </form>

        {/* City Filter — worldwide search-as-you-type, no giant dropdown */}
        <CityAutocomplete
          selectedLabel={selectedCityLabel ? `${selectedCityLabel}` : ''}
          placeholder="All Destinations — search any city..."
          onSelect={(city) => {
            setSelectedCityId(String(city.id));
            setSelectedCityLabel(`${city.name} (${city.country})`);
          }}
          onClear={() => {
            setSelectedCityId('');
            setSelectedCityLabel('');
          }}
        />

        {/* Price Slider */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', minWidth: '200px' }}>
          <span style={{ fontSize: '0.825rem', fontWeight: 600, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
            Max: {formatAmount(maxPrice)}
          </span>
          <input
            type="range"
            min="0"
            max="200"
            step="10"
            value={maxPrice}
            onChange={(e) => setMaxPrice(e.target.value)}
            style={{ width: '100%', accentColor: 'var(--primary-coral)' }}
          />
        </div>
      </div>

      {/* Category Tabs */}
      <div style={{ display: 'flex', gap: '0.5rem', overflowX: 'auto', paddingBottom: '0.75rem', marginBottom: '1.5rem' }}>
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setCategory(cat)}
            className={`btn btn-sm ${category === cat ? 'btn-primary' : 'btn-outline'}`}
            style={{ borderRadius: 'var(--radius-full)', padding: '0.4rem 1.1rem', whiteSpace: 'nowrap' }}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Activities Grid */}
      {loading ? (
        <LoadingSpinner message="Curating experiences catalog..." />
      ) : activities.length > 0 ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1.75rem' }}>
          {activities.map(act => (
            <ActivityCard
              key={act.id}
              activity={act}
              onSchedule={handleOpenSchedule}
            />
          ))}
        </div>
      ) : (
        <div className="card" style={{ padding: '3.5rem 2rem', textAlign: 'center' }}>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>No Activities Match Your Filters</h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', margin: '0.5rem 0 1.5rem' }}>
            Try adjusting your maximum price slider or changing the category filter.
          </p>
          <button className="btn btn-primary" onClick={() => { setCategory('All'); setSelectedCityId(''); setSelectedCityLabel(''); setMaxPrice('150'); setSearchQuery(''); }}>
            Reset Filters
          </button>
        </div>
      )}

      {/* Schedule Activity Modal */}
      {schedulingActivity && (
        <div className="modal-backdrop" onClick={() => setSchedulingActivity(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3 className="modal-title">Schedule "{schedulingActivity.title}"</h3>
              <button className="btn-ghost btn-icon-sm" onClick={() => setSchedulingActivity(null)}>✕</button>
            </div>
            <div className="modal-body">
              {trips.length > 0 ? (
                <div>
                  <div className="form-group">
                    <label className="form-label">Select Target Trip</label>
                    <select
                      className="form-select"
                      value={targetTripId}
                      onChange={(e) => handleTripChange(e.target.value)}
                    >
                      {trips.map(t => (
                        <option key={t.id} value={t.id}>{t.title} ({t.startDate})</option>
                      ))}
                    </select>
                  </div>

                  {selectedTripStops.length > 0 ? (
                    <div className="form-group">
                      <label className="form-label">Select Destination Stop</label>
                      <select
                        className="form-select"
                        value={targetStopId}
                        onChange={(e) => setTargetStopId(e.target.value)}
                      >
                        {selectedTripStops.map(s => (
                          <option key={s.id} value={s.id}>
                            {s.cityName} ({s.arrivalDate} to {s.departureDate})
                          </option>
                        ))}
                      </select>
                    </div>
                  ) : (
                    <p style={{ color: '#DC2626', fontSize: '0.875rem', marginBottom: '1rem' }}>
                      This trip doesn't have any stops yet. Please add a city stop first in the Itinerary Builder.
                    </p>
                  )}

                  <AddActivityModal
                    isOpen={true}
                    onClose={() => setSchedulingActivity(null)}
                    onScheduleActivity={handleConfirmSchedule}
                    tripStopId={Number(targetStopId)}
                    cityName={schedulingActivity.cityName}
                    totalDays={4}
                    prefilledActivity={schedulingActivity}
                  />
                </div>
              ) : (
                <div style={{ textAlign: 'center', padding: '1.5rem 0' }}>
                  <p style={{ marginBottom: '1rem' }}>You don't have any trips created yet.</p>
                  <button className="btn btn-primary" onClick={() => setSchedulingActivity(null)}>
                    Create a Trip First
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
