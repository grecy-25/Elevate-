import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  MapPin, 
  Calendar, 
  Clock, 
  DollarSign, 
  Trash2, 
  ChevronDown, 
  ChevronUp, 
  ArrowRight, 
  Eye, 
  CheckCircle2, 
  Circle, 
  Building2, 
  Plane, 
  FileText,
  Sparkles,
  Share2
} from 'lucide-react';
import api from '../services/api';
import { useCurrency } from '../context/CurrencyContext';
import AddStopModal from '../components/forms/AddStopModal';
import AddActivityModal from '../components/forms/AddActivityModal';
import LoadingSpinner from '../components/common/LoadingSpinner';

export default function ItineraryBuilderPage({
  tripId,
  onViewTrip,
  onBudgetTrip,
  onNavigate,
  showToast
}) {
  const { formatAmount } = useCurrency();
  const [tripData, setTripData] = useState(null);
  const [cities, setCities] = useState([]);
  const [loading, setLoading] = useState(true);

  // Modals state
  const [showAddStop, setShowAddStop] = useState(false);
  const [activeStopForActivity, setActiveStopForActivity] = useState(null);
  const [selectedCityActivities, setSelectedCityActivities] = useState([]);

  // Expanded stops accordion
  const [expandedStops, setExpandedStops] = useState({});

  async function loadTripHierarchy() {
    try {
      setLoading(true);
      const [tripRes, citiesRes] = await Promise.all([
        api.trips.getById(tripId),
        api.cities.list()
      ]);
      setTripData(tripRes);
      setCities(citiesRes.cities || []);

      // Auto-expand all stops initially
      const initialExpanded = {};
      if (tripRes.stops) {
        tripRes.stops.forEach(s => { initialExpanded[s.id] = true; });
      }
      setExpandedStops(initialExpanded);
    } catch (err) {
      console.error('Failed to load trip builder:', err);
      showToast('Failed to load trip details', 'error');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (tripId) loadTripHierarchy();
  }, [tripId]);

  function toggleStopExpand(stopId) {
    setExpandedStops(prev => ({ ...prev, [stopId]: !prev[stopId] }));
  }

  async function handleAddStop(stopPayload) {
    try {
      await api.stops.add({ ...stopPayload, tripId });
      showToast('New stop added to your itinerary!', 'success');
      loadTripHierarchy();
    } catch (err) {
      showToast(err.message || 'Failed to add stop', 'error');
    }
  }

  async function handleDeleteStop(stopId) {
    if (!window.confirm('Delete this stop and all its scheduled activities?')) return;
    try {
      await api.stops.delete(stopId);
      showToast('Stop removed from route', 'info');
      loadTripHierarchy();
    } catch (err) {
      showToast('Failed to delete stop', 'error');
    }
  }

  async function handleOpenAddActivity(stop) {
    setActiveStopForActivity(stop);
    try {
      const res = await api.activities.getByCity(stop.cityId);
      setSelectedCityActivities(res.activities || []);
    } catch {
      setSelectedCityActivities([]);
    }
  }

  async function handleScheduleActivity(actPayload) {
    try {
      await api.activities.schedule(actPayload);
      showToast('Activity scheduled into day plan!', 'success');
      loadTripHierarchy();
    } catch (err) {
      showToast(err.message || 'Failed to schedule activity', 'error');
    }
  }

  async function handleToggleComplete(activityId, currentStatus) {
    try {
      await api.activities.updateScheduled(activityId, { isCompleted: !currentStatus });
      loadTripHierarchy();
    } catch (err) {
      showToast('Failed to update activity status', 'error');
    }
  }

  async function handleDeleteActivity(activityId) {
    try {
      await api.activities.deleteScheduled(activityId);
      showToast('Activity removed from schedule', 'info');
      loadTripHierarchy();
    } catch (err) {
      showToast('Failed to delete activity', 'error');
    }
  }

  if (loading || !tripData) return <LoadingSpinner message="Opening your trip builder..." />;

  const { trip, stops = [], budget } = tripData;

  return (
    <div className="container-wide" style={{ paddingBottom: '4rem' }}>
      {/* Top Header & Quick Actions */}
      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '1rem',
        margin: '1.5rem 0 2rem',
        paddingBottom: '1.5rem',
        borderBottom: '1px solid var(--border-color)'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: '0.4rem' }}>
            <span className="badge badge-coral">{trip.travelStyle}</span>
            <span className="badge badge-teal">{stops.length} Cities</span>
            <span className="badge badge-indigo">{trip.startDate} to {trip.endDate}</span>
          </div>
          <h1 style={{ fontSize: '2.2rem', fontWeight: 800 }}>{trip.title}</h1>
          {trip.description && (
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.925rem', maxWidth: '650px', marginTop: '0.25rem' }}>
              {trip.description}
            </p>
          )}
        </div>

        <div style={{ display: 'flex', gap: '0.65rem', flexWrap: 'wrap' }}>
          <button className="btn btn-outline" onClick={() => onBudgetTrip(trip.id)}>
            <DollarSign size={16} />
            <span>Budget & Expenses</span>
          </button>
          <button className="btn btn-primary" onClick={() => onViewTrip(trip.id)}>
            <Eye size={16} />
            <span>View Final Itinerary</span>
          </button>
        </div>
      </div>

      {/* Main Builder Grid: Left Stops & Days, Right Financial Quick Summary */}
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 2.5fr) minmax(0, 1fr)', gap: '2rem' }}>
        {/* Left Column: Route Stops Accordion & Day Scheduler */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
            <h2 style={{ fontSize: '1.4rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span>Journey Route & Day Schedule</span>
            </h2>
            <button className="btn btn-secondary btn-sm" onClick={() => setShowAddStop(true)}>
              <Plus size={16} />
              <span>Add City Stop</span>
            </button>
          </div>

          {stops.length > 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {stops.map((stop, stopIdx) => {
                const isExpanded = expandedStops[stop.id];
                const start = new Date(stop.arrivalDate);
                const end = new Date(stop.departureDate);
                const stopDays = Math.max(1, Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1);

                // Group activities by day number
                const activitiesByDay = {};
                for (let d = 1; d <= stopDays; d++) activitiesByDay[d] = [];
                (stop.activities || []).forEach(act => {
                  const d = act.dayNumber || 1;
                  if (!activitiesByDay[d]) activitiesByDay[d] = [];
                  activitiesByDay[d].push(act);
                });

                return (
                  <div 
                    key={stop.id} 
                    className="card" 
                    style={{ 
                      border: '1.5px solid var(--border-color)',
                      boxShadow: 'var(--shadow-md)',
                      borderRadius: 'var(--radius-xl)',
                      overflow: 'hidden'
                    }}
                  >
                    {/* Stop Header Banner */}
                    <div style={{
                      padding: '1.25rem 1.5rem',
                      background: 'linear-gradient(90deg, var(--bg-surface-secondary) 0%, var(--bg-surface) 100%)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      cursor: 'pointer',
                      borderBottom: isExpanded ? '1px solid var(--border-color)' : 'none'
                    }} onClick={() => toggleStopExpand(stop.id)}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                        {/* Stop Number Circle */}
                        <div style={{
                          width: '38px',
                          height: '38px',
                          borderRadius: '50%',
                          background: 'var(--primary-gradient)',
                          color: 'white',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontWeight: 800,
                          fontSize: '1.1rem',
                          boxShadow: 'var(--shadow-coral)'
                        }}>
                          {stopIdx + 1}
                        </div>

                        {/* City thumbnail */}
                        <img
                          src={stop.cityImage}
                          alt={stop.cityName}
                          style={{ width: '56px', height: '56px', borderRadius: 'var(--radius-md)', objectFit: 'cover' }}
                        />

                        <div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>{stop.cityName}, {stop.cityCountry}</h3>
                            <span className="badge badge-teal">{stopDays} Days</span>
                          </div>
                          <p style={{ fontSize: '0.825rem', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: '0.35rem', marginTop: '0.15rem' }}>
                            <Calendar size={13} color="var(--accent-indigo)" />
                            <span>{stop.arrivalDate} to {stop.departureDate}</span>
                            <span>•</span>
                            <Building2 size={13} />
                            <span>{stop.accommodationName || 'Lodging'}</span>
                          </p>
                        </div>
                      </div>

                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <button
                          type="button"
                          className="btn-outline btn-icon-sm"
                          title="Delete Stop"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteStop(stop.id);
                          }}
                          style={{ color: '#DC2626' }}
                        >
                          <Trash2 size={15} />
                        </button>

                        <button type="button" className="btn-ghost btn-icon-sm">
                          {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                        </button>
                      </div>
                    </div>

                    {/* Stop Details & Day Scheduler */}
                    {isExpanded && (
                      <div style={{ padding: '1.5rem' }}>
                        {/* Transit & Lodging Quick Badges */}
                        <div style={{
                          display: 'flex',
                          flexWrap: 'wrap',
                          gap: '1rem',
                          padding: '0.85rem 1.25rem',
                          background: 'var(--bg-surface-secondary)',
                          borderRadius: 'var(--radius-md)',
                          marginBottom: '1.5rem',
                          fontSize: '0.85rem'
                        }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                            <Building2 size={16} color="var(--primary-coral)" />
                            <strong style={{ color: 'var(--text-secondary)' }}>Lodging:</strong>
                            <span>{stop.accommodationName}</span>
                            <span style={{ fontWeight: 700, color: 'var(--text-primary)' }}>({formatAmount(stop.accommodationCost)})</span>
                          </div>

                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                            <Plane size={16} color="var(--accent-indigo)" />
                            <strong style={{ color: 'var(--text-secondary)' }}>Transit In:</strong>
                            <span>{stop.transportMode}</span>
                            <span style={{ fontWeight: 700, color: 'var(--text-primary)' }}>({formatAmount(stop.transportCost)})</span>
                          </div>

                          {stop.notes && (
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', width: '100%' }}>
                              <FileText size={14} color="var(--text-muted)" />
                              <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>{stop.notes}</span>
                            </div>
                          )}
                        </div>

                        {/* Day-by-Day Grid inside this Stop */}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                          {Object.keys(activitiesByDay).map(dayKey => {
                            const dayNum = Number(dayKey);
                            const acts = activitiesByDay[dayKey] || [];

                            // Calculate actual date
                            const dayDate = new Date(start);
                            dayDate.setDate(dayDate.getDate() + (dayNum - 1));
                            const dateLabel = dayDate.toLocaleDateString(undefined, { month: 'short', day: 'numeric', weekday: 'short' });

                            return (
                              <div key={dayNum} style={{
                                border: '1px solid var(--border-color)',
                                borderRadius: 'var(--radius-lg)',
                                padding: '1rem 1.25rem',
                                background: 'var(--bg-surface)'
                              }}>
                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                                    <span style={{
                                      fontSize: '0.85rem',
                                      fontWeight: 800,
                                      background: 'var(--dark-navy)',
                                      color: 'white',
                                      padding: '0.2rem 0.6rem',
                                      borderRadius: 'var(--radius-sm)'
                                    }}>
                                      Day {dayNum}
                                    </span>
                                    <span style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-secondary)' }}>
                                      {dateLabel}
                                    </span>
                                  </div>

                                  <button
                                    className="btn btn-outline btn-sm"
                                    onClick={() => handleOpenAddActivity(stop)}
                                    style={{ fontSize: '0.775rem', padding: '0.25rem 0.65rem' }}
                                  >
                                    <Plus size={13} />
                                    <span>Schedule Activity</span>
                                  </button>
                                </div>

                                {/* Scheduled Activities list for this day */}
                                {acts.length > 0 ? (
                                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                                    {acts.map(act => (
                                      <div
                                        key={act.id}
                                        style={{
                                          display: 'flex',
                                          alignItems: 'center',
                                          justifyContent: 'space-between',
                                          padding: '0.65rem 0.85rem',
                                          background: act.isCompleted ? 'rgba(20, 167, 108, 0.06)' : 'var(--bg-surface-secondary)',
                                          borderRadius: 'var(--radius-md)',
                                          borderLeft: `4px solid ${act.isCompleted ? 'var(--accent-emerald)' : 'var(--primary-coral)'}`,
                                          transition: 'all 0.2s ease'
                                        }}
                                      >
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                                          <button
                                            onClick={() => handleToggleComplete(act.id, act.isCompleted)}
                                            style={{ background: 'none', border: 'none', cursor: 'pointer', color: act.isCompleted ? 'var(--accent-emerald)' : 'var(--text-muted)' }}
                                            title={act.isCompleted ? 'Mark as pending' : 'Mark as completed'}
                                          >
                                            {act.isCompleted ? <CheckCircle2 size={18} /> : <Circle size={18} />}
                                          </button>

                                          <div>
                                            <div style={{
                                              fontWeight: 700,
                                              fontSize: '0.9rem',
                                              textDecoration: act.isCompleted ? 'line-through' : 'none',
                                              color: act.isCompleted ? 'var(--text-muted)' : 'var(--text-primary)'
                                            }}>
                                              {act.title}
                                            </div>
                                            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '0.1rem' }}>
                                              <span style={{ display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
                                                <Clock size={12} />
                                                {act.startTime} ({act.durationMins}m)
                                              </span>
                                              <span>•</span>
                                              <span className="badge badge-coral" style={{ fontSize: '0.65rem', padding: '0.1rem 0.35rem' }}>
                                                {act.category}
                                              </span>
                                              {act.notes && <span>• {act.notes}</span>}
                                            </div>
                                          </div>
                                        </div>

                                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                                          <span style={{ fontWeight: 700, fontSize: '0.9rem', color: 'var(--text-primary)' }}>
                                            {act.cost === 0 ? 'Free' : formatAmount(act.cost)}
                                          </span>
                                          <button
                                            onClick={() => handleDeleteActivity(act.id)}
                                            style={{ background: 'none', border: 'none', color: '#DC2626', cursor: 'pointer', opacity: 0.7 }}
                                            title="Delete Activity"
                                          >
                                            <Trash2 size={14} />
                                          </button>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                ) : (
                                  <div style={{ padding: '0.85rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.8rem', background: 'var(--bg-surface-secondary)', borderRadius: 'var(--radius-sm)' }}>
                                    No activities scheduled for Day {dayNum}. Click "+ Schedule Activity" to add sights, food tours, or hikes.
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="card" style={{ padding: '3rem 2rem', textAlign: 'center' }}>
              <div style={{ width: '54px', height: '54px', borderRadius: '50%', background: 'rgba(255, 107, 74, 0.1)', color: 'var(--primary-coral)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1rem' }}>
                <MapPin size={28} />
              </div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 700 }}>No Route Stops Added Yet</h3>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', maxWidth: '380px', margin: '0.5rem auto 1.5rem' }}>
                Add your first city stop to begin scheduling day-by-day activities and tracking travel dates.
              </p>
              <button className="btn btn-primary" onClick={() => setShowAddStop(true)}>
                <Plus size={16} />
                <span>Add First City Stop</span>
              </button>
            </div>
          )}
        </div>

        {/* Right Column: Dynamic Budget & Summary Card */}
        <div>
          <div className="card" style={{ padding: '1.5rem', position: 'sticky', top: '90px' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '1rem' }}>Trip Cost Estimate</h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.25rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.875rem' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Accommodation</span>
                <strong>{formatAmount(budget.categories?.accommodation || 0)}</strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.875rem' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Transit / Flights</span>
                <strong>{formatAmount(budget.categories?.transport || 0)}</strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.875rem' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Scheduled Activities</span>
                <strong>{formatAmount(budget.categories?.activities || 0)}</strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.875rem' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Dining & Misc</span>
                <strong>{formatAmount((budget.categories?.dining || 0) + (budget.categories?.miscellaneous || 0))}</strong>
              </div>
            </div>

            <div style={{ borderTop: '2px dashed var(--border-color)', paddingTop: '1rem', marginBottom: '1.25rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1.1rem', fontWeight: 800 }}>
                <span>Total Estimated</span>
                <span style={{ color: budget.isOverbudget ? 'var(--accent-rose)' : 'var(--primary-coral)' }}>
                  {formatAmount(budget.totalSpent)}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '0.25rem' }}>
                <span>Allocated Budget</span>
                <span>{formatAmount(budget.allocated)}</span>
              </div>
            </div>

            {/* Budget Bar */}
            <div style={{ height: '8px', background: 'var(--bg-surface-secondary)', borderRadius: 'var(--radius-full)', overflow: 'hidden', marginBottom: '1.5rem' }}>
              <div style={{
                height: '100%',
                width: `${Math.min(100, budget.percentUtilized)}%`,
                background: budget.isOverbudget ? 'var(--accent-rose)' : 'var(--primary-gradient)',
                borderRadius: 'var(--radius-full)'
              }} />
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
              <button className="btn btn-primary" onClick={() => onViewTrip(trip.id)} style={{ width: '100%' }}>
                <span>Preview Final Itinerary</span>
                <ArrowRight size={16} />
              </button>
              <button className="btn btn-outline" onClick={() => onBudgetTrip(trip.id)} style={{ width: '100%' }}>
                <span>Full Financial Breakdown</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Add Stop Modal */}
      <AddStopModal
        isOpen={showAddStop}
        onClose={() => setShowAddStop(false)}
        onAddStop={handleAddStop}
        cities={cities}
        defaultStartDate={trip.startDate}
        defaultEndDate={trip.endDate}
      />

      {/* Add Activity Modal */}
      {activeStopForActivity && (
        <AddActivityModal
          isOpen={!!activeStopForActivity}
          onClose={() => setActiveStopForActivity(null)}
          onScheduleActivity={handleScheduleActivity}
          tripStopId={activeStopForActivity.id}
          cityName={activeStopForActivity.cityName}
          cityActivities={selectedCityActivities}
          totalDays={Math.max(1, Math.round((new Date(activeStopForActivity.departureDate) - new Date(activeStopForActivity.arrivalDate)) / (1000 * 60 * 60 * 24)) + 1)}
        />
      )}
    </div>
  );
}
