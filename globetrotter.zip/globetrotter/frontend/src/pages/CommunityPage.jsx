import React, { useState, useEffect } from 'react';
import { Users, Heart, Eye, Copy, Share2, MapPin, Calendar, Sparkles, Search, Filter, ArrowRight } from 'lucide-react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import LoadingSpinner from '../components/common/LoadingSpinner';

const STYLES = ['All', 'Explorer', 'Adventure', 'Culture', 'Relaxation', 'Culinary', 'Luxury', 'Solo'];

export default function CommunityPage({ onViewSharedTrip, onNavigate, showToast }) {
  const { user, isAuthenticated, refreshUser } = useAuth();
  const { formatAmount } = useCurrency();
  const [trips, setTrips] = useState([]);
  const [style, setStyle] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('likes'); // 'likes' | 'views' | 'newest'
  const [loading, setLoading] = useState(true);

  async function fetchCommunityTrips() {
    try {
      setLoading(true);
      const data = await api.community.list({
        style: style !== 'All' ? style : undefined,
        search: searchQuery,
        sort: sortBy
      });
      setTrips(data.trips || []);
    } catch (err) {
      console.error('Failed to load community trips:', err);
      showToast('Failed to load community itineraries', 'error');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchCommunityTrips();
  }, [style, sortBy]);

  function handleSearch(e) {
    e.preventDefault();
    fetchCommunityTrips();
  }

  async function handleToggleLike(e, tripId) {
    e.stopPropagation();
    if (!isAuthenticated) {
      showToast('Please sign in to like community itineraries.', 'info');
      return;
    }
    try {
      const res = await api.community.toggleLike(tripId);
      setTrips(trips.map(t => t.id === tripId ? { ...t, isLiked: res.isLiked, likesCount: res.likesCount } : t));
      showToast(res.isLiked ? 'Trip upvoted!' : 'Like removed', 'success');
    } catch {
      showToast('Failed to update like status', 'error');
    }
  }

  async function handleClone(e, tripId) {
    e.stopPropagation();
    if (!isAuthenticated) {
      showToast('Please sign in to copy this itinerary to your account.', 'info');
      return;
    }
    try {
      const res = await api.community.cloneTrip(tripId);
      showToast(res.message, 'success');
      refreshUser();
      onNavigate('my-trips');
    } catch (err) {
      showToast(err.message || 'Failed to clone trip', 'error');
    }
  }

  return (
    <div className="container-wide" style={{ paddingBottom: '4rem' }}>
      {/* Header */}
      <div style={{ margin: '2rem 0 1.5rem' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', padding: '0.25rem 0.65rem', background: 'rgba(255, 107, 74, 0.1)', color: 'var(--primary-coral)', borderRadius: 'var(--radius-full)', fontSize: '0.8rem', fontWeight: 700, marginBottom: '0.5rem' }}>
          <Users size={14} />
          <span>Traveler Community Hub</span>
        </div>
        <h1 style={{ fontSize: '2.3rem', fontWeight: 800 }}>Discover & Clone Public Itineraries</h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
          Explore real itineraries published by travelers worldwide. Copy any plan to your account with 1-click and customize it.
        </p>
      </div>

      {/* Filters & Search */}
      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        gap: '1rem',
        alignItems: 'center',
        background: 'var(--bg-surface)',
        padding: '1.25rem',
        borderRadius: 'var(--radius-xl)',
        border: '1px solid var(--border-color)',
        boxShadow: 'var(--shadow-sm)',
        marginBottom: '2rem'
      }}>
        {/* Search */}
        <form onSubmit={handleSearch} style={{ flex: 1, minWidth: '240px', position: 'relative' }}>
          <input
            type="text"
            className="form-input"
            placeholder="Search community itineraries by title or author..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{ paddingLeft: '2.5rem' }}
          />
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
        </form>

        {/* Sort */}
        <select
          className="form-select"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          style={{ width: 'auto', minWidth: '150px' }}
        >
          <option value="likes">Most Popular (Likes)</option>
          <option value="views">Most Viewed</option>
          <option value="newest">Recently Published</option>
        </select>
      </div>

      {/* Style Filter Pills */}
      <div style={{ display: 'flex', gap: '0.4rem', overflowX: 'auto', paddingBottom: '0.75rem', marginBottom: '1.5rem' }}>
        {STYLES.map(s => (
          <button
            key={s}
            onClick={() => setStyle(s)}
            className={`btn btn-sm ${style === s ? 'btn-primary' : 'btn-outline'}`}
            style={{ borderRadius: 'var(--radius-full)', padding: '0.4rem 1rem', whiteSpace: 'nowrap' }}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Community Trips Grid */}
      {loading ? (
        <LoadingSpinner message="Exploring community travel hub..." />
      ) : trips.length > 0 ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '2rem' }}>
          {trips.map(trip => (
            <div
              key={trip.id}
              className="card card-interactive"
              onClick={() => onViewSharedTrip(trip.shareSlug)}
              style={{ display: 'flex', flexDirection: 'column', height: '100%' }}
            >
              {/* Cover Photo */}
              <div style={{ position: 'relative', height: '200px', width: '100%', overflow: 'hidden' }}>
                <img
                  src={trip.coverImage}
                  alt={trip.title}
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
                <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent 0%, rgba(15, 23, 42, 0.75) 100%)' }} />

                {/* Badges */}
                <div style={{ position: 'absolute', top: '12px', left: '12px', right: '12px', display: 'flex', justifyContent: 'space-between' }}>
                  <span className="badge badge-coral" style={{ backdropFilter: 'blur(8px)' }}>
                    {trip.travelStyle}
                  </span>
                  <button
                    onClick={(e) => handleToggleLike(e, trip.id)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.3rem',
                      padding: '0.3rem 0.65rem',
                      borderRadius: 'var(--radius-full)',
                      background: 'rgba(15, 23, 42, 0.75)',
                      backdropFilter: 'blur(8px)',
                      color: trip.isLiked ? 'var(--accent-rose)' : 'white',
                      border: 'none',
                      cursor: 'pointer',
                      fontSize: '0.75rem',
                      fontWeight: 700
                    }}
                  >
                    <Heart size={14} fill={trip.isLiked ? 'var(--accent-rose)' : 'none'} />
                    <span>{trip.likesCount}</span>
                  </button>
                </div>

                {/* Bottom Cities */}
                <div style={{ position: 'absolute', bottom: '12px', left: '12px', right: '12px', color: 'white', display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.825rem' }}>
                  <MapPin size={14} color="var(--secondary-teal)" />
                  <span>{trip.stopsCount} Cities</span>
                  <span>•</span>
                  <span>{trip.activitiesCount} Scheduled Events</span>
                </div>
              </div>

              {/* Body */}
              <div style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', flex: 1, gap: '0.65rem' }}>
                <h3 style={{ fontSize: '1.2rem', fontWeight: 800, lineHeight: 1.3 }}>
                  {trip.title}
                </h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineClamp: 2, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                  {trip.description}
                </p>

                {/* Author row */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginTop: 'auto', paddingTop: '0.75rem', borderTop: '1px solid var(--border-color)' }}>
                  <img
                    src={trip.author?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                    alt={trip.author?.name}
                    style={{ width: '28px', height: '28px', borderRadius: '50%', objectFit: 'cover' }}
                  />
                  <div style={{ fontSize: '0.8rem' }}>
                    <div style={{ fontWeight: 700 }}>{trip.author?.name}</div>
                    <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>{trip.author?.location}</div>
                  </div>
                </div>
              </div>

              {/* Clone Action Button */}
              <div style={{ padding: '0.85rem 1.25rem', background: 'var(--bg-surface-secondary)', borderTop: '1px solid var(--border-color)', display: 'flex', gap: '0.5rem' }}>
                <button
                  className="btn btn-primary btn-sm"
                  onClick={(e) => handleClone(e, trip.id)}
                  style={{ width: '100%' }}
                >
                  <Copy size={15} />
                  <span>Copy Trip to My Plans</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="card" style={{ padding: '3.5rem 2rem', textAlign: 'center' }}>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>No Community Itineraries Found</h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', margin: '0.5rem 0 1.5rem' }}>
            Be the first to publish a public itinerary and inspire travelers!
          </p>
        </div>
      )}
    </div>
  );
}
