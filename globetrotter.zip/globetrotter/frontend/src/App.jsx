import React, { useState, useEffect } from 'react';
import { useAuth } from './context/AuthContext';
import api from './services/api';

// Components
import Navbar from './components/common/Navbar';
import Footer from './components/common/Footer';
import Toast from './components/common/Toast';
import CreateTripModal from './components/forms/CreateTripModal';
import CityDetailModal from './components/cards/CityDetailModal';
import LoadingSpinner from './components/common/LoadingSpinner';

// Pages for all 13 features
import AuthPage from './pages/AuthPage';
import DashboardPage from './pages/DashboardPage';
import MyTripsPage from './pages/MyTripsPage';
import ItineraryBuilderPage from './pages/ItineraryBuilderPage';
import ItineraryViewPage from './pages/ItineraryViewPage';
import CitySearchPage from './pages/CitySearchPage';
import ActivitySearchPage from './pages/ActivitySearchPage';
import TripBudgetPage from './pages/TripBudgetPage';
import TripCalendarPage from './pages/TripCalendarPage';
import CommunityPage from './pages/CommunityPage';
import SharedTripPage from './pages/SharedTripPage';
import ProfilePage from './pages/ProfilePage';
import AdminDashboardPage from './pages/AdminDashboardPage';

export default function App() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  
  // Navigation State
  const [activePage, setActivePage] = useState('dashboard');
  const [selectedTripId, setSelectedTripId] = useState(null);
  const [selectedShareSlug, setSelectedShareSlug] = useState(null);

  // Global Modals State
  const [showCreateTripModal, setShowCreateTripModal] = useState(false);
  const [preselectedCityId, setPreselectedCityId] = useState(null);
  const [cities, setCities] = useState([]);
  const [viewingCityId, setViewingCityId] = useState(null);

  // Toast notifications
  const [toasts, setToasts] = useState([]);

  function showToast(message, type = 'info') {
    const id = Date.now() + Math.random();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  }

  function dismissToast(id) {
    setToasts(prev => prev.filter(t => t.id !== id));
  }

  // Load cities catalog for modals
  useEffect(() => {
    api.cities.list()
      .then(res => setCities(res.cities || []))
      .catch(() => {});
  }, []);

  // Handle URL hash changes for deep linking (e.g. /#/share/:slug)
  useEffect(() => {
    function handleHashChange() {
      const hash = window.location.hash;
      if (hash.startsWith('#/share/')) {
        const slug = hash.replace('#/share/', '');
        setSelectedShareSlug(slug);
        setActivePage('share-trip');
      }
    }
    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Handle Create Trip
  async function handleCreateTrip(tripData) {
    try {
      const res = await api.trips.create(tripData);
      showToast('Trip created successfully! Let\'s build your day schedule.', 'success');
      setSelectedTripId(res.tripId);
      setActivePage('itinerary-builder');
    } catch (err) {
      showToast(err.message || 'Failed to create trip', 'error');
      throw err;
    }
  }

  // Quick action: Add Stop with City
  function handleAddStopWithCity(city) {
    setPreselectedCityId(city.id);
    setShowCreateTripModal(true);
    setViewingCityId(null);
  }

  if (authLoading) {
    return <LoadingSpinner message="Connecting to GlobeTrotter platform..." />;
  }

  // If not logged in and not viewing a public shared itinerary, show Auth Page
  if (!isAuthenticated && activePage !== 'share-trip') {
    return (
      <div className="app-wrapper">
        <AuthPage onLoginSuccess={() => setActivePage('dashboard')} />
        <Toast toasts={toasts} onDismiss={dismissToast} />
      </div>
    );
  }

  return (
    <div className="app-wrapper">
      <Navbar
        activePage={activePage}
        onNavigate={(page) => {
          setActivePage(page);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenCreateTrip={() => {
          setPreselectedCityId(null);
          setShowCreateTripModal(true);
        }}
      />

      <main className="main-content">
        {activePage === 'dashboard' && (
          <DashboardPage
            onNavigate={setActivePage}
            onOpenCreateTrip={() => {
              setPreselectedCityId(null);
              setShowCreateTripModal(true);
            }}
            onViewTrip={(id) => {
              setSelectedTripId(id);
              setActivePage('itinerary-view');
            }}
            onEditTrip={(id) => {
              setSelectedTripId(id);
              setActivePage('itinerary-builder');
            }}
            onBudgetTrip={(id) => {
              setSelectedTripId(id);
              setActivePage('budget-view');
            }}
            onAddStopWithCity={handleAddStopWithCity}
            onViewCityDetails={setViewingCityId}
            showToast={showToast}
          />
        )}

        {activePage === 'my-trips' && (
          <MyTripsPage
            onOpenCreateTrip={() => {
              setPreselectedCityId(null);
              setShowCreateTripModal(true);
            }}
            onViewTrip={(id) => {
              setSelectedTripId(id);
              setActivePage('itinerary-view');
            }}
            onEditTrip={(id) => {
              setSelectedTripId(id);
              setActivePage('itinerary-builder');
            }}
            onBudgetTrip={(id) => {
              setSelectedTripId(id);
              setActivePage('budget-view');
            }}
            onNavigate={setActivePage}
            showToast={showToast}
          />
        )}

        {activePage === 'itinerary-builder' && (
          <ItineraryBuilderPage
            tripId={selectedTripId}
            onViewTrip={(id) => {
              setSelectedTripId(id);
              setActivePage('itinerary-view');
            }}
            onBudgetTrip={(id) => {
              setSelectedTripId(id);
              setActivePage('budget-view');
            }}
            onNavigate={setActivePage}
            showToast={showToast}
          />
        )}

        {activePage === 'itinerary-view' && (
          <ItineraryViewPage
            tripId={selectedTripId}
            onEditTrip={(id) => {
              setSelectedTripId(id);
              setActivePage('itinerary-builder');
            }}
            onBudgetTrip={(id) => {
              setSelectedTripId(id);
              setActivePage('budget-view');
            }}
            onNavigate={setActivePage}
            showToast={showToast}
          />
        )}

        {activePage === 'cities' && (
          <CitySearchPage
            onAddStopWithCity={handleAddStopWithCity}
            onViewCityDetails={setViewingCityId}
            showToast={showToast}
          />
        )}

        {activePage === 'activities' && (
          <ActivitySearchPage
            showToast={showToast}
          />
        )}

        {activePage === 'budget-view' && (
          <TripBudgetPage
            tripId={selectedTripId}
            onViewTrip={(id) => {
              setSelectedTripId(id);
              setActivePage('itinerary-view');
            }}
            onEditTrip={(id) => {
              setSelectedTripId(id);
              setActivePage('itinerary-builder');
            }}
            onNavigate={setActivePage}
            showToast={showToast}
          />
        )}

        {activePage === 'calendar' && (
          <TripCalendarPage
            onViewTrip={(id) => {
              setSelectedTripId(id);
              setActivePage('itinerary-view');
            }}
            onNavigate={setActivePage}
            showToast={showToast}
          />
        )}

        {activePage === 'community' && (
          <CommunityPage
            onViewSharedTrip={(slug) => {
              setSelectedShareSlug(slug);
              setActivePage('share-trip');
              window.location.hash = `#/share/${slug}`;
            }}
            onNavigate={setActivePage}
            showToast={showToast}
          />
        )}

        {activePage === 'share-trip' && (
          <SharedTripPage
            slug={selectedShareSlug}
            onNavigate={setActivePage}
            showToast={showToast}
          />
        )}

        {activePage === 'profile' && (
          <ProfilePage
            onNavigate={setActivePage}
            onAddStopWithCity={handleAddStopWithCity}
            showToast={showToast}
          />
        )}

        {activePage === 'admin' && (
          <AdminDashboardPage
            showToast={showToast}
          />
        )}
      </main>

      <Footer onNavigate={setActivePage} />

      {/* Global Create Trip Modal */}
      <CreateTripModal
        isOpen={showCreateTripModal}
        onClose={() => setShowCreateTripModal(false)}
        onCreateTrip={handleCreateTrip}
        cities={cities}
        preselectedCityId={preselectedCityId}
      />

      {/* Global City Detail Modal */}
      {viewingCityId && (
        <CityDetailModal
          cityId={viewingCityId}
          onClose={() => setViewingCityId(null)}
          onAddToTrip={handleAddStopWithCity}
          onSelectCity={setViewingCityId}
          showToast={showToast}
        />
      )}

      {/* Toast Notifications Overlay */}
      <Toast toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
