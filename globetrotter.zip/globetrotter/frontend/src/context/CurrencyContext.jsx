import React, { createContext, useContext, useState } from 'react';

const CurrencyContext = createContext(null);

const RATES = {
  USD: { symbol: '$', rate: 1.0, label: 'USD ($)' },
  EUR: { symbol: '€', rate: 0.92, label: 'EUR (€)' },
  GBP: { symbol: '£', rate: 0.79, label: 'GBP (£)' },
  INR: { symbol: '₹', rate: 86.5, label: 'INR (₹)' },
  JPY: { symbol: '¥', rate: 154.0, label: 'JPY (¥)' }
};

export function CurrencyProvider({ children }) {
  const [currency, setCurrency] = useState(localStorage.getItem('globetrotter_currency') || 'USD');

  function changeCurrency(curr) {
    if (RATES[curr]) {
      setCurrency(curr);
      localStorage.setItem('globetrotter_currency', curr);
    }
  }

  function formatAmount(amountInUSD) {
    const numeric = Number(amountInUSD) || 0;
    const rateInfo = RATES[currency] || RATES.USD;
    const converted = numeric * rateInfo.rate;

    if (currency === 'JPY') {
      return `${rateInfo.symbol}${Math.round(converted).toLocaleString()}`;
    }
    return `${rateInfo.symbol}${converted.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
  }

  return (
    <CurrencyContext.Provider
      value={{
        currency,
        currencies: RATES,
        setCurrency: changeCurrency,
        formatAmount,
        symbol: RATES[currency]?.symbol || '$'
      }}
    >
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  return useContext(CurrencyContext);
}
