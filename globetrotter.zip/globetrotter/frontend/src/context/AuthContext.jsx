import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [stats, setStats] = useState(null);
  const [savedDestinations, setSavedDestinations] = useState([]);
  const [loading, setLoading] = useState(true);

  async function loadUser() {
    const token = localStorage.getItem('globetrotter_token');
    if (!token) {
      setUser(null);
      setLoading(false);
      return;
    }

    try {
      const data = await api.auth.getMe();
      setUser(data.user);
      setStats(data.stats);
      setSavedDestinations(data.savedDestinations || []);
    } catch (err) {
      console.warn('Session expired or invalid:', err);
      localStorage.removeItem('globetrotter_token');
      setUser(null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadUser();
  }, []);

  async function login(email, password) {
    const data = await api.auth.login({ email, password });
    localStorage.setItem('globetrotter_token', data.token);
    setUser(data.user);
    await loadUser();
    return data;
  }

  async function register(userData) {
    const data = await api.auth.register(userData);
    localStorage.setItem('globetrotter_token', data.token);
    setUser(data.user);
    await loadUser();
    return data;
  }

  function logout() {
    localStorage.removeItem('globetrotter_token');
    setUser(null);
    setStats(null);
    setSavedDestinations([]);
  }

  // Quick Demo Login helpers
  async function loginAsDemoTraveler() {
    return login('traveler@globetrotter.com', 'password123');
  }

  async function loginAsDemoAdmin() {
    return login('admin@globetrotter.com', 'admin123');
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        stats,
        savedDestinations,
        loading,
        login,
        register,
        logout,
        refreshUser: loadUser,
        loginAsDemoTraveler,
        loginAsDemoAdmin,
        isAuthenticated: !!user,
        isAdmin: user?.role === 'admin'
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
