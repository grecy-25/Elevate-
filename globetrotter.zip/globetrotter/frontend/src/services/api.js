const API_BASE = '/api';

function getAuthHeader() {
  const token = localStorage.getItem('globetrotter_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

// Build a clean query string, dropping undefined/null/'' values so they
// never get serialized as the literal string "undefined" (which used to
// break backend filters like ?cityId=undefined or ?region=undefined).
function buildQuery(params = {}) {
  const cleaned = {};
  Object.entries(params).forEach(([key, value]) => {
    if (value === undefined || value === null || value === '') return;
    cleaned[key] = value;
  });
  const qs = new URLSearchParams(cleaned).toString();
  return qs ? `?${qs}` : '';
}

async function request(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    ...getAuthHeader(),
    ...(options.headers || {})
  };

  const response = await fetch(url, {
    ...options,
    headers
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const error = new Error(data.error || data.message || 'Network request failed');
    error.status = response.status;
    error.data = data;
    throw error;
  }

  return data;
}

export const api = {
  // 1. Auth API
  auth: {
    login: (credentials) => request('/auth/login', { method: 'POST', body: JSON.stringify(credentials) }),
    register: (userData) => request('/auth/register', { method: 'POST', body: JSON.stringify(userData) }),
    getMe: () => request('/auth/me'),
    forgotPassword: (email) => request('/auth/forgot-password', { method: 'POST', body: JSON.stringify({ email }) }),
    updateProfile: (profileData) => request('/auth/profile', { method: 'PUT', body: JSON.stringify(profileData) }),
    changePassword: (passwords) => request('/auth/change-password', { method: 'POST', body: JSON.stringify(passwords) }),
    deleteAccount: () => request('/auth/account', { method: 'DELETE' })
  },

  // 2. Trips API
  trips: {
    list: (params = {}) => request(`/trips${buildQuery(params)}`),
    getById: (id) => request(`/trips/${id}`),
    create: (tripData) => request('/trips', { method: 'POST', body: JSON.stringify(tripData) }),
    update: (id, tripData) => request(`/trips/${id}`, { method: 'PUT', body: JSON.stringify(tripData) }),
    delete: (id) => request(`/trips/${id}`, { method: 'DELETE' }),
    duplicate: (id) => request(`/trips/${id}/duplicate`, { method: 'POST' })
  },

  // 3. Stops API
  stops: {
    add: (stopData) => request('/stops', { method: 'POST', body: JSON.stringify(stopData) }),
    update: (id, stopData) => request(`/stops/${id}`, { method: 'PUT', body: JSON.stringify(stopData) }),
    delete: (id) => request(`/stops/${id}`, { method: 'DELETE' }),
    reorder: (tripId, stopOrder) => request('/stops/reorder', { method: 'POST', body: JSON.stringify({ tripId, stopOrder }) })
  },

  // 4. Activities API
  activities: {
    list: (params = {}) => request(`/activities${buildQuery(params)}`),
    getByCity: (cityId) => request(`/activities/city/${cityId}`),
    schedule: (activityData) => request('/activities/schedule', { method: 'POST', body: JSON.stringify(activityData) }),
    updateScheduled: (id, data) => request(`/activities/schedule/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    deleteScheduled: (id) => request(`/activities/schedule/${id}`, { method: 'DELETE' })
  },

  // 5. Cities API
  cities: {
    list: (params = {}) => request(`/cities${buildQuery(params)}`),
    getById: (id) => request(`/cities/${id}`),
    toggleSave: (cityId) => request('/cities/save-toggle', { method: 'POST', body: JSON.stringify({ cityId }) })
  },

  // 6. Expenses API
  expenses: {
    getByTrip: (tripId) => request(`/expenses/trip/${tripId}`),
    add: (expenseData) => request('/expenses', { method: 'POST', body: JSON.stringify(expenseData) }),
    delete: (id) => request(`/expenses/${id}`, { method: 'DELETE' })
  },

  // 7. Community Hub API
  community: {
    list: (params = {}) => request(`/community/trips${buildQuery(params)}`),
    getBySlug: (slug) => request(`/community/trip/${slug}`),
    toggleLike: (tripId) => request('/community/like', { method: 'POST', body: JSON.stringify({ tripId }) }),
    cloneTrip: (tripId) => request(`/community/clone/${tripId}`, { method: 'POST' })
  },

  // 8. Admin API
  admin: {
    getAnalytics: () => request('/admin/analytics'),
    listUsers: () => request('/admin/users'),
    updateUserRole: (userId, role) => request('/admin/users/role', { method: 'POST', body: JSON.stringify({ userId, role }) }),
    resetDatabase: () => request('/admin/reset-database', { method: 'POST' })
  }
};

export default api;
