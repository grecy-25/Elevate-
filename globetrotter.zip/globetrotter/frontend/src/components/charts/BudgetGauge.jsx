import React from 'react';
import { useCurrency } from '../../context/CurrencyContext';
import { AlertTriangle, CheckCircle2, DollarSign } from 'lucide-react';

export default function BudgetGauge({ allocated = 0, spent = 0 }) {
  const { formatAmount } = useCurrency();
  const numAllocated = Number(allocated) || 0;
  const numSpent = Number(spent) || 0;
  const percent = numAllocated > 0 ? Math.round((numSpent / numAllocated) * 100) : 0;
  const remaining = numAllocated - numSpent;
  const isOver = numSpent > numAllocated && numAllocated > 0;

  // Determine progress color
  let statusColor = 'var(--secondary-teal)';
  if (percent > 90 && percent <= 100) statusColor = 'var(--accent-gold)';
  else if (isOver) statusColor = 'var(--accent-rose)';

  return (
    <div style={{
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-color)',
      borderRadius: 'var(--radius-lg)',
      padding: '1.25rem',
      boxShadow: 'var(--shadow-sm)'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <div style={{
            width: '32px',
            height: '32px',
            borderRadius: 'var(--radius-sm)',
            background: isOver ? 'rgba(225, 71, 107, 0.12)' : 'rgba(8, 145, 178, 0.12)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: isOver ? 'var(--accent-rose)' : 'var(--secondary-teal)'
          }}>
            {isOver ? <AlertTriangle size={18} /> : <DollarSign size={18} />}
          </div>
          <div>
            <h4 style={{ fontSize: '0.95rem', fontWeight: 700 }}>Budget Health</h4>
            <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              {isOver ? 'Exceeding planned budget limit' : 'Within target financial allocation'}
            </p>
          </div>
        </div>
        <span className={`badge ${isOver ? 'badge-coral' : percent > 80 ? 'badge-gold' : 'badge-teal'}`}>
          {percent}% Used
        </span>
      </div>

      {/* Linear Progress Bar */}
      <div style={{
        height: '10px',
        width: '100%',
        background: 'var(--bg-surface-secondary)',
        borderRadius: 'var(--radius-full)',
        overflow: 'hidden',
        position: 'relative',
        margin: '0.75rem 0'
      }}>
        <div style={{
          height: '100%',
          width: `${Math.min(100, percent)}%`,
          background: statusColor,
          borderRadius: 'var(--radius-full)',
          transition: 'width 0.5s cubic-bezier(0.16, 1, 0.3, 1)'
        }} />
      </div>

      {/* Metric details */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '0.5rem', fontSize: '0.85rem' }}>
        <div>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', display: 'block' }}>Spent So Far</span>
          <strong style={{ color: isOver ? 'var(--accent-rose)' : 'var(--text-primary)' }}>
            {formatAmount(numSpent)}
          </strong>
        </div>
        <div style={{ textAlign: 'center' }}>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', display: 'block' }}>
            {remaining >= 0 ? 'Remaining' : 'Over Budget'}
          </span>
          <strong style={{ color: remaining >= 0 ? 'var(--accent-emerald)' : 'var(--accent-rose)' }}>
            {formatAmount(Math.abs(remaining))}
          </strong>
        </div>
        <div style={{ textAlign: 'right' }}>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', display: 'block' }}>Total Allocated</span>
          <strong style={{ color: 'var(--text-primary)' }}>
            {formatAmount(numAllocated)}
          </strong>
        </div>
      </div>
    </div>
  );
}
