import React, { useState } from 'react';
import { useCurrency } from '../../context/CurrencyContext';

export default function BarChart({ data = [], height = 180, barColor = 'var(--primary-coral)' }) {
  const { formatAmount } = useCurrency();
  const [hoveredItem, setHoveredItem] = useState(null);

  if (!data || data.length === 0) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height, color: 'var(--text-muted)', fontSize: '0.875rem' }}>
        No timeline data available.
      </div>
    );
  }

  const maxVal = Math.max(...data.map(d => Number(d.total || d.value || d.count || 0)), 1);

  return (
    <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
      <div style={{
        display: 'flex',
        alignItems: 'flex-end',
        justifyContent: 'space-between',
        gap: '0.5rem',
        height,
        padding: '0.5rem 0',
        borderBottom: '1px solid var(--border-color)'
      }}>
        {data.map((item, idx) => {
          const val = Number(item.total || item.value || item.count || 0);
          const heightPercent = Math.max(8, (val / maxVal) * 100);
          const label = item.date ? item.date.slice(5) : item.label || `Day ${idx + 1}`;
          const isHovered = hoveredItem === idx;

          return (
            <div
              key={idx}
              style={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                height: '100%',
                justifyContent: 'flex-end',
                position: 'relative'
              }}
              onMouseEnter={() => setHoveredItem(idx)}
              onMouseLeave={() => setHoveredItem(null)}
            >
              {/* Tooltip on hover */}
              {isHovered && (
                <div style={{
                  position: 'absolute',
                  bottom: `${heightPercent + 10}%`,
                  background: 'var(--dark-navy)',
                  color: 'white',
                  padding: '0.3rem 0.6rem',
                  borderRadius: 'var(--radius-sm)',
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  whiteSpace: 'nowrap',
                  zIndex: 10,
                  boxShadow: 'var(--shadow-md)',
                  pointerEvents: 'none'
                }}>
                  {item.title || label}: {item.count !== undefined ? `${val} visits` : formatAmount(val)}
                </div>
              )}

              {/* Animated Bar */}
              <div style={{
                width: '100%',
                maxWidth: '38px',
                height: `${heightPercent}%`,
                background: isHovered ? 'var(--primary-coral-hover)' : barColor,
                borderRadius: '6px 6px 0 0',
                transition: 'all 0.25s ease',
                cursor: 'pointer',
                opacity: hoveredItem !== null && !isHovered ? 0.6 : 1
              }} />

              {/* X-Axis Label */}
              <span style={{
                marginTop: '0.5rem',
                fontSize: '0.75rem',
                fontWeight: 600,
                color: isHovered ? 'var(--primary-coral)' : 'var(--text-muted)',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                maxWidth: '48px',
                textAlign: 'center'
              }}>
                {label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
