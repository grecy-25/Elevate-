import React, { useState } from 'react';
import { useCurrency } from '../../context/CurrencyContext';

const DEFAULT_COLORS = {
  Accommodation: '#3B82F6',
  Transport: '#6D5DD3',
  Activities: '#EC4899',
  Food: '#D9A441',
  Shopping: '#14A76C',
  Miscellaneous: '#9B8AFB'
};

export default function DonutChart({ data = {}, size = 240, strokeWidth = 32 }) {
  const { formatAmount } = useCurrency();
  const [hoveredIndex, setHoveredIndex] = useState(null);

  const entries = Object.entries(data).filter(([_, value]) => Number(value) > 0);
  const total = entries.reduce((sum, [_, value]) => sum + Number(value), 0);

  if (entries.length === 0 || total === 0) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '220px', color: 'var(--text-muted)' }}>
        <p style={{ fontSize: '0.9rem' }}>No expense data recorded yet.</p>
      </div>
    );
  }

  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const center = size / 2;

  let accumulatedPercent = 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1.25rem' }}>
      <div style={{ position: 'relative', width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          {entries.map(([category, value], index) => {
            const val = Number(value);
            const percent = val / total;
            const strokeDasharray = `${percent * circumference} ${circumference}`;
            const strokeDashoffset = -accumulatedPercent * circumference;
            accumulatedPercent += percent;

            const color = DEFAULT_COLORS[category] || '#94A3B8';
            const isHovered = hoveredIndex === index;

            return (
              <circle
                key={category}
                cx={center}
                cy={center}
                r={radius}
                fill="none"
                stroke={color}
                strokeWidth={isHovered ? strokeWidth + 4 : strokeWidth}
                strokeDasharray={strokeDasharray}
                strokeDashoffset={strokeDashoffset}
                transform={`rotate(-90 ${center} ${center})`}
                style={{
                  transition: 'all 0.25s ease',
                  cursor: 'pointer',
                  opacity: hoveredIndex !== null && !isHovered ? 0.6 : 1
                }}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              />
            );
          })}
        </svg>

        {/* Center Total Display */}
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          textAlign: 'center',
          pointerEvents: 'none'
        }}>
          <span style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase' }}>
            {hoveredIndex !== null ? entries[hoveredIndex][0] : 'Total Spent'}
          </span>
          <div style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)' }}>
            {formatAmount(hoveredIndex !== null ? entries[hoveredIndex][1] : total)}
          </div>
          {hoveredIndex !== null && (
            <span style={{ fontSize: '0.75rem', fontWeight: 700, color: DEFAULT_COLORS[entries[hoveredIndex][0]] || 'var(--text-secondary)' }}>
              {Math.round((entries[hoveredIndex][1] / total) * 100)}%
            </span>
          )}
        </div>
      </div>

      {/* Legend */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: '0.5rem 1rem', width: '100%' }}>
        {entries.map(([category, value], index) => {
          const color = DEFAULT_COLORS[category] || '#94A3B8';
          const percent = Math.round((Number(value) / total) * 100);

          return (
            <div 
              key={category}
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '0.35rem 0.5rem',
                borderRadius: 'var(--radius-sm)',
                background: hoveredIndex === index ? 'var(--bg-surface-secondary)' : 'transparent',
                cursor: 'pointer',
                transition: 'background 0.15s ease'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', overflow: 'hidden' }}>
                <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: color, flexShrink: 0 }} />
                <span style={{ fontSize: '0.825rem', fontWeight: 600, color: 'var(--text-secondary)', textOverflow: 'ellipsis', whiteSpace: 'nowrap', overflow: 'hidden' }}>
                  {category}
                </span>
              </div>
              <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                {percent}%
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
