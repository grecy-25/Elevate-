import React, { useState, useEffect, useRef } from 'react';
import { Search, MapPin, X, Loader2 } from 'lucide-react';
import api from '../../services/api';

/**
 * Worldwide city search box. Instead of showing every city in a giant
 * dropdown, it stays empty until the person types — then it queries the
 * backend (which itself falls back to a live worldwide geocoding lookup
 * for any city not already cached locally) and shows the closest matching
 * suggestions to pick from.
 */
export default function CityAutocomplete({ selectedLabel, onSelect, onClear, placeholder = 'Search any city in the world...' }) {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const containerRef = useRef(null);
  const debounceRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);

    if (!query || query.trim().length < 2) {
      setSuggestions([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await api.cities.list({ search: query.trim() });
        setSuggestions((res.cities || []).slice(0, 8));
        setOpen(true);
      } catch {
        setSuggestions([]);
      } finally {
        setLoading(false);
      }
    }, 400);

    return () => clearTimeout(debounceRef.current);
  }, [query]);

  function handleSelect(city) {
    onSelect(city);
    setQuery('');
    setSuggestions([]);
    setOpen(false);
  }

  return (
    <div ref={containerRef} style={{ position: 'relative', minWidth: '220px', flex: '1 1 260px' }}>
      {selectedLabel ? (
        <div
          className="form-input"
          style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.5rem', cursor: 'default' }}
        >
          <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            <MapPin size={15} style={{ color: 'var(--primary-coral)', flexShrink: 0 }} />
            {selectedLabel}
          </span>
          <button
            type="button"
            onClick={onClear}
            aria-label="Clear destination filter"
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex', flexShrink: 0 }}
          >
            <X size={16} />
          </button>
        </div>
      ) : (
        <>
          <input
            type="text"
            className="form-input"
            placeholder={placeholder}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => query.trim().length >= 2 && setOpen(true)}
            style={{ paddingLeft: '2.5rem' }}
          />
          {loading ? (
            <Loader2 size={16} className="spin" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          ) : (
            <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          )}

          {open && query.trim().length >= 2 && (
            <div
              style={{
                position: 'absolute',
                top: 'calc(100% + 6px)',
                left: 0,
                right: 0,
                background: 'var(--bg-surface)',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                boxShadow: 'var(--shadow-lg)',
                maxHeight: '280px',
                overflowY: 'auto',
                zIndex: 50
              }}
            >
              {loading && suggestions.length === 0 ? (
                <div style={{ padding: '0.85rem 1rem', fontSize: '0.85rem', color: 'var(--text-muted)' }}>Searching worldwide destinations...</div>
              ) : suggestions.length > 0 ? (
                suggestions.map(city => (
                  <button
                    key={city.id}
                    type="button"
                    onClick={() => handleSelect(city)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.6rem',
                      width: '100%',
                      padding: '0.65rem 1rem',
                      background: 'none',
                      border: 'none',
                      borderBottom: '1px solid var(--border-light)',
                      cursor: 'pointer',
                      textAlign: 'left',
                      fontSize: '0.875rem'
                    }}
                    onMouseDown={(e) => e.preventDefault()}
                  >
                    <MapPin size={15} style={{ color: 'var(--primary-coral)', flexShrink: 0 }} />
                    <span style={{ fontWeight: 600 }}>{city.name}</span>
                    <span style={{ color: 'var(--text-muted)' }}>{city.country}</span>
                  </button>
                ))
              ) : (
                <div style={{ padding: '0.85rem 1rem', fontSize: '0.85rem', color: 'var(--text-muted)' }}>No matching cities found.</div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
