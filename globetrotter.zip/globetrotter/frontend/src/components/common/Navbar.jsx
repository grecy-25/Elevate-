import React, { useState } from 'react';
import { 
  Compass, 
  Map, 
  Globe2, 
  Sparkles, 
  Calendar as CalendarIcon, 
  Users, 
  ShieldCheck, 
  Plus, 
  LogOut, 
  User as UserIcon, 
  ChevronDown,
  Coins
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useCurrency } from '../../context/CurrencyContext';

export default function Navbar({ activePage, onNavigate, onOpenCreateTrip }) {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const { currency, currencies, setCurrency } = useCurrency();
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);

  return (
    <header className="navbar">
      <div className="container-wide navbar-inner">
        {/* Brand Logo */}
        <div 
          className="navbar-brand" 
          onClick={() => onNavigate('dashboard')} 
          style={{ cursor: 'pointer', userSelect: 'none' }}
        >
          <div className="navbar-brand-icon">
            <Compass size={22} />
          </div>
          <span>GlobeTrotter</span>
        </div>

        {/* Navigation Tabs */}
        {isAuthenticated && (
          <nav>
            <ul className="navbar-nav">
              <li>
                <button
                  className={`nav-link ${activePage === 'dashboard' ? 'active' : ''}`}
                  onClick={() => onNavigate('dashboard')}
                >
                  <Compass size={17} />
                  <span>Dashboard</span>
                </button>
              </li>

              <li>
                <button
                  className={`nav-link ${activePage === 'my-trips' ? 'active' : ''}`}
                  onClick={() => onNavigate('my-trips')}
                >
                  <Map size={17} />
                  <span>My Trips</span>
                </button>
              </li>

              <li>
                <button
                  className={`nav-link ${activePage === 'cities' ? 'active' : ''}`}
                  onClick={() => onNavigate('cities')}
                >
                  <Globe2 size={17} />
                  <span>Cities</span>
                </button>
              </li>

              <li>
                <button
                  className={`nav-link ${activePage === 'activities' ? 'active' : ''}`}
                  onClick={() => onNavigate('activities')}
                >
                  <Sparkles size={17} />
                  <span>Experiences</span>
                </button>
              </li>

              <li>
                <button
                  className={`nav-link ${activePage === 'calendar' ? 'active' : ''}`}
                  onClick={() => onNavigate('calendar')}
                >
                  <CalendarIcon size={17} />
                  <span>Calendar</span>
                </button>
              </li>

              <li>
                <button
                  className={`nav-link ${activePage === 'community' ? 'active' : ''}`}
                  onClick={() => onNavigate('community')}
                >
                  <Users size={17} />
                  <span>Community</span>
                </button>
              </li>

              {isAdmin && (
                <li>
                  <button
                    className={`nav-link ${activePage === 'admin' ? 'active' : ''}`}
                    onClick={() => onNavigate('admin')}
                    style={{ color: 'var(--accent-indigo)' }}
                  >
                    <ShieldCheck size={17} />
                    <span>Admin</span>
                  </button>
                </li>
              )}
            </ul>
          </nav>
        )}

        {/* Right Action Bar */}
        <div className="nav-actions">
          {/* Currency Switcher */}
          <div style={{ position: 'relative' }}>
            <button
              className="btn btn-outline btn-sm"
              onClick={() => {
                setCurrencyDropdownOpen(!currencyDropdownOpen);
                setProfileDropdownOpen(false);
              }}
              style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', padding: '0.35rem 0.65rem' }}
            >
              <Coins size={15} style={{ color: 'var(--accent-gold)' }} />
              <span style={{ fontWeight: 700 }}>{currency}</span>
              <ChevronDown size={13} />
            </button>

            {currencyDropdownOpen && (
              <div style={{
                position: 'absolute',
                top: '120%',
                right: 0,
                background: 'var(--bg-surface)',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                boxShadow: 'var(--shadow-lg)',
                width: '140px',
                zIndex: 200,
                overflow: 'hidden'
              }}>
                {Object.keys(currencies).map(code => (
                  <button
                    key={code}
                    onClick={() => {
                      setCurrency(code);
                      setCurrencyDropdownOpen(false);
                    }}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      width: '100%',
                      padding: '0.5rem 0.85rem',
                      background: currency === code ? 'rgba(255, 107, 74, 0.08)' : 'transparent',
                      color: currency === code ? 'var(--primary-coral)' : 'var(--text-primary)',
                      border: 'none',
                      fontSize: '0.85rem',
                      fontWeight: 600,
                      cursor: 'pointer',
                      textAlign: 'left'
                    }}
                  >
                    <span>{code}</span>
                    <span style={{ color: 'var(--text-muted)' }}>{currencies[code].symbol}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {isAuthenticated ? (
            <>
              {/* Plan Trip CTA */}
              <button 
                className="btn btn-primary btn-sm"
                onClick={onOpenCreateTrip}
                style={{ boxShadow: 'var(--shadow-coral)' }}
              >
                <Plus size={16} />
                <span>Plan Trip</span>
              </button>

              {/* Profile Avatar Menu */}
              <div style={{ position: 'relative' }}>
                <div
                  onClick={() => {
                    setProfileDropdownOpen(!profileDropdownOpen);
                    setCurrencyDropdownOpen(false);
                  }}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    cursor: 'pointer',
                    padding: '0.25rem 0.5rem',
                    borderRadius: 'var(--radius-full)',
                    background: 'var(--bg-surface-secondary)',
                    border: '1px solid var(--border-color)'
                  }}
                >
                  <img
                    src={user?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                    alt={user?.firstName}
                    style={{ width: '32px', height: '32px', borderRadius: '50%', objectFit: 'cover' }}
                  />
                  <span style={{ fontSize: '0.85rem', fontWeight: 700, paddingRight: '0.2rem' }}>
                    {user?.firstName}
                  </span>
                  <ChevronDown size={14} style={{ color: 'var(--text-muted)' }} />
                </div>

                {profileDropdownOpen && (
                  <div style={{
                    position: 'absolute',
                    top: '120%',
                    right: 0,
                    background: 'var(--bg-surface)',
                    border: '1px solid var(--border-color)',
                    borderRadius: 'var(--radius-lg)',
                    boxShadow: 'var(--shadow-xl)',
                    width: '220px',
                    zIndex: 200,
                    overflow: 'hidden',
                    animation: 'scaleUp 0.15s ease'
                  }}>
                    <div style={{ padding: '0.85rem 1rem', borderBottom: '1px solid var(--border-color)', background: 'var(--bg-surface-secondary)' }}>
                      <p style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                        {user?.firstName} {user?.lastName}
                      </p>
                      <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {user?.email}
                      </p>
                      {isAdmin && (
                        <span className="badge badge-indigo" style={{ marginTop: '0.35rem' }}>
                          Administrator
                        </span>
                      )}
                    </div>

                    <div style={{ padding: '0.4rem 0' }}>
                      <button
                        onClick={() => {
                          onNavigate('profile');
                          setProfileDropdownOpen(false);
                        }}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.65rem',
                          width: '100%',
                          padding: '0.6rem 1rem',
                          background: 'none',
                          border: 'none',
                          color: 'var(--text-primary)',
                          fontSize: '0.875rem',
                          fontWeight: 600,
                          cursor: 'pointer',
                          textAlign: 'left'
                        }}
                      >
                        <UserIcon size={16} style={{ color: 'var(--accent-indigo)' }} />
                        <span>Profile & Settings</span>
                      </button>

                      <button
                        onClick={() => {
                          onNavigate('my-trips');
                          setProfileDropdownOpen(false);
                        }}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.65rem',
                          width: '100%',
                          padding: '0.6rem 1rem',
                          background: 'none',
                          border: 'none',
                          color: 'var(--text-primary)',
                          fontSize: '0.875rem',
                          fontWeight: 600,
                          cursor: 'pointer',
                          textAlign: 'left'
                        }}
                      >
                        <Map size={16} style={{ color: 'var(--secondary-teal)' }} />
                        <span>My Itineraries</span>
                      </button>
                    </div>

                    <div style={{ borderTop: '1px solid var(--border-color)', padding: '0.4rem 0' }}>
                      <button
                        onClick={() => {
                          logout();
                          setProfileDropdownOpen(false);
                          onNavigate('auth');
                        }}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.65rem',
                          width: '100%',
                          padding: '0.6rem 1rem',
                          background: 'none',
                          border: 'none',
                          color: '#DC2626',
                          fontSize: '0.875rem',
                          fontWeight: 600,
                          cursor: 'pointer',
                          textAlign: 'left'
                        }}
                      >
                        <LogOut size={16} />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            <button 
              className="btn btn-primary btn-sm"
              onClick={() => onNavigate('auth')}
            >
              Sign In
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
