import React from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export default function Toast({ toasts, onDismiss }) {
  if (!toasts || toasts.length === 0) return null;

  return (
    <div className="toast-container">
      {toasts.map((toast) => {
        const typeClass = toast.type === 'success' ? 'toast-success' : toast.type === 'error' ? 'toast-error' : 'toast-info';
        const Icon = toast.type === 'success' ? CheckCircle2 : toast.type === 'error' ? AlertCircle : Info;

        return (
          <div key={toast.id} className={`toast ${typeClass}`}>
            <Icon size={18} />
            <div style={{ flex: 1 }}>{toast.message}</div>
            <button 
              onClick={() => onDismiss(toast.id)} 
              style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer', opacity: 0.8 }}
            >
              <X size={16} />
            </button>
          </div>
        );
      })}
    </div>
  );
}
