import React from 'react';
import { Compass, Heart, Globe, Shield, Sparkles } from 'lucide-react';

export default function Footer({ onNavigate }) {
  return (
    <footer style={{
      background: 'var(--dark-navy)',
      color: 'white',
      borderTop: '1px solid rgba(255, 255, 255, 0.1)',
      marginTop: 'auto',
      padding: '3.5rem 0 2rem'
    }}>
      <div className="container-wide">
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: '2.5rem',
          paddingBottom: '2.5rem',
          borderBottom: '1px solid rgba(255, 255, 255, 0.1)'
        }}>
          {/* Col 1: Brand */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
              <div style={{
                width: '36px',
                height: '36px',
                background: 'var(--primary-gradient)',
                borderRadius: 'var(--radius-md)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white'
              }}>
                <Compass size={20} />
              </div>
              <span style={{ fontSize: '1.4rem', fontWeight: 800, fontFamily: 'Outfit, sans-serif' }}>
                GlobeTrotter
              </span>
            </div>
            <p style={{ color: '#94A3B8', fontSize: '0.875rem', lineHeight: 1.6, maxWidth: '280px' }}>
              The modern intelligent travel platform empowering explorers to dream, design, budget, and share seamless multi-city journeys.
            </p>
          </div>

          {/* Col 2: Platform Links */}
          <div>
            <h4 style={{ color: 'white', fontSize: '1rem', fontWeight: 700, marginBottom: '1rem' }}>
              Platform
            </h4>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.65rem', fontSize: '0.875rem', color: '#CBD5E1' }}>
              <li><button onClick={() => onNavigate('dashboard')} style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer', padding: 0 }}>Dashboard</button></li>
              <li><button onClick={() => onNavigate('my-trips')} style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer', padding: 0 }}>My Itineraries</button></li>
              <li><button onClick={() => onNavigate('cities')} style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer', padding: 0 }}>City Explorer</button></li>
              <li><button onClick={() => onNavigate('activities')} style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer', padding: 0 }}>Experiences Catalog</button></li>
              <li><button onClick={() => onNavigate('calendar')} style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer', padding: 0 }}>Calendar Timeline</button></li>
              <li><button onClick={() => onNavigate('community')} style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer', padding: 0 }}>Community Hub</button></li>
            </ul>
          </div>

          {/* Col 3: Features */}
          <div>
            <h4 style={{ color: 'white', fontSize: '1rem', fontWeight: 700, marginBottom: '1rem' }}>
              Features & Tools
            </h4>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.65rem', fontSize: '0.875rem', color: '#CBD5E1' }}>
              <li style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}><Sparkles size={14} color="var(--primary-coral)" /> Multi-City Route Planner</li>
              <li style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}><Globe size={14} color="var(--secondary-teal)" /> Day-by-Day Scheduling</li>
              <li style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}><Shield size={14} color="var(--accent-indigo)" /> Live Budget & Cost Analytics</li>
              <li style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}><Heart size={14} color="var(--accent-rose)" /> 1-Click Public Itinerary Cloning</li>
            </ul>
          </div>

          {/* Col 4: Relational Architecture */}
          <div>
            <h4 style={{ color: 'white', fontSize: '1rem', fontWeight: 700, marginBottom: '1rem' }}>
              Architecture
            </h4>
            <p style={{ color: '#94A3B8', fontSize: '0.85rem', lineHeight: 1.6 }}>
              Powered by SQLite relational database schema with full FK constraints, Express REST API, and dynamic React interface.
            </p>
            <div style={{ marginTop: '1rem', display: 'inline-block', padding: '0.4rem 0.8rem', background: 'rgba(255,255,255,0.08)', borderRadius: 'var(--radius-sm)', fontSize: '0.75rem', color: 'var(--accent-emerald)', fontWeight: 700 }}>
              ● Relational DB Active
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div style={{
          paddingTop: '1.5rem',
          display: 'flex',
          flexWrap: 'wrap',
          alignItems: 'center',
          justifyContent: 'space-between',
          fontSize: '0.825rem',
          color: '#64748B'
        }}>
          <div>
            © {new Date().getFullYear()} GlobeTrotter Travel Platforms Inc. All rights reserved.
          </div>
          <div>
            Designed with modern vibrant aesthetics & production full-stack architecture.
          </div>
        </div>
      </div>
    </footer>
  );
}
