import React from 'react';
import { Compass } from 'lucide-react';

export default function LoadingSpinner({ message = 'Loading your journey...' }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '4rem 1rem', minHeight: '300px' }}>
      <div style={{
        width: '56px',
        height: '56px',
        borderRadius: '50%',
        background: 'var(--primary-gradient)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'white',
        boxShadow: 'var(--shadow-coral)',
        animation: 'spin 2s linear infinite'
      }}>
        <Compass size={32} />
      </div>
      <p style={{ marginTop: '1.25rem', color: 'var(--text-secondary)', fontWeight: 600, fontSize: '0.95rem' }}>
        {message}
      </p>
      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
