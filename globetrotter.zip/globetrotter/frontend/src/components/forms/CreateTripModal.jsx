import React, { useState } from 'react';
import Modal from '../common/Modal';
import { Calendar, DollarSign, Image, Sparkles, Globe, Lock, MapPin } from 'lucide-react';

const PRESET_COVERS = [
  { name: 'Europe Architecture', url: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=1200&auto=format&fit=crop&q=80' },
  { name: 'Tokyo Neon & Shrines', url: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=1200&auto=format&fit=crop&q=80' },
  { name: 'Rome Historic Forum', url: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=1200&auto=format&fit=crop&q=80' },
  { name: 'Tropical Bali Paradise', url: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=1200&auto=format&fit=crop&q=80' },
  { name: 'Barcelona Mediterranean', url: 'https://images.unsplash.com/photo-1583422409516-2895a77efded?w=1200&auto=format&fit=crop&q=80' },
  { name: 'New York Skyline', url: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=1200&auto=format&fit=crop&q=80' },
  { name: 'Santorini Caldera', url: 'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=1200&auto=format&fit=crop&q=80' },
  { name: 'Kyoto Bamboo Grove', url: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=1200&auto=format&fit=crop&q=80' }
];

const TRAVEL_STYLES = ['Explorer', 'Adventure', 'Culture', 'Relaxation', 'Culinary', 'Luxury', 'Solo', 'Family'];

export default function CreateTripModal({ isOpen, onClose, onCreateTrip, cities = [], preselectedCityId = null }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [budgetAllocated, setBudgetAllocated] = useState('2500');
  const [travelStyle, setTravelStyle] = useState('Explorer');
  const [isPublic, setIsPublic] = useState(true);
  const [coverImage, setCoverImage] = useState(PRESET_COVERS[0].url);
  const [initialCityId, setInitialCityId] = useState(preselectedCityId || '');
  const [isCustomCover, setIsCustomCover] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    if (!title.trim() || !startDate || !endDate) {
      setError('Please fill in trip title, start date, and end date.');
      return;
    }

    if (new Date(startDate) > new Date(endDate)) {
      setError('Start date cannot be after end date.');
      return;
    }

    try {
      setSubmitting(true);
      setError('');
      await onCreateTrip({
        title,
        description,
        startDate,
        endDate,
        budgetAllocated: Number(budgetAllocated) || 0,
        travelStyle,
        isPublic,
        coverImage,
        initialCityId: initialCityId ? Number(initialCityId) : undefined
      });
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to create trip.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Plan a New Journey" maxWidth="680px">
      <form onSubmit={handleSubmit}>
        {error && (
          <div style={{ padding: '0.75rem 1rem', background: '#FEE2E2', color: '#DC2626', borderRadius: 'var(--radius-md)', marginBottom: '1rem', fontSize: '0.875rem' }}>
            {error}
          </div>
        )}

        {/* Trip Title */}
        <div className="form-group">
          <label className="form-label">Trip Title *</label>
          <input
            type="text"
            className="form-input"
            placeholder="e.g. Summer in Tokyo & Kyoto or Mediterranean Coastal Escape"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>

        {/* Dates */}
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Start Date *</label>
            <input
              type="date"
              className="form-input"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label className="form-label">End Date *</label>
            <input
              type="date"
              className="form-input"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              required
            />
          </div>
        </div>

        {/* Budget & Starting City */}
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Estimated Total Budget ($ USD)</label>
            <input
              type="number"
              min="0"
              step="50"
              className="form-input"
              placeholder="e.g. 3000"
              value={budgetAllocated}
              onChange={(e) => setBudgetAllocated(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Starting Destination Stop (Optional)</label>
            <select
              className="form-select"
              value={initialCityId}
              onChange={(e) => setInitialCityId(e.target.value)}
            >
              <option value="">-- Choose First City --</option>
              {cities.map((city) => (
                <option key={city.id} value={city.id}>
                  {city.name}, {city.country}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Travel Style Selector */}
        <div className="form-group">
          <label className="form-label">Travel Style</label>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
            {TRAVEL_STYLES.map((style) => (
              <button
                type="button"
                key={style}
                onClick={() => setTravelStyle(style)}
                className={`btn btn-sm ${travelStyle === style ? 'btn-primary' : 'btn-outline'}`}
                style={{ fontSize: '0.8rem', padding: '0.35rem 0.75rem' }}
              >
                {style}
              </button>
            ))}
          </div>
        </div>

        {/* Description */}
        <div className="form-group">
          <label className="form-label">Trip Notes / Description</label>
          <textarea
            className="form-textarea"
            placeholder="Share your goals, bucket list sights, or travel vibes for this trip..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>

        {/* Cover Photo Selection */}
        <div className="form-group">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.4rem' }}>
            <label className="form-label" style={{ marginBottom: 0 }}>Cover Photo</label>
            <button
              type="button"
              onClick={() => setIsCustomCover(!isCustomCover)}
              style={{ background: 'none', border: 'none', color: 'var(--primary-coral)', fontSize: '0.8rem', fontWeight: 600, cursor: 'pointer' }}
            >
              {isCustomCover ? 'Choose from Presets' : 'Enter Custom Image URL'}
            </button>
          </div>

          {isCustomCover ? (
            <input
              type="url"
              className="form-input"
              placeholder="https://images.unsplash.com/..."
              value={coverImage}
              onChange={(e) => setCoverImage(e.target.value)}
            />
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0.5rem' }}>
              {PRESET_COVERS.map((preset, idx) => (
                <div
                  key={idx}
                  onClick={() => setCoverImage(preset.url)}
                  style={{
                    height: '60px',
                    borderRadius: 'var(--radius-sm)',
                    overflow: 'hidden',
                    cursor: 'pointer',
                    position: 'relative',
                    border: coverImage === preset.url ? '3px solid var(--primary-coral)' : '1px solid var(--border-color)',
                    transition: 'transform 0.15s ease'
                  }}
                >
                  <img src={preset.url} alt={preset.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Visibility Toggle */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0.85rem 1rem',
          background: 'var(--bg-surface-secondary)',
          borderRadius: 'var(--radius-md)',
          margin: '1rem 0'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            {isPublic ? <Globe size={20} color="var(--secondary-teal)" /> : <Lock size={20} color="var(--text-muted)" />}
            <div>
              <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>
                {isPublic ? 'Public Itinerary' : 'Private Itinerary'}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                {isPublic ? 'Visible to travel community and sharable via public link' : 'Only visible to you'}
              </div>
            </div>
          </div>
          <input
            type="checkbox"
            checked={isPublic}
            onChange={(e) => setIsPublic(e.target.checked)}
            style={{ width: '18px', height: '18px', cursor: 'pointer', accentColor: 'var(--primary-coral)' }}
          />
        </div>

        {/* Submit */}
        <div className="modal-footer" style={{ padding: '1rem 0 0', borderTop: 'none' }}>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={submitting}>
            <Sparkles size={16} />
            <span>{submitting ? 'Creating Itinerary...' : 'Create & Build Itinerary'}</span>
          </button>
        </div>
      </form>
    </Modal>
  );
}
