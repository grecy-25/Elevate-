import React, { useState } from 'react';
import Modal from '../common/Modal';
import { DollarSign, Tag, Calendar, FileText } from 'lucide-react';

const EXPENSE_CATEGORIES = ['Accommodation', 'Transport', 'Food', 'Activities', 'Shopping', 'Miscellaneous'];

export default function AddExpenseModal({ isOpen, onClose, onAddExpense, tripId, defaultDate = '' }) {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Food');
  const [amount, setAmount] = useState('');
  const [expenseDate, setExpenseDate] = useState(defaultDate || new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    if (!title.trim() || !amount || !expenseDate) {
      setError('Please enter expense title, amount, and date.');
      return;
    }

    try {
      setSubmitting(true);
      setError('');
      await onAddExpense({
        tripId,
        title: title.trim(),
        category,
        amount: Number(amount),
        expenseDate,
        notes: notes.trim()
      });
      setTitle('');
      setAmount('');
      setNotes('');
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to record expense.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Log Trip Expense" maxWidth="540px">
      <form onSubmit={handleSubmit}>
        {error && (
          <div style={{ padding: '0.75rem', background: '#FEE2E2', color: '#DC2626', borderRadius: 'var(--radius-md)', marginBottom: '1rem', fontSize: '0.85rem' }}>
            {error}
          </div>
        )}

        <div className="form-group">
          <label className="form-label">Expense Title *</label>
          <input
            type="text"
            className="form-input"
            placeholder="e.g. Dinner in Trastevere, Subway pass, Museum ticket"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>

        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Category</label>
            <select
              className="form-select"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              {EXPENSE_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Amount ($ USD) *</label>
            <input
              type="number"
              min="0.01"
              step="0.01"
              className="form-input"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Expense Date *</label>
            <input
              type="date"
              className="form-input"
              value={expenseDate}
              onChange={(e) => setExpenseDate(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Receipt / Payment Notes</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. Split with Sarah, Paid by credit card"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
        </div>

        <div className="modal-footer" style={{ padding: '1rem 0 0', borderTop: 'none' }}>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={submitting}>
            {submitting ? 'Recording...' : 'Log Expense'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
