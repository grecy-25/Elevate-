import React, { useState } from 'react';
import Modal from '../common/Modal';
import { MapPin, Calendar, Home, Navigation, DollarSign } from 'lucide-react';

const TRANSPORT_MODES = ['Flight', 'Train', 'Bus', 'Car Rental', 'Ferry'];

export default function AddStopModal({ isOpen, onClose, onAddStop, cities = [], defaultStartDate = '', defaultEndDate = '' }) {
  const [cityId, setCityId] = useState(cities[0]?.id || '');
  const [arrivalDate, setArrivalDate] = useState(defaultStartDate || '');
  const [departureDate, setDepartureDate] = useState(defaultEndDate || '');
  const [accommodationName, setAccommodationName] = useState('');
  const [accommodationCost, setAccommodationCost] = useState('0');
  const [transportMode, setTransportMode] = useState('Flight');
  const [transportCost, setTransportCost] = useState('0');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    if (!cityId || !arrivalDate || !departureDate) {
      setError('Please select a destination city and arrival/departure dates.');
      return;
    }

    if (new Date(arrivalDate) > new Date(departureDate)) {
      setError('Arrival date cannot be after departure date.');
      return;
    }

    try {
      setSubmitting(true);
      setError('');
      await onAddStop({
        cityId: Number(cityId),
        arrivalDate,
        departureDate,
        accommodationName: accommodationName.trim() || 'City Hotel',
        accommodationCost: Number(accommodationCost) || 0,
        transportMode,
        transportCost: Number(transportCost) || 0,
        notes: notes.trim()
      });
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to add stop.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Add City Stop to Route" maxWidth="600px">
      <form onSubmit={handleSubmit}>
        {error && (
          <div style={{ padding: '0.75rem', background: '#FEE2E2', color: '#DC2626', borderRadius: 'var(--radius-md)', marginBottom: '1rem', fontSize: '0.85rem' }}>
            {error}
          </div>
        )}

        {/* City Select */}
        <div className="form-group">
          <label className="form-label">Destination City *</label>
          <select
            className="form-select"
            value={cityId}
            onChange={(e) => setCityId(e.target.value)}
            required
          >
            {cities.map((city) => (
              <option key={city.id} value={city.id}>
                {city.name}, {city.country} ({city.region})
              </option>
            ))}
          </select>
        </div>

        {/* Dates */}
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Arrival Date *</label>
            <input
              type="date"
              className="form-input"
              value={arrivalDate}
              onChange={(e) => setArrivalDate(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label className="form-label">Departure Date *</label>
            <input
              type="date"
              className="form-input"
              value={departureDate}
              onChange={(e) => setDepartureDate(e.target.value)}
              required
            />
          </div>
        </div>

        {/* Lodging */}
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Lodging / Hotel Name</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. Hyatt Regency, Boutique Airbnb"
              value={accommodationName}
              onChange={(e) => setAccommodationName(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Lodging Total Cost ($)</label>
            <input
              type="number"
              min="0"
              step="10"
              className="form-input"
              placeholder="0"
              value={accommodationCost}
              onChange={(e) => setAccommodationCost(e.target.value)}
            />
          </div>
        </div>

        {/* Transport */}
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Transit Mode into City</label>
            <select
              className="form-select"
              value={transportMode}
              onChange={(e) => setTransportMode(e.target.value)}
            >
              {TRANSPORT_MODES.map((mode) => (
                <option key={mode} value={mode}>{mode}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Transit Fare ($)</label>
            <input
              type="number"
              min="0"
              step="10"
              className="form-input"
              placeholder="0"
              value={transportCost}
              onChange={(e) => setTransportCost(e.target.value)}
            />
          </div>
        </div>

        {/* Notes */}
        <div className="form-group">
          <label className="form-label">Stop Notes</label>
          <textarea
            className="form-textarea"
            placeholder="e.g. Check-in after 3 PM, take express airport train..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
        </div>

        <div className="modal-footer" style={{ padding: '1rem 0 0', borderTop: 'none' }}>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={submitting}>
            {submitting ? 'Adding Stop...' : 'Add Stop to Route'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
