import React, { useState, useEffect } from 'react';
import Modal from '../common/Modal';
import { Clock, DollarSign, Tag, Sparkles } from 'lucide-react';
import { useCurrency } from '../../context/CurrencyContext';

const CATEGORIES = ['Sightseeing', 'Culinary', 'Adventure', 'Culture', 'Relaxation', 'Nightlife'];

export default function AddActivityModal({
  isOpen,
  onClose,
  onScheduleActivity,
  tripStopId,
  cityName = '',
  cityActivities = [],
  totalDays = 3,
  prefilledActivity = null
}) {
  const { formatAmount } = useCurrency();
  const [selectedCatalogId, setSelectedCatalogId] = useState(prefilledActivity?.id || '');
  const [isCustom, setIsCustom] = useState(!prefilledActivity && cityActivities.length === 0);
  const [dayNumber, setDayNumber] = useState('1');
  const [customTitle, setCustomTitle] = useState(prefilledActivity?.title || '');
  const [category, setCategory] = useState(prefilledActivity?.category || 'Sightseeing');
  const [startTime, setStartTime] = useState('10:00');
  const [durationMins, setDurationMins] = useState(prefilledActivity?.durationMins || '120');
  const [cost, setCost] = useState(prefilledActivity?.price !== undefined ? prefilledActivity.price : '0');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (prefilledActivity) {
      setSelectedCatalogId(prefilledActivity.id || '');
      setCustomTitle(prefilledActivity.title || '');
      setCategory(prefilledActivity.category || 'Sightseeing');
      setDurationMins(prefilledActivity.durationMins || '120');
      setCost(prefilledActivity.price !== undefined ? prefilledActivity.price : '0');
      setIsCustom(!prefilledActivity.id);
    }
  }, [prefilledActivity]);

  function handleCatalogSelect(actId) {
    setSelectedCatalogId(actId);
    if (!actId) {
      setIsCustom(true);
      return;
    }
    const act = cityActivities.find(a => a.id === Number(actId));
    if (act) {
      setCustomTitle(act.title);
      setCategory(act.category);
      setDurationMins(act.durationMins);
      setCost(act.price);
      setIsCustom(false);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!customTitle.trim()) {
      setError('Please enter or select an activity title.');
      return;
    }

    try {
      setSubmitting(true);
      setError('');
      await onScheduleActivity({
        tripStopId,
        activityId: selectedCatalogId ? Number(selectedCatalogId) : null,
        dayNumber: Number(dayNumber),
        customTitle: customTitle.trim(),
        category,
        startTime,
        durationMins: Number(durationMins) || 120,
        cost: Number(cost) || 0,
        notes: notes.trim()
      });
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to schedule activity.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Schedule Activity ${cityName ? `in ${cityName}` : ''}`} maxWidth="620px">
      <form onSubmit={handleSubmit}>
        {error && (
          <div style={{ padding: '0.75rem', background: '#FEE2E2', color: '#DC2626', borderRadius: 'var(--radius-md)', marginBottom: '1rem', fontSize: '0.85rem' }}>
            {error}
          </div>
        )}

        {/* Option to select from curated city catalog */}
        {cityActivities && cityActivities.length > 0 && !prefilledActivity && (
          <div className="form-group">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.35rem' }}>
              <label className="form-label" style={{ marginBottom: 0 }}>Curated Experiences in {cityName}</label>
              <button
                type="button"
                onClick={() => {
                  setIsCustom(!isCustom);
                  if (!isCustom) {
                    setSelectedCatalogId('');
                    setCustomTitle('');
                  }
                }}
                style={{ background: 'none', border: 'none', color: 'var(--primary-coral)', fontSize: '0.8rem', fontWeight: 600, cursor: 'pointer' }}
              >
                {isCustom ? 'Pick from Curated List' : '+ Create Custom Activity'}
              </button>
            </div>

            {!isCustom && (
              <select
                className="form-select"
                value={selectedCatalogId}
                onChange={(e) => handleCatalogSelect(e.target.value)}
              >
                <option value="">-- Choose Curated Experience --</option>
                {cityActivities.map((act) => (
                  <option key={act.id} value={act.id}>
                    {act.title} ({act.category} • {formatAmount(act.price)})
                  </option>
                ))}
              </select>
            )}
          </div>
        )}

        {/* Custom or Selected Title */}
        <div className="form-group">
          <label className="form-label">Activity Title *</label>
          <input
            type="text"
            className="form-input"
            placeholder="e.g. Sunset drinks at Sky Bar, Museum Tour..."
            value={customTitle}
            onChange={(e) => setCustomTitle(e.target.value)}
            required
          />
        </div>

        {/* Day & Time Slot */}
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Itinerary Day</label>
            <select
              className="form-select"
              value={dayNumber}
              onChange={(e) => setDayNumber(e.target.value)}
            >
              {Array.from({ length: Math.max(1, totalDays) }, (_, i) => (
                <option key={i + 1} value={i + 1}>
                  Day {i + 1}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Start Time</label>
            <input
              type="time"
              className="form-input"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              required
            />
          </div>
        </div>

        {/* Category & Cost */}
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Category</label>
            <select
              className="form-select"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Cost ($ USD)</label>
            <input
              type="number"
              min="0"
              step="5"
              className="form-input"
              value={cost}
              onChange={(e) => setCost(e.target.value)}
            />
          </div>
        </div>

        {/* Duration & Notes */}
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Estimated Duration (Mins)</label>
            <input
              type="number"
              min="15"
              step="15"
              className="form-input"
              value={durationMins}
              onChange={(e) => setDurationMins(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Notes / Booking Details</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. Reservation under Alex, bring sunscreen"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
        </div>

        <div className="modal-footer" style={{ padding: '1rem 0 0', borderTop: 'none' }}>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={submitting}>
            {submitting ? 'Adding to Schedule...' : 'Add to Day Schedule'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
