import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Clock, MapPin, Tag } from 'lucide-react';
import { useCurrency } from '../../context/CurrencyContext';

const DAYS_OF_WEEK = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function InteractiveCalendar({ trips = [], currentTrip = null, onSelectTrip, onScheduleActivity }) {
  const { formatAmount } = useCurrency();
  const [currentDate, setCurrentDate] = useState(() => {
    if (currentTrip && currentTrip.startDate) {
      return new Date(currentTrip.startDate);
    }
    return new Date();
  });
  const [selectedDay, setSelectedDay] = useState(null);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDayOfMonth = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  function prevMonth() {
    setCurrentDate(new Date(year, month - 1, 1));
  }

  function nextMonth() {
    setCurrentDate(new Date(year, month + 1, 1));
  }

  function goToToday() {
    setCurrentDate(new Date());
  }

  const monthName = currentDate.toLocaleString('default', { month: 'long' });

  // Map trips and activities to date strings YYYY-MM-DD
  const activeTrips = currentTrip ? [currentTrip] : trips;
  const eventsByDate = {};

  activeTrips.forEach(trip => {
    const tripStart = new Date(trip.startDate);
    const tripEnd = new Date(trip.endDate);

    // If trip has detailed stops & activities
    if (trip.stops) {
      trip.stops.forEach(stop => {
        const stopStart = new Date(stop.arrivalDate);
        if (stop.activities) {
          stop.activities.forEach(act => {
            // Calculate date from stop arrival + dayNumber - 1
            const actDateObj = new Date(stopStart);
            actDateObj.setDate(actDateObj.getDate() + ((act.dayNumber || 1) - 1));
            const dateStr = actDateObj.toISOString().split('T')[0];

            if (!eventsByDate[dateStr]) eventsByDate[dateStr] = [];
            eventsByDate[dateStr].push({
              type: 'activity',
              title: act.title,
              time: act.startTime,
              category: act.category,
              cost: act.cost,
              cityName: stop.cityName,
              tripTitle: trip.title,
              isCompleted: act.isCompleted
            });
          });
        }
      });
    }
  });

  // Check if a date string falls inside any active trip
  function getTripForDate(dateStr) {
    return activeTrips.find(t => t.startDate <= dateStr && t.endDate >= dateStr);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {/* Calendar Header Bar */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '1.25rem 1.5rem',
        background: 'var(--bg-surface)',
        borderRadius: 'var(--radius-lg)',
        border: '1px solid var(--border-color)',
        boxShadow: 'var(--shadow-sm)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{
            width: '42px',
            height: '42px',
            borderRadius: 'var(--radius-md)',
            background: 'var(--primary-gradient)',
            color: 'white',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: 'var(--shadow-coral)'
          }}>
            <CalendarIcon size={22} />
          </div>
          <div>
            <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>
              {monthName} {year}
            </h2>
            <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
              {activeTrips.length} active journey timeline{activeTrips.length !== 1 ? 's' : ''}
            </p>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <button className="btn btn-outline btn-sm" onClick={goToToday}>
            Today
          </button>
          <button className="btn btn-outline btn-icon-sm" onClick={prevMonth} title="Previous Month">
            <ChevronLeft size={18} />
          </button>
          <button className="btn btn-outline btn-icon-sm" onClick={nextMonth} title="Next Month">
            <ChevronRight size={18} />
          </button>
        </div>
      </div>

      {/* Days Grid */}
      <div style={{
        background: 'var(--bg-surface)',
        borderRadius: 'var(--radius-xl)',
        border: '1px solid var(--border-color)',
        boxShadow: 'var(--shadow-sm)',
        overflow: 'hidden'
      }}>
        {/* Day of Week Headers */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(7, 1fr)',
          background: 'var(--bg-surface-secondary)',
          borderBottom: '1px solid var(--border-color)',
          textAlign: 'center',
          fontWeight: 700,
          fontSize: '0.85rem',
          color: 'var(--text-secondary)',
          padding: '0.75rem 0'
        }}>
          {DAYS_OF_WEEK.map(d => <div key={d}>{d}</div>)}
        </div>

        {/* Month Day Cells */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '1px', background: 'var(--border-color)' }}>
          {/* Empty cells before 1st of month */}
          {Array.from({ length: firstDayOfMonth }, (_, i) => (
            <div key={`empty-${i}`} style={{ background: 'var(--bg-surface)', minHeight: '110px', opacity: 0.3 }} />
          ))}

          {/* Actual days */}
          {Array.from({ length: daysInMonth }, (_, i) => {
            const dayNum = i + 1;
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
            const isToday = new Date().toISOString().split('T')[0] === dateStr;
            const inTrip = getTripForDate(dateStr);
            const events = eventsByDate[dateStr] || [];
            const isSelected = selectedDay === dateStr;

            return (
              <div
                key={dayNum}
                onClick={() => setSelectedDay(dateStr)}
                style={{
                  background: isSelected 
                    ? 'rgba(255, 107, 74, 0.08)' 
                    : inTrip 
                    ? 'rgba(8, 145, 178, 0.04)' 
                    : 'var(--bg-surface)',
                  minHeight: '110px',
                  padding: '0.5rem',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.35rem',
                  cursor: 'pointer',
                  border: isSelected ? '2px solid var(--primary-coral)' : 'none',
                  transition: 'background 0.15s ease'
                }}
              >
                {/* Day Number Header */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{
                    width: '26px',
                    height: '26px',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '0.85rem',
                    fontWeight: 700,
                    background: isToday ? 'var(--primary-coral)' : 'transparent',
                    color: isToday ? 'white' : inTrip ? 'var(--secondary-teal)' : 'var(--text-primary)'
                  }}>
                    {dayNum}
                  </span>

                  {inTrip && (
                    <span style={{ fontSize: '0.65rem', fontWeight: 700, color: 'var(--secondary-teal)', background: 'rgba(8, 145, 178, 0.15)', padding: '0.1rem 0.35rem', borderRadius: '4px' }}>
                      Trip
                    </span>
                  )}
                </div>

                {/* Event Pills */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem', overflow: 'hidden' }}>
                  {events.slice(0, 2).map((ev, idx) => (
                    <div
                      key={idx}
                      style={{
                        fontSize: '0.725rem',
                        fontWeight: 600,
                        padding: '0.2rem 0.35rem',
                        borderRadius: '4px',
                        background: 'rgba(109, 93, 211, 0.14)',
                        color: 'var(--accent-indigo)',
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.25rem'
                      }}
                      title={`${ev.time || ''} ${ev.title}`}
                    >
                      <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)' }}>{ev.time}</span>
                      <span>{ev.title}</span>
                    </div>
                  ))}

                  {events.length > 2 && (
                    <span style={{ fontSize: '0.7rem', color: 'var(--primary-coral)', fontWeight: 700, paddingLeft: '0.25rem' }}>
                      +{events.length - 2} more
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Day Agenda Drawer */}
      {selectedDay && (
        <div style={{
          background: 'var(--bg-surface)',
          borderRadius: 'var(--radius-xl)',
          border: '1px solid var(--border-color)',
          padding: '1.5rem',
          boxShadow: 'var(--shadow-md)'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>
                Agenda for {new Date(selectedDay + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
              </h3>
              {getTripForDate(selectedDay) && (
                <span className="badge badge-teal" style={{ marginTop: '0.3rem' }}>
                  Part of: {getTripForDate(selectedDay).title}
                </span>
              )}
            </div>

            <button className="btn btn-ghost btn-sm" onClick={() => setSelectedDay(null)}>
              Close Day View
            </button>
          </div>

          {eventsByDate[selectedDay] && eventsByDate[selectedDay].length > 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {eventsByDate[selectedDay].map((ev, idx) => (
                <div
                  key={idx}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '0.85rem 1rem',
                    background: 'var(--bg-surface-secondary)',
                    borderRadius: 'var(--radius-md)',
                    borderLeft: '4px solid var(--accent-indigo)'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', color: 'var(--text-muted)', fontSize: '0.85rem', fontWeight: 600 }}>
                      <Clock size={16} />
                      <span>{ev.time || 'All Day'}</span>
                    </div>
                    <div>
                      <h4 style={{ fontSize: '0.95rem', fontWeight: 700 }}>{ev.title}</h4>
                      {ev.cityName && (
                        <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                          <MapPin size={13} />
                          {ev.cityName}
                        </span>
                      )}
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <span className="badge badge-indigo">{ev.category}</span>
                    {ev.cost > 0 && (
                      <span style={{ fontWeight: 800, fontSize: '0.95rem' }}>
                        {formatAmount(ev.cost)}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ padding: '2rem 1rem', textAlign: 'center', color: 'var(--text-muted)' }}>
              <p style={{ fontSize: '0.95rem' }}>No specific activities scheduled on this day.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
