import React, { useEffect, useState } from 'react';
import { X, MapPin, Star, Calendar, Thermometer, Heart, Plus, Clock, Sparkles } from 'lucide-react';
import api from '../../services/api';
import { useCurrency } from '../../context/CurrencyContext';
import { useAuth } from '../../context/AuthContext';
import LoadingSpinner from '../common/LoadingSpinner';

export default function CityDetailModal({ cityId, onClose, onAddToTrip, onSelectCity, showToast }) {
  const { formatAmount } = useCurrency();
  const { refreshUser } = useAuth();
  const [loading, setLoading] = useState(true);
  const [city, setCity] = useState(null);
  const [activities, setActivities] = useState([]);
  const [similarCities, setSimilarCities] = useState([]);

  useEffect(() => {
    if (!cityId) return;

    let cancelled = false;

    async function loadCity() {
      try {
        setLoading(true);
        const data = await api.cities.getById(cityId);
        if (cancelled) return;
        setCity(data.city);
        setActivities(data.activities || []);

        // Fetch a few other popular destinations in the same region
        if (data.city?.region) {
          try {
            const regionRes = await api.cities.list({ region: data.city.region });
            if (!cancelled) {
              const others = (regionRes.cities || [])
                .filter(c => c.id !== data.city.id)
                .sort((a, b) => b.popularityRating - a.popularityRating)
                .slice(0, 4);
              setSimilarCities(others);
            }
          } catch {
            if (!cancelled) setSimilarCities([]);
          }
        }
      } catch (err) {
        if (!cancelled) showToast && showToast('Failed to load city details', 'error');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    loadCity();
    return () => { cancelled = true; };
  }, [cityId]);

  async function handleToggleSave() {
    if (!city) return;
    try {
      const res = await api.cities.toggleSave(city.id);
      setCity(prev => ({ ...prev, isSaved: res.isSaved }));
      showToast && showToast(res.message, 'success');
      refreshUser && refreshUser();
    } catch (err) {
      showToast && showToast('Failed to update wishlist', 'error');
    }
  }

  if (!cityId) return null;

  const costLabels = ['', 'Budget', 'Moderate', 'Upscale', 'Luxury'];

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div
        className="modal-content"
        style={{ maxWidth: '760px', padding: 0, overflow: 'hidden' }}
        onClick={(e) => e.stopPropagation()}
      >
        {loading || !city ? (
          <div style={{ padding: '3rem' }}>
            <LoadingSpinner message="Loading destination details..." />
          </div>
        ) : (
          <>
            {/* Hero */}
            <div style={{ position: 'relative', height: '260px', width: '100%', overflow: 'hidden' }}>
              <img src={city.imageUrl} alt={city.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(15,23,42,0.15) 0%, rgba(15,23,42,0.8) 100%)' }} />

              <button
                onClick={onClose}
                aria-label="Close"
                style={{ position: 'absolute', top: '14px', right: '14px', width: '36px', height: '36px', borderRadius: '50%', background: 'rgba(255,255,255,0.92)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
              >
                <X size={18} />
              </button>

              <div style={{ position: 'absolute', bottom: '16px', left: '20px', right: '20px' }}>
                <span className="badge badge-teal" style={{ backdropFilter: 'blur(8px)', marginBottom: '0.5rem', display: 'inline-block' }}>{city.region}</span>
                <h2 style={{ color: '#fff', fontSize: '1.9rem', fontWeight: 800, textShadow: '0 2px 6px rgba(0,0,0,0.5)' }}>{city.name}</h2>
                <p style={{ color: '#E2E8F0', fontSize: '0.95rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                  <MapPin size={15} style={{ color: 'var(--primary-coral)' }} />
                  {city.country}
                </p>
              </div>
            </div>

            <div className="modal-body" style={{ padding: '1.5rem' }}>
              {/* Quick stats row */}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1.25rem', marginBottom: '1.25rem', paddingBottom: '1.25rem', borderBottom: '1px solid var(--border-color)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontWeight: 700, color: 'var(--accent-gold)' }}>
                  <Star size={16} fill="var(--accent-gold)" />
                  <span>{city.popularityRating} rating</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontWeight: 600, color: 'var(--accent-emerald)' }}>
                  <span>{'$'.repeat(city.costIndex || 2)}</span>
                  <span style={{ color: 'var(--text-muted)', fontWeight: 500 }}>({costLabels[city.costIndex]})</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: 'var(--text-secondary)' }}>
                  <Calendar size={16} />
                  <span>Best season: {city.bestSeason}</span>
                </div>
                {city.weatherPreview && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: 'var(--text-secondary)' }}>
                    <Thermometer size={16} />
                    <span>{city.weatherPreview.tempC}°C / {city.weatherPreview.tempF}°F &middot; {city.weatherPreview.condition}</span>
                  </div>
                )}
              </div>

              <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem', lineHeight: 1.6, marginBottom: '1.5rem' }}>
                {city.description}
              </p>

              {/* Actions */}
              <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '2rem' }}>
                <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => onAddToTrip && onAddToTrip(city)}>
                  <Plus size={16} />
                  <span>Add to Trip</span>
                </button>
                <button
                  className="btn btn-outline"
                  style={{ flex: 1, color: city.isSaved ? 'var(--accent-rose)' : undefined }}
                  onClick={handleToggleSave}
                >
                  <Heart size={16} fill={city.isSaved ? 'var(--accent-rose)' : 'none'} />
                  <span>{city.isSaved ? 'Saved to Wishlist' : 'Save to Wishlist'}</span>
                </button>
              </div>

              {/* Popular Experiences */}
              <div style={{ marginBottom: similarCities.length ? '2rem' : 0 }}>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '0.9rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <Sparkles size={18} style={{ color: 'var(--accent-indigo)' }} />
                  Popular Experiences in {city.name}
                </h3>
                {activities.length > 0 ? (
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(210px, 1fr))', gap: '0.9rem' }}>
                    {activities.slice(0, 6).map(act => (
                      <div key={act.id} className="card" style={{ padding: '0.9rem', display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                        <span className="badge badge-indigo" style={{ alignSelf: 'flex-start', fontSize: '0.7rem' }}>{act.category}</span>
                        <div style={{ fontWeight: 700, fontSize: '0.9rem', lineHeight: 1.3 }}>{act.title}</div>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: 'auto', paddingTop: '0.4rem' }}>
                          <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                            <Clock size={12} />
                            {Math.round(act.durationMins / 60) || 1}h
                          </span>
                          <span style={{ fontWeight: 800, color: 'var(--text-primary)' }}>
                            {act.price === 0 ? 'Free' : formatAmount(act.price)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>No curated experiences listed for this destination yet.</p>
                )}
              </div>

              {/* Similar / nearby popular destinations */}
              {similarCities.length > 0 && (
                <div>
                  <h3 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '0.9rem' }}>
                    More Popular Destinations in {city.region}
                  </h3>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: '0.9rem' }}>
                    {similarCities.map(c => (
                      <button
                        key={c.id}
                        onClick={() => onSelectCity && onSelectCity(c.id)}
                        className="card card-interactive"
                        style={{ padding: 0, textAlign: 'left', cursor: 'pointer', border: 'none', overflow: 'hidden' }}
                      >
                        <div style={{ position: 'relative', height: '90px' }}>
                          <img src={c.imageUrl} alt={c.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(15,23,42,0.05) 0%, rgba(15,23,42,0.75) 100%)' }} />
                          <div style={{ position: 'absolute', bottom: '6px', left: '8px', right: '8px', color: '#fff' }}>
                            <div style={{ fontWeight: 700, fontSize: '0.85rem' }}>{c.name}</div>
                            <div style={{ fontSize: '0.7rem', color: '#E2E8F0' }}>{c.country}</div>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
