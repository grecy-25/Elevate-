import React, { useState } from 'react';
import { Calendar, MapPin, DollarSign, Share2, Copy, Trash2, Edit3, ArrowRight, Eye, MoreVertical } from 'lucide-react';
import { useCurrency } from '../../context/CurrencyContext';

export default function TripCard({
  trip,
  onView,
  onEdit,
  onBudget,
  onCalendar,
  onShare,
  onClone,
  onDelete
}) {
  const { formatAmount } = useCurrency();
  const [showMenu, setShowMenu] = useState(false);

  const start = new Date(trip.startDate);
  const end = new Date(trip.endDate);
  const durationDays = Math.max(1, Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1);

  const statusBadgeClass = 
    trip.status === 'ongoing' ? 'badge-emerald' :
    trip.status === 'upcoming' ? 'badge-indigo' : 'badge-gray';

  return (
    <div className="card card-interactive" style={{ display: 'flex', flexDirection: 'column', height: '100%', position: 'relative' }}>
      {/* Cover Image Header */}
      <div style={{ position: 'relative', height: '190px', width: '100%', overflow: 'hidden' }}>
        <img
          src={trip.coverImage || 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800&auto=format&fit=crop&q=80'}
          alt={trip.title}
          style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.5s ease' }}
          className="trip-card-img"
        />
        <div style={{
          position: 'absolute',
          inset: 0,
          background: 'linear-gradient(180deg, rgba(15, 23, 42, 0.2) 0%, rgba(15, 23, 42, 0.7) 100%)'
        }} />

        {/* Top Badges */}
        <div style={{ position: 'absolute', top: '12px', left: '12px', right: '12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span className={`badge ${statusBadgeClass}`} style={{ backdropFilter: 'blur(8px)' }}>
            {trip.status}
          </span>
          <div style={{ display: 'flex', gap: '0.4rem' }}>
            {trip.isPublic && (
              <span className="badge badge-teal" style={{ backdropFilter: 'blur(8px)' }}>
                Public
              </span>
            )}
            <span className="badge badge-coral" style={{ backdropFilter: 'blur(8px)' }}>
              {trip.travelStyle || 'Explorer'}
            </span>
          </div>
        </div>

        {/* Bottom Destination Count in Image */}
        <div style={{ position: 'absolute', bottom: '12px', left: '12px', color: 'white', display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.825rem', fontWeight: 600 }}>
          <MapPin size={15} style={{ color: 'var(--primary-coral)' }} />
          <span>{trip.stopsCount || trip.cities?.length || 0} Cities</span>
          <span>•</span>
          <span>{durationDays} Days</span>
        </div>
      </div>

      {/* Card Body */}
      <div style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', flex: 1, gap: '0.75rem' }}>
        <h3 style={{ fontSize: '1.15rem', fontWeight: 700, lineHeight: 1.3, minHeight: '2.6rem' }}>
          {trip.title}
        </h3>

        {/* Date info */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-secondary)', fontSize: '0.85rem' }}>
          <Calendar size={15} style={{ color: 'var(--accent-indigo)' }} />
          <span>{trip.startDate} to {trip.endDate}</span>
        </div>

        {/* City Route Badges */}
        {trip.cities && trip.cities.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem', marginTop: '0.25rem' }}>
            {trip.cities.slice(0, 3).map(c => (
              <span key={c.id} style={{
                fontSize: '0.75rem',
                fontWeight: 600,
                background: 'var(--bg-surface-secondary)',
                color: 'var(--text-secondary)',
                padding: '0.2rem 0.5rem',
                borderRadius: 'var(--radius-sm)'
              }}>
                {c.name}
              </span>
            ))}
            {trip.cities.length > 3 && (
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', padding: '0.2rem 0.3rem' }}>
                +{trip.cities.length - 3} more
              </span>
            )}
          </div>
        )}

        {/* Budget Progress Bar */}
        <div style={{ marginTop: 'auto', paddingTop: '0.75rem', borderTop: '1px solid var(--border-color)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', fontWeight: 600, marginBottom: '0.35rem' }}>
            <span style={{ color: 'var(--text-muted)' }}>Budget</span>
            <span style={{ color: trip.budgetRemaining < 0 ? 'var(--accent-rose)' : 'var(--text-primary)' }}>
              {formatAmount(trip.totalSpent)} / {formatAmount(trip.budgetAllocated)}
            </span>
          </div>
          <div style={{ height: '6px', width: '100%', background: 'var(--bg-surface-secondary)', borderRadius: 'var(--radius-full)', overflow: 'hidden' }}>
            <div style={{
              height: '100%',
              width: `${Math.min(100, trip.percentSpent || 0)}%`,
              background: trip.budgetRemaining < 0 ? 'var(--accent-rose)' : 'var(--primary-gradient)',
              borderRadius: 'var(--radius-full)'
            }} />
          </div>
        </div>
      </div>

      {/* Card Action Buttons */}
      <div style={{
        padding: '0.85rem 1.25rem',
        background: 'var(--bg-surface-secondary)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderTop: '1px solid var(--border-color)'
      }}>
        <button 
          className="btn btn-primary btn-sm"
          onClick={() => onView(trip.id)}
          style={{ flex: 1, marginRight: '0.5rem' }}
        >
          <span>View Plan</span>
          <ArrowRight size={14} />
        </button>

        <div style={{ display: 'flex', gap: '0.3rem' }}>
          <button 
            className="btn-outline btn-icon-sm" 
            title="Edit Itinerary" 
            onClick={() => onEdit(trip.id)}
          >
            <Edit3 size={15} />
          </button>
          <button 
            className="btn-outline btn-icon-sm" 
            title="Budget Analytics" 
            onClick={() => onBudget(trip.id)}
          >
            <DollarSign size={15} />
          </button>
          <button 
            className="btn-outline btn-icon-sm" 
            title="Duplicate Trip" 
            onClick={() => onClone(trip.id)}
          >
            <Copy size={15} />
          </button>
          <button 
            className="btn-outline btn-icon-sm" 
            title="Delete Trip" 
            onClick={() => onDelete(trip.id)}
            style={{ color: '#DC2626' }}
          >
            <Trash2 size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}
