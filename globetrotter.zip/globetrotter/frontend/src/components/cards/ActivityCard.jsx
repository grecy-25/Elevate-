import React from 'react';
import { Clock, Star, MapPin, Plus, DollarSign } from 'lucide-react';
import { useCurrency } from '../../context/CurrencyContext';

const CATEGORY_BADGES = {
  Sightseeing: 'badge-coral',
  Culinary: 'badge-gold',
  Adventure: 'badge-teal',
  Culture: 'badge-indigo',
  Relaxation: 'badge-emerald',
  Nightlife: 'badge-rose'
};

export default function ActivityCard({ activity, onSchedule }) {
  const { formatAmount } = useCurrency();

  const hours = Math.floor(activity.durationMins / 60);
  const mins = activity.durationMins % 60;
  const durationText = hours > 0 ? `${hours}h${mins > 0 ? ` ${mins}m` : ''}` : `${mins}m`;

  const badgeClass = CATEGORY_BADGES[activity.category] || 'badge-gray';

  return (
    <div className="card" style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      {/* Activity Image */}
      <div style={{ position: 'relative', height: '170px', width: '100%', overflow: 'hidden' }}>
        <img
          src={activity.imageUrl || 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800&auto=format&fit=crop&q=80'}
          alt={activity.title}
          style={{ width: '100%', height: '100%', objectFit: 'cover' }}
        />
        <div style={{
          position: 'absolute',
          inset: 0,
          background: 'linear-gradient(180deg, rgba(15, 23, 42, 0.1) 0%, rgba(15, 23, 42, 0.6) 100%)'
        }} />

        {/* Top Category Badge */}
        <div style={{ position: 'absolute', top: '10px', left: '10px' }}>
          <span className={`badge ${badgeClass}`} style={{ backdropFilter: 'blur(8px)' }}>
            {activity.category}
          </span>
        </div>

        {/* Top Right Rating */}
        <div style={{
          position: 'absolute',
          top: '10px',
          right: '10px',
          background: 'rgba(15, 23, 42, 0.8)',
          backdropFilter: 'blur(8px)',
          color: 'white',
          padding: '0.2rem 0.5rem',
          borderRadius: 'var(--radius-sm)',
          display: 'flex',
          alignItems: 'center',
          gap: '0.25rem',
          fontSize: '0.75rem',
          fontWeight: 700
        }}>
          <Star size={13} fill="var(--accent-gold)" color="var(--accent-gold)" />
          <span>{activity.rating}</span>
        </div>

        {/* Bottom City / Location */}
        {activity.cityName && (
          <div style={{ position: 'absolute', bottom: '10px', left: '10px', color: 'white', fontSize: '0.8rem', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
            <MapPin size={13} style={{ color: 'var(--primary-coral)' }} />
            <span>{activity.cityName}, {activity.cityCountry}</span>
          </div>
        )}
      </div>

      {/* Body */}
      <div style={{ padding: '1.15rem', display: 'flex', flexDirection: 'column', flex: 1, gap: '0.5rem' }}>
        <h4 style={{ fontSize: '1.05rem', fontWeight: 700, lineHeight: 1.3 }}>
          {activity.title}
        </h4>

        <p style={{ fontSize: '0.825rem', color: 'var(--text-secondary)', lineClamp: 2, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
          {activity.description}
        </p>

        {activity.locationName && (
          <p style={{ fontSize: '0.775rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
            <MapPin size={12} />
            <span style={{ textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>{activity.locationName}</span>
          </p>
        )}

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 'auto', paddingTop: '0.75rem', borderTop: '1px solid var(--border-color)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            <Clock size={14} />
            <span>{durationText}</span>
          </div>

          <div style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--text-primary)' }}>
            {activity.price === 0 ? 'Free' : formatAmount(activity.price)}
          </div>
        </div>
      </div>

      {/* Schedule button */}
      {onSchedule && (
        <div style={{ padding: '0.75rem 1.15rem', background: 'var(--bg-surface-secondary)', borderTop: '1px solid var(--border-color)' }}>
          <button 
            className="btn btn-secondary btn-sm"
            onClick={() => onSchedule(activity)}
            style={{ width: '100%' }}
          >
            <Plus size={15} />
            <span>Schedule Activity</span>
          </button>
        </div>
      )}
    </div>
  );
}
