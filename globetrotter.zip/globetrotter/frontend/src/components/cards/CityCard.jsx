import React from 'react';
import { Heart, Star, Compass, MapPin, Calendar, Plus } from 'lucide-react';

export default function CityCard({ city, onAddToTrip, onToggleSave, onViewDetails }) {
  const costSymbols = '$'.repeat(city.costIndex || 2);
  const costLabels = ['', 'Budget', 'Moderate', 'Upscale', 'Luxury'];

  return (
    <div className="card card-interactive" style={{ display: 'flex', flexDirection: 'column', height: '100%', position: 'relative' }}>
      {/* City Photo */}
      <div style={{ position: 'relative', height: '200px', width: '100%', overflow: 'hidden' }}>
        <img
          src={city.imageUrl}
          alt={city.name}
          style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.5s ease' }}
        />
        <div style={{
          position: 'absolute',
          inset: 0,
          background: 'linear-gradient(180deg, rgba(15, 23, 42, 0.1) 0%, rgba(15, 23, 42, 0.7) 100%)'
        }} />

        {/* Top Badges */}
        <div style={{ position: 'absolute', top: '12px', left: '12px', right: '12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span className="badge badge-teal" style={{ backdropFilter: 'blur(8px)' }}>
            {city.region}
          </span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleSave(city.id);
            }}
            style={{
              width: '34px',
              height: '34px',
              borderRadius: '50%',
              background: 'rgba(255, 255, 255, 0.9)',
              border: 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              boxShadow: 'var(--shadow-sm)',
              color: city.isSaved ? 'var(--accent-rose)' : 'var(--text-secondary)',
              transition: 'transform 0.2s ease'
            }}
            title={city.isSaved ? 'Remove from wishlist' : 'Save to wishlist'}
          >
            <Heart size={18} fill={city.isSaved ? 'var(--accent-rose)' : 'none'} />
          </button>
        </div>

        {/* Bottom City Name & Country in Photo */}
        <div style={{ position: 'absolute', bottom: '12px', left: '12px', right: '12px' }}>
          <h3 style={{ color: 'white', fontSize: '1.35rem', fontWeight: 800, textShadow: '0 2px 4px rgba(0,0,0,0.5)' }}>
            {city.name}
          </h3>
          <p style={{ color: '#E2E8F0', fontSize: '0.85rem', fontWeight: 500, display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
            <MapPin size={14} style={{ color: 'var(--primary-coral)' }} />
            {city.country}
          </p>
        </div>
      </div>

      {/* City Meta */}
      <div style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', flex: 1, gap: '0.65rem' }}>
        <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', lineClamp: 2, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden', minHeight: '2.5rem' }}>
          {city.description}
        </p>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.825rem', color: 'var(--text-secondary)', marginTop: 'auto', paddingTop: '0.5rem', borderTop: '1px solid var(--border-color)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', fontWeight: 700, color: 'var(--accent-gold)' }}>
            <Star size={15} fill="var(--accent-gold)" />
            <span>{city.popularityRating}</span>
          </div>

          <div style={{ fontWeight: 600 }}>
            <span style={{ color: 'var(--accent-emerald)', fontWeight: 800 }}>{costSymbols}</span>{' '}
            <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>({costLabels[city.costIndex]})</span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.775rem', color: 'var(--text-muted)' }}>
            <Calendar size={13} />
            <span>{city.bestSeason}</span>
          </div>
        </div>
      </div>

      {/* Action Footer */}
      <div style={{ padding: '0.85rem 1.25rem', background: 'var(--bg-surface-secondary)', borderTop: '1px solid var(--border-color)', display: 'flex', gap: '0.5rem' }}>
        {onViewDetails && (
          <button 
            className="btn btn-outline btn-sm"
            onClick={() => onViewDetails(city.id)}
            style={{ flex: 1 }}
          >
            Explore
          </button>
        )}
        <button 
          className="btn btn-primary btn-sm"
          onClick={() => onAddToTrip(city)}
          style={{ flex: 1 }}
        >
          <Plus size={15} />
          <span>Add to Trip</span>
        </button>
      </div>
    </div>
  );
}
